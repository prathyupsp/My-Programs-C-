﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest4.POCO
{
    [Serializable]
    class Product
    {
        //declaring datamembers
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public float Price { get; set; }
        public string ExpiryDate { get; set; }
        public int Quantity { get; set; }
        public string Description { get; set; }
        public string Supplier { get; set; }
        public string Features { get; set; }
        public string Service { get; set; }
    }
}
