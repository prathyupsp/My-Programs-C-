﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ModuleTest4.POCO;
using System.Windows.Forms;

namespace ModuleTest4
{
    public partial class productDetailsForm : Form
    {
        string category = null;
        public productDetailsForm()
        {
            InitializeComponent();
            tt1.SetToolTip(txtProductId, "Product ID");
            tt1.SetToolTip(txtProductName, "Name of product");
            tt1.SetToolTip(txtPrice, "Price");
            
        }

        private void cbFreeService6month_CheckedChanged(object sender, EventArgs e)
        {

        }

        //close button
        private void btnClose_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Close","Do you really want to close !",MessageBoxButtons.YesNo);
            if (DialogResult.Yes.ToString()=="Yes")
            {
                Environment.Exit(0);
            }
        }
        //"ADD NEW" button
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            string id = txtProductId.Text;
            Dictionary<string, Product> productdict=null;
            productdict=FileHelper.ReadProduct();
            try
            {
                if (ValidateDetails())
                {
                    if (!productdict.ContainsKey(id))
                    {
                        Product product = new Product();
                        product.ProductId = Convert.ToInt32(txtProductId.Text);
                        product.ProductName = txtProductName.Text;
                        product.Category = category;
                        product.Price = Convert.ToInt32(txtPrice.Text);
                        product.ExpiryDate = mtbExpiryDate.ToString();
                        product.Quantity = Convert.ToInt32(nudQuantity.Value.ToString());
                        product.Description = txtDescription.Text;
                        product.Supplier = null;
                        product.Supplier += lbSupplier.SelectedItems.ToString();
                        product.Features = null;
                        if (cbFreeService1year.Checked == true)
                            product.Features += "FreeService1year";
                        if (cbFreeService6month.Checked == true)
                            product.Features += "FreeService6month";
                        if (cbInsurance.Checked == true)
                            product.Features += "Insurance";
                        if (cbPaidService.Checked == true)
                            product.Features += "PaidService";
                        if (rbCompany.Checked == true)
                            product.Service = "Company";
                        else if (rbOnsite.Checked == true)
                            product.Service = "Onsite";
                        Dictionary<string, Product> AddProduct = new Dictionary<string, Product>();
                        AddProduct.Add(id, product);
                        if (FileHelper.WriteProduct(AddProduct))
                        {
                            FileHelper.WriteProduct(AddProduct);
                            //write into file method is invoked
                            MessageBox.Show("SUCCESS");
                            ss1.Text = "Details Added";
                        }
                    }
                    else
                        MessageBox.Show("Id Duplicate");
                }
                else
                    MessageBox.Show("Enter all details");
            }
            catch
            {
                MessageBox.Show("ERROR in writing");
            }
        }

        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            category = cbCategory.ToString();
        }
        //clear form
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtProductId.Text = "";
            txtProductName.Text = "";
            txtPrice.Text = "";
            txtDescription.Text = "";
            cbCategory.SelectedValue = "";
            cbFreeService1year.Checked=false;
            cbFreeService6month.Checked=false;
            cbInsurance.Checked=false;
            lbSupplier.ClearSelected();
            cbPaidService.Checked = false;
            rbCompany.Checked = false;
            rbOnsite.Checked = false;
            nudQuantity.Value = 0;
            
        }
        //search button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string id=txtProductId.Text;
            Dictionary<string, Product> ReadProduct;
            try
            {
                ReadProduct = FileHelper.ReadProduct();
                if (ReadProduct.ContainsKey(id))
                {
                    lblMessage.Text = "PRODUCT FOUND";
                    ss1.Text = "Product Found";
                    Product product = ReadProduct[id];
                    
                    Fill(product);
                }
                else
                {
                    lblMessage.Text = "PRODUCT NOT FOUND";
                    ss1.Text = "Product Found";
                }
            }
            catch
            {
                lblMessage.Text = "ERROR in reading";
            }
        }
        //fill form
        private void Fill(Product product)
        {
            txtProductId.Text = product.ProductId.ToString();
            txtProductName.Text = product.ProductName;
            txtPrice.Text = product.Price.ToString();
            txtDescription.Text = product.Description;
            mtbExpiryDate.Text = product.ExpiryDate;
            cbCategory.SelectedValue = product.Category;
            if (product.Features.Contains("FreeService1year"))
                cbFreeService1year.Checked = true;
            if (product.Features.Contains("FreeService6month"))
                cbFreeService6month.Checked = true;
            if (product.Features.Contains("Insurance"))
                cbInsurance.Checked = true;
            if (product.Features.Contains("PaidService"))
                cbPaidService.Checked = true;
            if(product.Service.Contains("Company"))
                rbCompany.Checked = true;
            else
                rbOnsite.Checked = true;

            if (product.Supplier.ToString().Contains("Oracle"))
                lbSupplier.SetSelected(1, true);

            if (product.Supplier.ToString().Contains("Quest"))
                lbSupplier.SetSelected(0, true);

            if (product.Supplier.ToString().Contains("Others"))
                lbSupplier.SetSelected(2, true);

            nudQuantity.Value = product.Quantity;
           
        }

        private void gbProductDetails_Enter(object sender, EventArgs e)
        {

        }
        
        //validation
        private bool ValidateDetails()
        {
            try
            {
                if (txtProductId.Text == "")
                {
                    txtProductId.Focus();
                    return false;
                }
                if (txtProductName.Text == "")
                {
                    txtProductName.Focus();
                    return false;
                }
                if (txtPrice.Text == "")
                {
                    txtPrice.Focus();
                    return false;
                }
                if (txtDescription.Text == "")
                {
                    txtDescription.Focus();
                    return false;
                }
                return true; 
            }
                catch
                {
                    return false;
                }
        }

        private void cbFreeService1year_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tt1_Popup(object sender, System.Windows.Forms.PopupEventArgs e)
        {

        }
    }
}
