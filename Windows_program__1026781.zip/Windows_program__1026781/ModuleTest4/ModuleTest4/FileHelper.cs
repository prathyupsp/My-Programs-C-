﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModuleTest4.POCO;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ModuleTest4
{
    class FileHelper
    {
        //Write into a file
        public static bool WriteProduct(Dictionary<string,Product> productDetails)
        {Dictionary<string, Product> product;
            bool completed = true;
            try
            {
                    product = FileHelper.ReadProduct();
                    FileStream fstream = new FileStream("C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Windows_program__1026781\\ModuleTest4Files\\Product.data", FileMode.OpenOrCreate);
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fstream, productDetails);
                    fstream.Close();
            }
            catch
            {
                completed = false;
            }
            return completed;
        }

        //read from the file
        public static Dictionary<string, Product> ReadProduct()
        {
            Dictionary<string, Product> productDetails;
            try
            {
                FileStream fstream = new FileStream("C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Windows_program__1026781\\ModuleTest4Files\\Product.data", FileMode.OpenOrCreate);
                BinaryFormatter formatter = new BinaryFormatter();
                productDetails = (Dictionary<string, Product>)formatter.Deserialize(fstream);
                fstream.Close();
            }
            catch
            {
                productDetails = null;
            }
            return productDetails;
        }
    }
}
