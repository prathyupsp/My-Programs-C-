﻿namespace ModuleTest4
{
    partial class productDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbProductDetails = new System.Windows.Forms.GroupBox();
            this.pnlBasicDetails = new System.Windows.Forms.Panel();
            this.lblId = new System.Windows.Forms.Label();
            this.txtProductId = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.mtbExpiryDate = new System.Windows.Forms.MaskedTextBox();
            this.lblExpiry = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.nudQuantity = new System.Windows.Forms.NumericUpDown();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.lbSupplier = new System.Windows.Forms.ListBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblService = new System.Windows.Forms.Label();
            this.lblFeatures = new System.Windows.Forms.Label();
            this.cbFreeService1year = new System.Windows.Forms.CheckBox();
            this.cbFreeService6month = new System.Windows.Forms.CheckBox();
            this.cbPaidService = new System.Windows.Forms.CheckBox();
            this.cbInsurance = new System.Windows.Forms.CheckBox();
            this.rbOnsite = new System.Windows.Forms.RadioButton();
            this.rbCompany = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.tt1 = new System.Windows.Forms.ToolTip(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ss1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.gbProductDetails.SuspendLayout();
            this.pnlBasicDetails.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbProductDetails
            // 
            this.gbProductDetails.Controls.Add(this.panel3);
            this.gbProductDetails.Controls.Add(this.panel2);
            this.gbProductDetails.Controls.Add(this.panel1);
            this.gbProductDetails.Controls.Add(this.pnlBasicDetails);
            this.gbProductDetails.Location = new System.Drawing.Point(7, 7);
            this.gbProductDetails.Name = "gbProductDetails";
            this.gbProductDetails.Size = new System.Drawing.Size(406, 449);
            this.gbProductDetails.TabIndex = 0;
            this.gbProductDetails.TabStop = false;
            this.gbProductDetails.Text = "Product Details";
            this.gbProductDetails.Enter += new System.EventHandler(this.gbProductDetails_Enter);
            // 
            // pnlBasicDetails
            // 
            this.pnlBasicDetails.Controls.Add(this.lblMessage);
            this.pnlBasicDetails.Controls.Add(this.txtProductName);
            this.pnlBasicDetails.Controls.Add(this.lblProductName);
            this.pnlBasicDetails.Controls.Add(this.txtProductId);
            this.pnlBasicDetails.Controls.Add(this.lblId);
            this.pnlBasicDetails.Location = new System.Drawing.Point(8, 19);
            this.pnlBasicDetails.Name = "pnlBasicDetails";
            this.pnlBasicDetails.Size = new System.Drawing.Size(389, 71);
            this.pnlBasicDetails.TabIndex = 0;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(19, 15);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(58, 13);
            this.lblId.TabIndex = 0;
            this.lblId.Text = "Product ID";
            // 
            // txtProductId
            // 
            this.txtProductId.Location = new System.Drawing.Point(151, 12);
            this.txtProductId.Name = "txtProductId";
            this.txtProductId.Size = new System.Drawing.Size(80, 20);
            this.txtProductId.TabIndex = 1;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(151, 38);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(176, 20);
            this.txtProductName.TabIndex = 3;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(19, 41);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(75, 13);
            this.lblProductName.TabIndex = 2;
            this.lblProductName.Text = "Product Name";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblExpiry);
            this.panel1.Controls.Add(this.mtbExpiryDate);
            this.panel1.Controls.Add(this.cbCategory);
            this.panel1.Controls.Add(this.txtPrice);
            this.panel1.Controls.Add(this.lblPrice);
            this.panel1.Controls.Add(this.lblCategory);
            this.panel1.Location = new System.Drawing.Point(8, 96);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(389, 96);
            this.panel1.TabIndex = 4;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(151, 38);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(127, 20);
            this.txtPrice.TabIndex = 3;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(19, 41);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.Text = "Price";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(19, 15);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(49, 13);
            this.lblCategory.TabIndex = 0;
            this.lblCategory.Text = "Category";
            // 
            // cbCategory
            // 
            this.cbCategory.AutoCompleteCustomSource.AddRange(new string[] {
            "Home appliances",
            "others"});
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Items.AddRange(new object[] {
            "Home",
            "Others"});
            this.cbCategory.Location = new System.Drawing.Point(151, 11);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(69, 21);
            this.cbCategory.TabIndex = 4;
            this.cbCategory.SelectedIndexChanged += new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            // 
            // mtbExpiryDate
            // 
            this.mtbExpiryDate.Location = new System.Drawing.Point(151, 65);
            this.mtbExpiryDate.Mask = "00/00/0000";
            this.mtbExpiryDate.Name = "mtbExpiryDate";
            this.mtbExpiryDate.Size = new System.Drawing.Size(80, 20);
            this.mtbExpiryDate.TabIndex = 5;
            this.mtbExpiryDate.ValidatingType = typeof(System.DateTime);
            // 
            // lblExpiry
            // 
            this.lblExpiry.AutoSize = true;
            this.lblExpiry.Location = new System.Drawing.Point(19, 68);
            this.lblExpiry.Name = "lblExpiry";
            this.lblExpiry.Size = new System.Drawing.Size(61, 13);
            this.lblExpiry.TabIndex = 6;
            this.lblExpiry.Text = "Expiry Date";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbSupplier);
            this.panel2.Controls.Add(this.lblSupplier);
            this.panel2.Controls.Add(this.nudQuantity);
            this.panel2.Controls.Add(this.txtDescription);
            this.panel2.Controls.Add(this.lblDescription);
            this.panel2.Controls.Add(this.lblQuantity);
            this.panel2.Location = new System.Drawing.Point(8, 198);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(389, 137);
            this.panel2.TabIndex = 4;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(151, 38);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescription.Size = new System.Drawing.Size(176, 35);
            this.txtDescription.TabIndex = 3;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(19, 41);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(60, 13);
            this.lblDescription.TabIndex = 2;
            this.lblDescription.Text = "Description";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(19, 15);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(46, 13);
            this.lblQuantity.TabIndex = 0;
            this.lblQuantity.Text = "Quantity";
            // 
            // nudQuantity
            // 
            this.nudQuantity.Location = new System.Drawing.Point(151, 8);
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new System.Drawing.Size(100, 20);
            this.nudQuantity.TabIndex = 4;
            // 
            // lblSupplier
            // 
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Location = new System.Drawing.Point(19, 88);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(45, 13);
            this.lblSupplier.TabIndex = 5;
            this.lblSupplier.Text = "Supplier";
            // 
            // lbSupplier
            // 
            this.lbSupplier.FormattingEnabled = true;
            this.lbSupplier.Items.AddRange(new object[] {
            "Quest",
            "Oracle",
            "Others"});
            this.lbSupplier.Location = new System.Drawing.Point(150, 79);
            this.lbSupplier.Name = "lbSupplier";
            this.lbSupplier.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbSupplier.Size = new System.Drawing.Size(128, 56);
            this.lbSupplier.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rbCompany);
            this.panel3.Controls.Add(this.rbOnsite);
            this.panel3.Controls.Add(this.cbPaidService);
            this.panel3.Controls.Add(this.cbInsurance);
            this.panel3.Controls.Add(this.cbFreeService6month);
            this.panel3.Controls.Add(this.cbFreeService1year);
            this.panel3.Controls.Add(this.lblService);
            this.panel3.Controls.Add(this.lblFeatures);
            this.panel3.Location = new System.Drawing.Point(8, 341);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(389, 96);
            this.panel3.TabIndex = 4;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(19, 66);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(43, 13);
            this.lblService.TabIndex = 2;
            this.lblService.Text = "Service";
            // 
            // lblFeatures
            // 
            this.lblFeatures.AutoSize = true;
            this.lblFeatures.Location = new System.Drawing.Point(19, 15);
            this.lblFeatures.Name = "lblFeatures";
            this.lblFeatures.Size = new System.Drawing.Size(48, 13);
            this.lblFeatures.TabIndex = 0;
            this.lblFeatures.Text = "Features";
            // 
            // cbFreeService1year
            // 
            this.cbFreeService1year.AutoSize = true;
            this.cbFreeService1year.Location = new System.Drawing.Point(150, 13);
            this.cbFreeService1year.Name = "cbFreeService1year";
            this.cbFreeService1year.Size = new System.Drawing.Size(113, 17);
            this.cbFreeService1year.TabIndex = 4;
            this.cbFreeService1year.Text = "1 year free service";
            this.cbFreeService1year.UseVisualStyleBackColor = true;
            this.cbFreeService1year.CheckedChanged += new System.EventHandler(this.cbFreeService1year_CheckedChanged);
            // 
            // cbFreeService6month
            // 
            this.cbFreeService6month.AutoSize = true;
            this.cbFreeService6month.Location = new System.Drawing.Point(150, 40);
            this.cbFreeService6month.Name = "cbFreeService6month";
            this.cbFreeService6month.Size = new System.Drawing.Size(122, 17);
            this.cbFreeService6month.TabIndex = 5;
            this.cbFreeService6month.Text = "6 month free service";
            this.cbFreeService6month.UseVisualStyleBackColor = true;
            this.cbFreeService6month.CheckedChanged += new System.EventHandler(this.cbFreeService6month_CheckedChanged);
            // 
            // cbPaidService
            // 
            this.cbPaidService.AutoSize = true;
            this.cbPaidService.Location = new System.Drawing.Point(277, 40);
            this.cbPaidService.Name = "cbPaidService";
            this.cbPaidService.Size = new System.Drawing.Size(110, 17);
            this.cbPaidService.TabIndex = 7;
            this.cbPaidService.Text = "Paid Service Only";
            this.cbPaidService.UseVisualStyleBackColor = true;
            // 
            // cbInsurance
            // 
            this.cbInsurance.AutoSize = true;
            this.cbInsurance.Location = new System.Drawing.Point(277, 15);
            this.cbInsurance.Name = "cbInsurance";
            this.cbInsurance.Size = new System.Drawing.Size(73, 17);
            this.cbInsurance.TabIndex = 6;
            this.cbInsurance.Text = "Insurance";
            this.cbInsurance.UseVisualStyleBackColor = true;
            // 
            // rbOnsite
            // 
            this.rbOnsite.AutoSize = true;
            this.rbOnsite.Location = new System.Drawing.Point(151, 64);
            this.rbOnsite.Name = "rbOnsite";
            this.rbOnsite.Size = new System.Drawing.Size(55, 17);
            this.rbOnsite.TabIndex = 8;
            this.rbOnsite.TabStop = true;
            this.rbOnsite.Text = "Onsite";
            this.rbOnsite.UseVisualStyleBackColor = true;
            // 
            // rbCompany
            // 
            this.rbCompany.AutoSize = true;
            this.rbCompany.Location = new System.Drawing.Point(258, 64);
            this.rbCompany.Name = "rbCompany";
            this.rbCompany.Size = new System.Drawing.Size(69, 17);
            this.rbCompany.TabIndex = 9;
            this.rbCompany.TabStop = true;
            this.rbCompany.Text = "Company";
            this.rbCompany.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnAddNew);
            this.panel4.Controls.Add(this.btnSearch);
            this.panel4.Controls.Add(this.btnClear);
            this.panel4.Controls.Add(this.btnClose);
            this.panel4.Location = new System.Drawing.Point(8, 462);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(404, 45);
            this.panel4.TabIndex = 1;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(6, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(72, 28);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(110, 6);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(72, 28);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(212, 6);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(72, 28);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Location = new System.Drawing.Point(323, 6);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(72, 28);
            this.btnAddNew.TabIndex = 3;
            this.btnAddNew.Text = "ADD NEW";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(250, 15);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 13);
            this.lblMessage.TabIndex = 4;
            // 
            // tt1
            // 
            this.tt1.Popup += new System.Windows.Forms.PopupEventHandler(this.tt1_Popup);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ss1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 511);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(418, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // ss1
            // 
            this.ss1.Name = "ss1";
            this.ss1.Size = new System.Drawing.Size(10, 17);
            this.ss1.Text = " ";
            // 
            // productDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 533);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.gbProductDetails);
            this.Name = "productDetailsForm";
            this.Text = "PRODUCT DETAILS";
            this.gbProductDetails.ResumeLayout(false);
            this.pnlBasicDetails.ResumeLayout(false);
            this.pnlBasicDetails.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbProductDetails;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton rbCompany;
        private System.Windows.Forms.RadioButton rbOnsite;
        private System.Windows.Forms.CheckBox cbPaidService;
        private System.Windows.Forms.CheckBox cbInsurance;
        private System.Windows.Forms.CheckBox cbFreeService6month;
        private System.Windows.Forms.CheckBox cbFreeService1year;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.Label lblFeatures;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox lbSupplier;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.NumericUpDown nudQuantity;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblExpiry;
        private System.Windows.Forms.MaskedTextBox mtbExpiryDate;
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Panel pnlBasicDetails;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.TextBox txtProductId;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ToolTip tt1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel ss1;
    }
}

