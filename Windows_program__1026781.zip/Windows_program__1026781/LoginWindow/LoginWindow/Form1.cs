﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginWindow
{
    public partial class QuEST : Form
    {
        public QuEST()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if(txtUserName.Text.Equals("QUEST") && txtPassword.Text.Equals("12345"))
            {
                MessageBox.Show("Login Successfull\n Welcome  " + txtUserName.Text, "QuEST");
            }
            else
                MessageBox.Show("Wrong Username or Password", "QuEST");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
