﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FolderTreeView
{
    public partial class TreeView : Form
    {
        public TreeView()
        {
            InitializeComponent();
        }

        private void FolderTreview_Load(object sender, EventArgs e)
        {
            tvFolder.Nodes.Add("Desktop");
            tvFolder.Nodes[0].Nodes.Add("Downloads");
            tvFolder.Nodes[0].Nodes.Add("Documents");
            tvFolder.Nodes[0].Nodes[1].Nodes.Add("Visual Studio 2013");
            tvFolder.Nodes[0].Nodes[1].Nodes.Add("Projects");
            tvFolder.Nodes[0].Nodes[1].Nodes[1].Nodes.Add("program__1026781");
            tvFolder.Nodes[0].Nodes[1].Nodes[1].Nodes.Add("Windows_program__1026781");
            tvFolder.Nodes[0].Nodes[1].Nodes[1].Nodes[0].Nodes.Add("Check Prime");
            tvFolder.Nodes[0].Nodes[1].Nodes[1].Nodes[1].Nodes.Add("Count Down Timer");
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            
        }

        private void tvFolder_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void tvFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog o1=new FolderBrowserDialog();
            o1.SelectedPath = "C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\program__1026781";
        }
    }
}
