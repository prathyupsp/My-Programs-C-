﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotifyIcon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;

    notifyIcon1.BalloonTipText = "I am a NotifyIcon Balloon";

    notifyIcon1.BalloonTipTitle = "Welcome Message";



    notifyIcon1.ShowBalloonTip(1000);

        }
    }
}
