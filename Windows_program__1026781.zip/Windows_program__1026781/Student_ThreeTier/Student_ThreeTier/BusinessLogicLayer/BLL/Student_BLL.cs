﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_ThreeTier.BusinessLogicLayer.DTO;
using System.Diagnostics;
using Student_ThreeTier.DataAccessLayer;
using System.Data;

namespace Student_ThreeTier.BusinessLogicLayer.BLL
{
    class Student_BLL
    {
        //insert student method in BLL
        public static int Insert_Student(Student student)
        {
            int output = 0;
            try
            {
                //calculate total
                student.total = student.mark1 + student.mark2 + student.mark3;
                //calculate grade
                if (student.total > 200)
                    student.grade = "A";
                else if (student.total > 100)
                    student.grade = "B";
                else
                    student.grade = "F";
                //call insert method in DataAccessLayer and pass student object
                output = Student_DAO.Insert_Student(student);   
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  Student_ThreeTier.BusinessLogicLayer.BLL.Student_BLL / Insert_Student ** " + ex.Message.ToString());
            }
            return output;
        }
        //Get student method in BLL
        public static Student Get_student(int student_Id)
        {
            Student student = null;
            DataSet dataset = null;
            try
            {
                dataset = Student_DAO.Get_Student(student_Id);
                int count = dataset.Tables[0].Rows.Count;
                if(count>0)
                {
                    student = new Student();
                    student.student_id = Convert.ToInt32(dataset.Tables[0].Rows[0]["studentId"]);
                    student.mark1 = Convert.ToInt32(dataset.Tables[0].Rows[0]["mark1"]);
                    student.mark2 = Convert.ToInt32(dataset.Tables[0].Rows[0]["mark2"]);
                    student.mark3 = Convert.ToInt32(dataset.Tables[0].Rows[0]["mark3"]);
                    student.total = Convert.ToInt32(dataset.Tables[0].Rows[0]["total"]);
                    student.student_name = dataset.Tables[0].Rows[0]["studentName"].ToString();
                    student.grade = dataset.Tables[0].Rows[0]["grade"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.BusinessLogicLayer.BLL.Student_BLL / Get_student ** " + ex.Message.ToString());
            }
            return student;
        }
        //delete method
        public static int DeleteStudent(int student_id)
        {
            int output = 0;
            try
            {
                output = Student_DAO.Delete_Student(student_id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.BusinessLogicLayer.BLL.Student_BLL / DeleteStudent ** " + ex.Message.ToString());
            }
            return output;
        }


        //update method
        public static int Update_Student(Student student)
        {
            int output = 0;
            try
            {
                //calculate total
                student.total = student.mark1 + student.mark2 + student.mark3;
                //calculate grade
                if (student.total > 200)
                    student.grade = "A";
                else if (student.total > 100)
                    student.grade = "B";
                else
                    student.grade = "F";
                //call Update method in DataAccessLayer and pass student object
                output = Student_DAO.Update_Student(student);   
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  Student_ThreeTier.BusinessLogicLayer.BLL.Student_BLL / Update_Student ** " + ex.Message.ToString());
            }
            return output;
        }

        //Get All Details method in BLL
        public static DataSet Get_students()
        {
            DataSet dataset = null;
            try
            {
                dataset = Student_DAO.Get_Students();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.BusinessLogicLayer.BLL.Student_BLL / Get_students ** " + ex.Message.ToString());
            }
            return dataset;
        }

        //get details of student starting name with : method in BLL
        public static DataSet Get_students_Like(string name_like)
        {
            DataSet dataset = null;
            try
            {
                dataset = Student_DAO.Get_Student_Like(name_like);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.BusinessLogicLayer.BLL.Student_BLL / Get_students_Like ** " + ex.Message.ToString());
            }
            return dataset;
        }
    }
}