﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_ThreeTier.PresentationLayer.View;

namespace Student_ThreeTier.BusinessLogicLayer.DTO
{
    class Student
    {
        //defining properties for student variables
        public int student_id { get;  set; }
        public string student_name { get; set; }
        public int mark1 { get; set; }
        public int mark2 { get; set; }
        public int mark3 { get; set; }
        public int total { get; set; }
        public string grade { get; set; }
        //deffault constructor
        public Student()
        {
           
        }
        //parameterised constructor
        public Student(int student_id,string student_name,int mark1,int mark2,int mark3,int total,string grade)
        {
            this.student_id = student_id;
            this.student_name = student_name;
            this.mark1 = mark1;
            this.mark2 = mark2;
            this.mark3 = mark3;
            this.total = total;
            this.grade = grade;
        }

    }
}
