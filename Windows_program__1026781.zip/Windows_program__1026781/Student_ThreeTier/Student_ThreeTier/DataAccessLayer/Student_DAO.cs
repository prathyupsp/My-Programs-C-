﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Student_ThreeTier.BusinessLogicLayer.DTO;
using System.Diagnostics;
using System.Data;
namespace Student_ThreeTier.DataAccessLayer
{
    class Student_DAO
    {
        //Method to insert student details to database
        public static int Insert_Student(Student student)
        {
            int output = 0;
            string sql = "";
            try
            {
                //store insert query in string sql
                sql = "INSERT INTO tbl_student values(";
                sql += student.student_id + ",'" + student.student_name + "',";
                sql += student.mark1 + "," + student.mark2 + "," + student.mark3 + "," + student.total + ",";
                sql += "'" + student.grade + "')";
                Debug.WriteLine("Insert : " + sql);
                output = DAO.ExecuteNonQuery(sql);      //call execute method in DAO class
            }
             catch(Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.Student_DAO / Insert_Student ** " + ex.Message.ToString());
            }
            return output;
        }

        //Get student details from database
        public static DataSet Get_Student(int student_id)
        {
            DataSet dataset = null;
            string sql="";
            try
            {
                sql="SELECT * FROM tbl_student WHERE studentId=" + student_id;
                dataset = DAO.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.Student_DAO / Get_student ** " + ex.Message.ToString());
            }
            return dataset;
        }

        //Delete student details from database
        public static int Delete_Student(int student_id)
        {
            
            string sql = "";
            int output = 0;
            try
            {
                //store delete query in string sql
                sql = "DELETE FROM tbl_student WHERE studentId=" + student_id;  
                Debug.WriteLine("Delete : " + sql);
                output = DAO.ExecuteNonQuery(sql);      //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.Student_DAO / Delete_Student ** " + ex.Message.ToString());
            }
            return output;
        }

        //Update student details in database
        public static int Update_Student(Student student)
        {
            int output = 0;
            string sql = "";
            try
            {
                //store update query in string sql
                sql = "UPDATE tbl_student SET";
                sql += " studentName='" + student.student_name + "',";
                sql += " mark1=" + student.mark1 + "," + " mark2=" + student.mark2 + "," + " mark3=" + student.mark3 + "," ;
                sql += " total=" + student.total + "," + " grade='" + student.grade + "'";
                sql += " WHERE studentId=" + student.student_id;
                Debug.WriteLine("Update : " + sql);
                output = DAO.ExecuteNonQuery(sql);      //call execute method in DAO class
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.Student_DAO / Update_Student ** " + ex.Message.ToString());
            }
            return output;
        }

        //Get All details from database
        public static DataSet Get_Students()
        {
            DataSet dataset = null;
            string sql = "";
            try
            {
                sql = "SELECT * FROM tbl_student";
                dataset = DAO.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.Student_DAO / Get_Students ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //get details of student starting name with
        public static DataSet Get_Student_Like(string name_like)
        {
            DataSet dataset = null;
            string sql = "";
            try
            {
                sql = "SELECT * FROM tbl_student WHERE studentName LIKE '" + name_like + "%'";
                dataset = DAO.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.Student_DAO / Get_Student_Like ** " + ex.Message.ToString());
            }
            return dataset;
        }
    }
}
