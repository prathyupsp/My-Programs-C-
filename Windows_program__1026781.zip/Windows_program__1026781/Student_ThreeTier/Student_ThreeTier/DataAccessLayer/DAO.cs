﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;

namespace Student_ThreeTier.DataAccessLayer
{
    class DAO
    {
        //connection string for database
        static string connectionString = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Windows_program__1026781\\Student_ThreeTier\\Student_ThreeTier\\Data\\student_DB.mdf;Integrated Security=True";
        //method to execute non-queries
        public static int ExecuteNonQuery(string sql)
        {
            int output = 0;
            try
            {
                using(SqlConnection con=new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(sql, con);
                    output = cmd.ExecuteNonQuery();     //execute non-query
                }
            }
            catch(Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.DAO / ExecuteNonQuery ** " + ex.Message.ToString());
            }
            return output;
        }
        //method to execute queries
        public static DataSet ExecuteQuery(string sql)
        {
            DataSet dataset = null;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    dataset = new DataSet();
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, con);   //execute query and store result in adapter object
                    adapter.Fill(dataset);      //fill dataset (dataset as outparametr)
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.DataAccessLayer.DAO / ExecuteQuery ** " + ex.Message.ToString());
            }
            return dataset;
        }
    }
}
