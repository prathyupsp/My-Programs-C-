﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Student_ThreeTier.BusinessLogicLayer.DTO;
using Student_ThreeTier.BusinessLogicLayer.BLL;
namespace Student_ThreeTier.PresentationLayer.View
{
    public partial class Student_Form : Form
    {
        public Student_Form()
        {
            InitializeComponent();
            Disable();
            LoadStudentCombo();     //load combo box
            LoadStudentGrid();      //load grid view
            LoadStudentChart();     //load chart
        }

        private void pnlID_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        //Insert to database
        private void btnInsert_Click(object sender, EventArgs e)
        {
            Student student = null;
            int output = 0;
            try
            {
                if(Validation())        //successful validation
                {
                    student = new Student();
                    student.student_id = Convert.ToInt32(txtStudentID.Text);
                    student.student_name = txtStudentName.Text;
                    student.mark1 = Convert.ToInt32(txtMark1.Text);
                    student.mark2 = Convert.ToInt32(txtMark2.Text);
                    student.mark3 = Convert.ToInt32(txtMark3.Text);
                    output = Student_BLL.Insert_Student(student);
                    if(output>0)
                    {
                        MessageBox.Show("SUCCESS  !!", "STUDENT");
                        LoadStudentCombo();
                        LoadStudentGrid();
                        LoadStudentChart();
                    }
                    else
                    {
                        MessageBox.Show("ERROR !!!", "STUDENT");
                    }
                }
                else                   //Error in validation
                {
                    MessageBox.Show("ERROR !!!", "STUDENT");
                }
                    
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Student Id");  //format exception to handle non-integer id value
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / Insert Button ** " + ex.Message.ToString());
            }
        }
        //Method to validate inputs (checks for blank inputs)
        private bool Validation()
        {
            bool verified = true;
            try
            {
                if (txtStudentID.Text.Equals(""))
                {
                    MessageBox.Show("Student ID should not be empty", "Student");
                    txtStudentID.Focus();
                    return false;
                }
                else if (txtStudentName.Text.Equals(""))
                {
                    MessageBox.Show("Student Name should not be empty", "Student");
                    txtStudentName.Focus();
                    return false;
                }
                else if (txtMark1.Text.Equals(""))
                {
                    MessageBox.Show("Mark of Subject 1 should not be empty", "Student");
                    txtMark1.Focus();
                    return false;
                }
                else if (txtMark2.Text.Equals(""))
                {
                    MessageBox.Show("Mark of Subject 2 should not be empty", "Student");
                    txtMark2.Focus();
                    return false;
                }
                else if (txtMark3.Text.Equals(""))
                {
                    MessageBox.Show("Mark of Subject 3 should not be empty", "Student");
                    txtMark3.Focus();
                    return false;
                }
               
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / Validation ** " + ex.Message.ToString());
            }
            return verified;
        }
        //VIEW ALL button
        private void btnViewAll_Click(object sender, EventArgs e)
        {
            Student student = null;
            try
            {
                if (txtStudentID.Text.Equals(""))
                {
                    MessageBox.Show("Enter the student ID");
                    txtStudentID.Focus();
                }
                else
                {
                    int student_id = Convert.ToInt32(txtStudentID.Text);
                    student = Student_BLL.Get_student(student_id);
                    if(student!=null)
                    {
                        SetStudent(student);
                        Enable();           //Enable update and delete button and disable insert button   
                    }
                    else
                    {
                        MessageBox.Show("No such student available");
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Student Id");  //format exception to handle non-integer id value
            }
            catch(Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / btnViewAll_Click ** " + ex.Message.ToString());
            }
        }
        //fill the form with student details from object
        private void SetStudent(Student student)
        {
            try
            {
                txtStudentID.Text = student.student_id.ToString();
                txtStudentName.Text = student.student_name;
                txtMark1.Text = student.mark1.ToString();
                txtMark2.Text = student.mark2.ToString();
                txtMark3.Text = student.mark3.ToString();
                txtTotal.Text = student.total.ToString();
                txtGrade.Text = student.grade;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / SetStudent ** " + ex.Message.ToString());
            }
        }
        //delete button
        private void btnDelete_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (txtStudentID.Text.Equals(""))
                {
                    MessageBox.Show("Enter the student ID");
                    txtStudentID.Focus();
                }
                else
                {
                    int student_id = Convert.ToInt32(txtStudentID.Text);
                    if (MessageBox.Show("Do you want to Delete the Student with id : " + student_id, "STUDENT", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        //If YES button is clicked in the message box
                        output = Student_BLL.DeleteStudent(student_id);
                        if (output >= 0)
                        {
                            MessageBox.Show("Student id : " + student_id + "  Deleted Successfully");
                            Disable();      //Disable update and delete button
                            LoadStudentCombo();
                            LoadStudentGrid();
                            LoadStudentChart();
                        }
                        else
                        {
                            MessageBox.Show("No such student available");
                        }
                    }
                }
            }
            catch(FormatException)
            {
                MessageBox.Show("Invalid Student Id");  //format exception to handle non-integer id value
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / Delete button ** " + ex.Message.ToString());
            }
        }

        //update button
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Student student = null;
            int output = 0;
            try
            {
                if (Validation())        //successful validation
                {
                    student = new Student();
                    student.student_id = Convert.ToInt32(txtStudentID.Text);
                    if (MessageBox.Show("Do you want to Update the Student with id : " + student.student_id, "STUDENT", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        //if YES button in message box is clicked
                        student.student_name = txtStudentName.Text;
                        student.mark1 = Convert.ToInt32(txtMark1.Text);
                        student.mark2 = Convert.ToInt32(txtMark2.Text);
                        student.mark3 = Convert.ToInt32(txtMark3.Text);
                        output = Student_BLL.Update_Student(student);
                        if (output > 0)
                        {
                            MessageBox.Show("Student Details Updated Successfully !!", "STUDENT");
                            Disable();      //Disable update and delete button
                            LoadStudentCombo();
                            LoadStudentGrid();
                           // chtMark.Series.Clear();
                            LoadStudentChart();
                        }
                        else
                        {
                            MessageBox.Show("ERROR !!!", "STUDENT");
                        }
                    } 
                }
                else                   //Error in validation
                {
                    MessageBox.Show("ERROR !!!", "STUDENT");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Student Id");  //format exception to handle non-integer id value
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / Update Button ** " + ex.Message.ToString());
            }
        }

        private void cbStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        //clear button
        private void btnClear_Click(object sender, EventArgs e)
        {
            if(btnClear.Text.Equals("BACK"))
            {
                Disable();      //Disable update and delete button
            }
            else
                Clear();
        }
        //Disable update and delete button
        private void Disable()
        {
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnInsert.Enabled = true;
            btnClear.Text = "CLEAR";
        }
        //Enable update and delete button and disable insert button
        private void Enable()
        {
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnInsert.Enabled = false;
            btnClear.Text = "BACK";
        }
        //method to clear all fields
        private void Clear()
        {
            txtStudentID.Text = "";
            txtStudentName.Text = "";
            txtMark1.Text = "";
            txtMark2.Text = "";
            txtMark3.Text = "";
            txtTotal.Text = "";
            txtGrade.Text = "";
        }
        //mathod to load ComboBox
        private void LoadStudentCombo()
        {
            DataSet dataset=null;
            try
            { 
                dataset=Student_BLL.Get_students();
                if(dataset!=null)
                {
                    cbStudentID.DataSource = dataset.Tables[0];
                    cbStudentID.DisplayMember = "studentId";
                    cbStudentID.ValueMember = "studentId";
                }
                else
                {
                    MessageBox.Show("No student details available");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / LoadStudentCombo ** " + ex.Message.ToString());
            }
        }
        //load GridView
        private void LoadStudentGrid()
        {
            DataSet dataset = null;
            try
            {
                dataset = Student_BLL.Get_students();
                if (dataset != null)
                {
                    dgvStudent.DataSource = dataset.Tables[0];
                }
                else
                {
                    MessageBox.Show("No student details available");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / LoadStudentGrid ** " + ex.Message.ToString());
            }
        }
        private void Student_Form_Load(object sender, EventArgs e)
        {

        }
        //combo box value changed event
        private void cbStudentID_SelectedValueChanged(object sender, EventArgs e)
        {
            int student_id = 0;
            Student student = null;
            try
            {
                student_id = Convert.ToInt32(cbStudentID.SelectedValue.ToString());
                txtStudentID.Text = student_id.ToString();
                student = Student_BLL.Get_student(student_id);
                Enable();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / cbStudentID_SelectedValueChanged Event ** " + ex.Message.ToString());
            }
        }

        //clear txtNameBegins textbox
        private void btnClearNameBeg_Click(object sender, EventArgs e)
        {
            txtNameBegins.Text = "";
        }

        //text changed event for txtNameBegins textbox
        private void txtNameBegins_TextChanged(object sender, EventArgs e)
        {
            DataSet dataset = null;
            try
            {
                string name_like=txtNameBegins.Text;
                dataset = Student_BLL.Get_students_Like(name_like);
                if(dataset!=null)
                {
                    dgvStudent.DataSource = dataset.Tables[0];  //fill datagrid view
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / txtNameBegins_TextChanged Event ** " + ex.Message.ToString());
            }
        }
        //load Chart
        private void LoadStudentChart()
        {
            DataSet dataset = null;
            try
            {
                dataset = Student_BLL.Get_students();
                if (dataset != null)
                {
                    //chtMark.Series.Clear();
                    //chtMark.Series.Add("Mark");

                    foreach (var series in chtMark.Series)
                    {
                        series.Points.Clear();
                    }
                    chtMark.DataSource = dataset.Tables[0];
                    chtMark.Series["Mark"].XValueMember = "studentName";
                    chtMark.Series["Mark"].YValueMembers = "total";
                    chtMark.Titles.Add("Student Mark Details");
                }
                else
                {
                    MessageBox.Show("No student details available");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** Student_ThreeTier.PresentationLayer.View.Student_Form / LoadStudentChart ** " + ex.Message.ToString());
            }
        }

        private void chtMark_Click(object sender, EventArgs e)
        {

        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
