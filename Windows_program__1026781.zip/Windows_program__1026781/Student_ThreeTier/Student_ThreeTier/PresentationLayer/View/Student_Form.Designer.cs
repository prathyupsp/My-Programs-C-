﻿namespace Student_ThreeTier.PresentationLayer.View
{
    partial class Student_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnViewAll = new System.Windows.Forms.Button();
            this.gbStudent = new System.Windows.Forms.GroupBox();
            this.pnlID = new System.Windows.Forms.Panel();
            this.cbStudentID = new System.Windows.Forms.ComboBox();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.lblID = new System.Windows.Forms.Label();
            this.pnlName = new System.Windows.Forms.Panel();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.gbMarks = new System.Windows.Forms.GroupBox();
            this.pnlResult = new System.Windows.Forms.Panel();
            this.lblGrade = new System.Windows.Forms.Label();
            this.txtGrade = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.pnlMarks = new System.Windows.Forms.Panel();
            this.txtMark3 = new System.Windows.Forms.TextBox();
            this.lblSubj3 = new System.Windows.Forms.Label();
            this.txtMark2 = new System.Windows.Forms.TextBox();
            this.lblSubj2 = new System.Windows.Forms.Label();
            this.txtMark1 = new System.Windows.Forms.TextBox();
            this.lblSubj1 = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chtMark = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dgvStudent = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnClearNameBeg = new System.Windows.Forms.Button();
            this.txtNameBegins = new System.Windows.Forms.TextBox();
            this.lblNameBegins = new System.Windows.Forms.Label();
            this.gbStudent.SuspendLayout();
            this.pnlID.SuspendLayout();
            this.pnlName.SuspendLayout();
            this.gbMarks.SuspendLayout();
            this.pnlResult.SuspendLayout();
            this.pnlMarks.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtMark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(80, 8);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(67, 36);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(10, 8);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(67, 36);
            this.btnInsert.TabIndex = 6;
            this.btnInsert.Text = "INSERT";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(150, 8);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(67, 36);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnViewAll
            // 
            this.btnViewAll.Location = new System.Drawing.Point(220, 8);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(67, 36);
            this.btnViewAll.TabIndex = 9;
            this.btnViewAll.Text = "VIEW";
            this.btnViewAll.UseVisualStyleBackColor = true;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click);
            // 
            // gbStudent
            // 
            this.gbStudent.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gbStudent.Controls.Add(this.pnlID);
            this.gbStudent.Controls.Add(this.pnlName);
            this.gbStudent.Location = new System.Drawing.Point(12, 36);
            this.gbStudent.Name = "gbStudent";
            this.gbStudent.Size = new System.Drawing.Size(364, 83);
            this.gbStudent.TabIndex = 20;
            this.gbStudent.TabStop = false;
            this.gbStudent.Text = "Student Details";
            // 
            // pnlID
            // 
            this.pnlID.Controls.Add(this.cbStudentID);
            this.pnlID.Controls.Add(this.txtStudentID);
            this.pnlID.Controls.Add(this.lblID);
            this.pnlID.Location = new System.Drawing.Point(11, 17);
            this.pnlID.Name = "pnlID";
            this.pnlID.Size = new System.Drawing.Size(342, 26);
            this.pnlID.TabIndex = 2;
            this.pnlID.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlID_Paint);
            // 
            // cbStudentID
            // 
            this.cbStudentID.FormattingEnabled = true;
            this.cbStudentID.Location = new System.Drawing.Point(134, 2);
            this.cbStudentID.Name = "cbStudentID";
            this.cbStudentID.Size = new System.Drawing.Size(85, 21);
            this.cbStudentID.TabIndex = 27;
            this.cbStudentID.SelectedIndexChanged += new System.EventHandler(this.cbStudentID_SelectedIndexChanged);
            this.cbStudentID.SelectedValueChanged += new System.EventHandler(this.cbStudentID_SelectedValueChanged);
            // 
            // txtStudentID
            // 
            this.txtStudentID.Location = new System.Drawing.Point(254, 3);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.Size = new System.Drawing.Size(79, 20);
            this.txtStudentID.TabIndex = 1;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(5, 5);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(58, 13);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "Student ID";
            // 
            // pnlName
            // 
            this.pnlName.Controls.Add(this.txtStudentName);
            this.pnlName.Controls.Add(this.lblName);
            this.pnlName.Location = new System.Drawing.Point(11, 51);
            this.pnlName.Name = "pnlName";
            this.pnlName.Size = new System.Drawing.Size(342, 26);
            this.pnlName.TabIndex = 0;
            // 
            // txtStudentName
            // 
            this.txtStudentName.Location = new System.Drawing.Point(134, 3);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.Size = new System.Drawing.Size(199, 20);
            this.txtStudentName.TabIndex = 2;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(5, 5);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(87, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name of Student";
            // 
            // gbMarks
            // 
            this.gbMarks.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gbMarks.Controls.Add(this.pnlResult);
            this.gbMarks.Controls.Add(this.pnlMarks);
            this.gbMarks.Location = new System.Drawing.Point(12, 120);
            this.gbMarks.Name = "gbMarks";
            this.gbMarks.Size = new System.Drawing.Size(364, 114);
            this.gbMarks.TabIndex = 21;
            this.gbMarks.TabStop = false;
            this.gbMarks.Text = "MARKS DETAILS";
            // 
            // pnlResult
            // 
            this.pnlResult.Controls.Add(this.lblGrade);
            this.pnlResult.Controls.Add(this.txtGrade);
            this.pnlResult.Controls.Add(this.txtTotal);
            this.pnlResult.Controls.Add(this.lblTotal);
            this.pnlResult.Location = new System.Drawing.Point(218, 15);
            this.pnlResult.Name = "pnlResult";
            this.pnlResult.Size = new System.Drawing.Size(135, 90);
            this.pnlResult.TabIndex = 1;
            // 
            // lblGrade
            // 
            this.lblGrade.AutoSize = true;
            this.lblGrade.Location = new System.Drawing.Point(11, 66);
            this.lblGrade.Name = "lblGrade";
            this.lblGrade.Size = new System.Drawing.Size(36, 13);
            this.lblGrade.TabIndex = 19;
            this.lblGrade.Text = "Grade";
            this.lblGrade.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtGrade
            // 
            this.txtGrade.Enabled = false;
            this.txtGrade.Location = new System.Drawing.Point(59, 63);
            this.txtGrade.Name = "txtGrade";
            this.txtGrade.ReadOnly = true;
            this.txtGrade.Size = new System.Drawing.Size(65, 20);
            this.txtGrade.TabIndex = 11;
            // 
            // txtTotal
            // 
            this.txtTotal.Enabled = false;
            this.txtTotal.Location = new System.Drawing.Point(59, 9);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(67, 20);
            this.txtTotal.TabIndex = 10;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(11, 12);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(31, 13);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "Total";
            // 
            // pnlMarks
            // 
            this.pnlMarks.Controls.Add(this.txtMark3);
            this.pnlMarks.Controls.Add(this.lblSubj3);
            this.pnlMarks.Controls.Add(this.txtMark2);
            this.pnlMarks.Controls.Add(this.lblSubj2);
            this.pnlMarks.Controls.Add(this.txtMark1);
            this.pnlMarks.Controls.Add(this.lblSubj1);
            this.pnlMarks.Location = new System.Drawing.Point(10, 15);
            this.pnlMarks.Name = "pnlMarks";
            this.pnlMarks.Size = new System.Drawing.Size(179, 91);
            this.pnlMarks.TabIndex = 0;
            // 
            // txtMark3
            // 
            this.txtMark3.Location = new System.Drawing.Point(67, 60);
            this.txtMark3.Name = "txtMark3";
            this.txtMark3.Size = new System.Drawing.Size(94, 20);
            this.txtMark3.TabIndex = 5;
            // 
            // lblSubj3
            // 
            this.lblSubj3.AutoSize = true;
            this.lblSubj3.Location = new System.Drawing.Point(4, 63);
            this.lblSubj3.Name = "lblSubj3";
            this.lblSubj3.Size = new System.Drawing.Size(52, 13);
            this.lblSubj3.TabIndex = 4;
            this.lblSubj3.Text = "Subject 3";
            // 
            // txtMark2
            // 
            this.txtMark2.Location = new System.Drawing.Point(67, 34);
            this.txtMark2.Name = "txtMark2";
            this.txtMark2.Size = new System.Drawing.Size(94, 20);
            this.txtMark2.TabIndex = 4;
            // 
            // lblSubj2
            // 
            this.lblSubj2.AutoSize = true;
            this.lblSubj2.Location = new System.Drawing.Point(4, 37);
            this.lblSubj2.Name = "lblSubj2";
            this.lblSubj2.Size = new System.Drawing.Size(52, 13);
            this.lblSubj2.TabIndex = 2;
            this.lblSubj2.Text = "Subject 2";
            // 
            // txtMark1
            // 
            this.txtMark1.Location = new System.Drawing.Point(67, 8);
            this.txtMark1.Name = "txtMark1";
            this.txtMark1.Size = new System.Drawing.Size(94, 20);
            this.txtMark1.TabIndex = 3;
            // 
            // lblSubj1
            // 
            this.lblSubj1.AutoSize = true;
            this.lblSubj1.Location = new System.Drawing.Point(4, 11);
            this.lblSubj1.Name = "lblSubj1";
            this.lblSubj1.Size = new System.Drawing.Size(52, 13);
            this.lblSubj1.TabIndex = 0;
            this.lblSubj1.Text = "Subject 1";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(313, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(265, 25);
            this.lblTitle.TabIndex = 26;
            this.lblTitle.Text = "STUDENT MARKSHEET";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(290, 8);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(67, 36);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // pnlButton
            // 
            this.pnlButton.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlButton.Controls.Add(this.btnClear);
            this.pnlButton.Controls.Add(this.btnUpdate);
            this.pnlButton.Controls.Add(this.btnInsert);
            this.pnlButton.Controls.Add(this.btnDelete);
            this.pnlButton.Controls.Add(this.btnViewAll);
            this.pnlButton.Location = new System.Drawing.Point(12, 240);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(364, 54);
            this.pnlButton.TabIndex = 27;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chtMark);
            this.panel1.Controls.Add(this.dgvStudent);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(382, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(491, 458);
            this.panel1.TabIndex = 28;
            // 
            // chtMark
            // 
            chartArea1.Name = "ChartArea1";
            this.chtMark.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chtMark.Legends.Add(legend1);
            this.chtMark.Location = new System.Drawing.Point(8, 197);
            this.chtMark.Name = "chtMark";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Legend = "Legend1";
            series1.Name = "Mark";
            this.chtMark.Series.Add(series1);
            this.chtMark.Size = new System.Drawing.Size(475, 182);
            this.chtMark.TabIndex = 14;
            this.chtMark.Text = "chart1";
            this.chtMark.Click += new System.EventHandler(this.chtMark_Click);
            // 
            // dgvStudent
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStudent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStudent.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvStudent.Location = new System.Drawing.Point(8, 42);
            this.dgvStudent.Name = "dgvStudent";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStudent.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvStudent.Size = new System.Drawing.Size(475, 149);
            this.dgvStudent.TabIndex = 13;
            this.dgvStudent.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvStudent_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnClearNameBeg);
            this.panel2.Controls.Add(this.txtNameBegins);
            this.panel2.Controls.Add(this.lblNameBegins);
            this.panel2.Location = new System.Drawing.Point(7, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(478, 32);
            this.panel2.TabIndex = 12;
            // 
            // btnClearNameBeg
            // 
            this.btnClearNameBeg.Location = new System.Drawing.Point(311, 3);
            this.btnClearNameBeg.Name = "btnClearNameBeg";
            this.btnClearNameBeg.Size = new System.Drawing.Size(67, 26);
            this.btnClearNameBeg.TabIndex = 11;
            this.btnClearNameBeg.Text = "CLEAR";
            this.btnClearNameBeg.UseVisualStyleBackColor = true;
            this.btnClearNameBeg.Click += new System.EventHandler(this.btnClearNameBeg_Click);
            // 
            // txtNameBegins
            // 
            this.txtNameBegins.Location = new System.Drawing.Point(166, 6);
            this.txtNameBegins.Name = "txtNameBegins";
            this.txtNameBegins.Size = new System.Drawing.Size(122, 20);
            this.txtNameBegins.TabIndex = 6;
            this.txtNameBegins.TextChanged += new System.EventHandler(this.txtNameBegins_TextChanged);
            // 
            // lblNameBegins
            // 
            this.lblNameBegins.AutoSize = true;
            this.lblNameBegins.Location = new System.Drawing.Point(63, 10);
            this.lblNameBegins.Name = "lblNameBegins";
            this.lblNameBegins.Size = new System.Drawing.Size(95, 13);
            this.lblNameBegins.TabIndex = 1;
            this.lblNameBegins.Text = "Name Begins With";
            // 
            // Student_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(885, 505);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlButton);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.gbStudent);
            this.Controls.Add(this.gbMarks);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Student_Form";
            this.Text = "STUDENT MARKSHEET";
            this.TransparencyKey = System.Drawing.Color.DarkRed;
            this.Load += new System.EventHandler(this.Student_Form_Load);
            this.gbStudent.ResumeLayout(false);
            this.pnlID.ResumeLayout(false);
            this.pnlID.PerformLayout();
            this.pnlName.ResumeLayout(false);
            this.pnlName.PerformLayout();
            this.gbMarks.ResumeLayout(false);
            this.pnlResult.ResumeLayout(false);
            this.pnlResult.PerformLayout();
            this.pnlMarks.ResumeLayout(false);
            this.pnlMarks.PerformLayout();
            this.pnlButton.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chtMark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnViewAll;
        private System.Windows.Forms.GroupBox gbStudent;
        private System.Windows.Forms.Panel pnlID;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Panel pnlName;
        private System.Windows.Forms.TextBox txtStudentName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.GroupBox gbMarks;
        private System.Windows.Forms.Panel pnlResult;
        private System.Windows.Forms.TextBox txtGrade;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Panel pnlMarks;
        private System.Windows.Forms.Label lblSubj3;
        private System.Windows.Forms.TextBox txtMark2;
        private System.Windows.Forms.Label lblSubj2;
        private System.Windows.Forms.TextBox txtMark1;
        private System.Windows.Forms.Label lblSubj1;
        private System.Windows.Forms.Label lblGrade;
        private System.Windows.Forms.TextBox txtMark3;
        private System.Windows.Forms.ComboBox cbStudentID;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvStudent;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnClearNameBeg;
        private System.Windows.Forms.TextBox txtNameBegins;
        private System.Windows.Forms.Label lblNameBegins;
        private System.Windows.Forms.DataVisualization.Charting.Chart chtMark;
    }
}