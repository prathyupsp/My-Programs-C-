﻿namespace StudentDatabase
{
    partial class StudentDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitle = new System.Windows.Forms.Label();
            this.gbMarks = new System.Windows.Forms.GroupBox();
            this.pnlResult = new System.Windows.Forms.Panel();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtAverage = new System.Windows.Forms.TextBox();
            this.lblAverage = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.pnlMarks = new System.Windows.Forms.Panel();
            this.txtSubj6 = new System.Windows.Forms.TextBox();
            this.lblSubj6 = new System.Windows.Forms.Label();
            this.txtSubj5 = new System.Windows.Forms.TextBox();
            this.lblSubj5 = new System.Windows.Forms.Label();
            this.txtSubj4 = new System.Windows.Forms.TextBox();
            this.lblSubj4 = new System.Windows.Forms.Label();
            this.txtSubj3 = new System.Windows.Forms.TextBox();
            this.lblSubj3 = new System.Windows.Forms.Label();
            this.txtSubj2 = new System.Windows.Forms.TextBox();
            this.lblSubj2 = new System.Windows.Forms.Label();
            this.txtSubj1 = new System.Windows.Forms.TextBox();
            this.lblSubj1 = new System.Windows.Forms.Label();
            this.gbStudent = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.lblGender = new System.Windows.Forms.Label();
            this.pnlDOB = new System.Windows.Forms.Panel();
            this.dtDOB = new System.Windows.Forms.DateTimePicker();
            this.lblDOB = new System.Windows.Forms.Label();
            this.pnlID = new System.Windows.Forms.Panel();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblID = new System.Windows.Forms.Label();
            this.pnlName = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.ttNotify = new System.Windows.Forms.ToolTip(this.components);
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnShowMarks = new System.Windows.Forms.Button();
            this.gbMarks.SuspendLayout();
            this.pnlResult.SuspendLayout();
            this.pnlMarks.SuspendLayout();
            this.gbStudent.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlDOB.SuspendLayout();
            this.pnlID.SuspendLayout();
            this.pnlName.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(99, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(286, 20);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "STUDENT DETAILS COLLECTION";
            // 
            // gbMarks
            // 
            this.gbMarks.Controls.Add(this.pnlResult);
            this.gbMarks.Controls.Add(this.pnlMarks);
            this.gbMarks.Location = new System.Drawing.Point(12, 208);
            this.gbMarks.Name = "gbMarks";
            this.gbMarks.Size = new System.Drawing.Size(482, 114);
            this.gbMarks.TabIndex = 8;
            this.gbMarks.TabStop = false;
            this.gbMarks.Text = "MARKS DETAILS";
            // 
            // pnlResult
            // 
            this.pnlResult.Controls.Add(this.txtStatus);
            this.pnlResult.Controls.Add(this.txtAverage);
            this.pnlResult.Controls.Add(this.lblAverage);
            this.pnlResult.Controls.Add(this.txtTotal);
            this.pnlResult.Controls.Add(this.lblTotal);
            this.pnlResult.Location = new System.Drawing.Point(328, 16);
            this.pnlResult.Name = "pnlResult";
            this.pnlResult.Size = new System.Drawing.Size(142, 90);
            this.pnlResult.TabIndex = 1;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(8, 61);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ReadOnly = true;
            this.txtStatus.Size = new System.Drawing.Size(128, 20);
            this.txtStatus.TabIndex = 18;
            // 
            // txtAverage
            // 
            this.txtAverage.Location = new System.Drawing.Point(70, 34);
            this.txtAverage.Name = "txtAverage";
            this.txtAverage.ReadOnly = true;
            this.txtAverage.Size = new System.Drawing.Size(68, 20);
            this.txtAverage.TabIndex = 17;
            // 
            // lblAverage
            // 
            this.lblAverage.AutoSize = true;
            this.lblAverage.Location = new System.Drawing.Point(7, 37);
            this.lblAverage.Name = "lblAverage";
            this.lblAverage.Size = new System.Drawing.Size(47, 13);
            this.lblAverage.TabIndex = 4;
            this.lblAverage.Text = "Average";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(70, 8);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(68, 20);
            this.txtTotal.TabIndex = 16;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(7, 11);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(31, 13);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "Total";
            // 
            // pnlMarks
            // 
            this.pnlMarks.Controls.Add(this.txtSubj6);
            this.pnlMarks.Controls.Add(this.lblSubj6);
            this.pnlMarks.Controls.Add(this.txtSubj5);
            this.pnlMarks.Controls.Add(this.lblSubj5);
            this.pnlMarks.Controls.Add(this.txtSubj4);
            this.pnlMarks.Controls.Add(this.lblSubj4);
            this.pnlMarks.Controls.Add(this.txtSubj3);
            this.pnlMarks.Controls.Add(this.lblSubj3);
            this.pnlMarks.Controls.Add(this.txtSubj2);
            this.pnlMarks.Controls.Add(this.lblSubj2);
            this.pnlMarks.Controls.Add(this.txtSubj1);
            this.pnlMarks.Controls.Add(this.lblSubj1);
            this.pnlMarks.Location = new System.Drawing.Point(12, 16);
            this.pnlMarks.Name = "pnlMarks";
            this.pnlMarks.Size = new System.Drawing.Size(305, 91);
            this.pnlMarks.TabIndex = 0;
            // 
            // txtSubj6
            // 
            this.txtSubj6.Location = new System.Drawing.Point(220, 61);
            this.txtSubj6.Name = "txtSubj6";
            this.txtSubj6.Size = new System.Drawing.Size(68, 20);
            this.txtSubj6.TabIndex = 11;
            // 
            // lblSubj6
            // 
            this.lblSubj6.AutoSize = true;
            this.lblSubj6.Location = new System.Drawing.Point(157, 64);
            this.lblSubj6.Name = "lblSubj6";
            this.lblSubj6.Size = new System.Drawing.Size(52, 13);
            this.lblSubj6.TabIndex = 10;
            this.lblSubj6.Text = "Subject 6";
            // 
            // txtSubj5
            // 
            this.txtSubj5.Location = new System.Drawing.Point(220, 34);
            this.txtSubj5.Name = "txtSubj5";
            this.txtSubj5.Size = new System.Drawing.Size(68, 20);
            this.txtSubj5.TabIndex = 10;
            // 
            // lblSubj5
            // 
            this.lblSubj5.AutoSize = true;
            this.lblSubj5.Location = new System.Drawing.Point(157, 37);
            this.lblSubj5.Name = "lblSubj5";
            this.lblSubj5.Size = new System.Drawing.Size(52, 13);
            this.lblSubj5.TabIndex = 8;
            this.lblSubj5.Text = "Subject 5";
            // 
            // txtSubj4
            // 
            this.txtSubj4.Location = new System.Drawing.Point(220, 8);
            this.txtSubj4.Name = "txtSubj4";
            this.txtSubj4.Size = new System.Drawing.Size(68, 20);
            this.txtSubj4.TabIndex = 9;
            // 
            // lblSubj4
            // 
            this.lblSubj4.AutoSize = true;
            this.lblSubj4.Location = new System.Drawing.Point(157, 11);
            this.lblSubj4.Name = "lblSubj4";
            this.lblSubj4.Size = new System.Drawing.Size(52, 13);
            this.lblSubj4.TabIndex = 6;
            this.lblSubj4.Text = "Subject 4";
            // 
            // txtSubj3
            // 
            this.txtSubj3.Location = new System.Drawing.Point(67, 60);
            this.txtSubj3.Name = "txtSubj3";
            this.txtSubj3.Size = new System.Drawing.Size(68, 20);
            this.txtSubj3.TabIndex = 8;
            // 
            // lblSubj3
            // 
            this.lblSubj3.AutoSize = true;
            this.lblSubj3.Location = new System.Drawing.Point(4, 63);
            this.lblSubj3.Name = "lblSubj3";
            this.lblSubj3.Size = new System.Drawing.Size(52, 13);
            this.lblSubj3.TabIndex = 4;
            this.lblSubj3.Text = "Subject 3";
            // 
            // txtSubj2
            // 
            this.txtSubj2.Location = new System.Drawing.Point(67, 34);
            this.txtSubj2.Name = "txtSubj2";
            this.txtSubj2.Size = new System.Drawing.Size(68, 20);
            this.txtSubj2.TabIndex = 7;
            // 
            // lblSubj2
            // 
            this.lblSubj2.AutoSize = true;
            this.lblSubj2.Location = new System.Drawing.Point(4, 37);
            this.lblSubj2.Name = "lblSubj2";
            this.lblSubj2.Size = new System.Drawing.Size(52, 13);
            this.lblSubj2.TabIndex = 2;
            this.lblSubj2.Text = "Subject 2";
            // 
            // txtSubj1
            // 
            this.txtSubj1.Location = new System.Drawing.Point(67, 8);
            this.txtSubj1.Name = "txtSubj1";
            this.txtSubj1.Size = new System.Drawing.Size(68, 20);
            this.txtSubj1.TabIndex = 6;
            // 
            // lblSubj1
            // 
            this.lblSubj1.AutoSize = true;
            this.lblSubj1.Location = new System.Drawing.Point(4, 11);
            this.lblSubj1.Name = "lblSubj1";
            this.lblSubj1.Size = new System.Drawing.Size(52, 13);
            this.lblSubj1.TabIndex = 0;
            this.lblSubj1.Text = "Subject 1";
            // 
            // gbStudent
            // 
            this.gbStudent.Controls.Add(this.panel1);
            this.gbStudent.Controls.Add(this.pnlDOB);
            this.gbStudent.Controls.Add(this.pnlID);
            this.gbStudent.Controls.Add(this.pnlName);
            this.gbStudent.Location = new System.Drawing.Point(12, 53);
            this.gbStudent.Name = "gbStudent";
            this.gbStudent.Size = new System.Drawing.Size(482, 145);
            this.gbStudent.TabIndex = 2;
            this.gbStudent.TabStop = false;
            this.gbStudent.Text = "Student Details";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rbFemale);
            this.panel1.Controls.Add(this.rbMale);
            this.panel1.Controls.Add(this.lblGender);
            this.panel1.Location = new System.Drawing.Point(10, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(461, 26);
            this.panel1.TabIndex = 4;
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Location = new System.Drawing.Point(357, 3);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(59, 17);
            this.rbFemale.TabIndex = 5;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Location = new System.Drawing.Point(274, 3);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(48, 17);
            this.rbMale.TabIndex = 4;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(5, 5);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(42, 13);
            this.lblGender.TabIndex = 0;
            this.lblGender.Text = "Gender";
            // 
            // pnlDOB
            // 
            this.pnlDOB.Controls.Add(this.dtDOB);
            this.pnlDOB.Controls.Add(this.lblDOB);
            this.pnlDOB.Location = new System.Drawing.Point(10, 80);
            this.pnlDOB.Name = "pnlDOB";
            this.pnlDOB.Size = new System.Drawing.Size(461, 26);
            this.pnlDOB.TabIndex = 3;
            // 
            // dtDOB
            // 
            this.dtDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDOB.Location = new System.Drawing.Point(349, 3);
            this.dtDOB.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
            this.dtDOB.MinDate = new System.DateTime(1970, 1, 1, 0, 0, 0, 0);
            this.dtDOB.Name = "dtDOB";
            this.dtDOB.Size = new System.Drawing.Size(108, 20);
            this.dtDOB.TabIndex = 3;
            this.dtDOB.Value = new System.DateTime(2019, 8, 21, 15, 44, 11, 0);
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(5, 5);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(68, 13);
            this.lblDOB.TabIndex = 0;
            this.lblDOB.Text = "Date Of Birth";
            // 
            // pnlID
            // 
            this.pnlID.Controls.Add(this.txtID);
            this.pnlID.Controls.Add(this.lblID);
            this.pnlID.Location = new System.Drawing.Point(9, 48);
            this.pnlID.Name = "pnlID";
            this.pnlID.Size = new System.Drawing.Size(461, 26);
            this.pnlID.TabIndex = 2;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(297, 3);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(160, 20);
            this.txtID.TabIndex = 1;
            this.txtID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(5, 5);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(58, 13);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "Student ID";
            // 
            // pnlName
            // 
            this.pnlName.Controls.Add(this.txtName);
            this.pnlName.Controls.Add(this.lblName);
            this.pnlName.Location = new System.Drawing.Point(9, 16);
            this.pnlName.Name = "pnlName";
            this.pnlName.Size = new System.Drawing.Size(461, 26);
            this.pnlName.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(232, 3);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(225, 20);
            this.txtName.TabIndex = 2;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(5, 5);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(87, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name of Student";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(386, 342);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(90, 36);
            this.btnSubmit.TabIndex = 15;
            this.btnSubmit.Text = "SUBMIT";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click_1);
            // 
            // ttNotify
            // 
            this.ttNotify.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(184, 30);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 13);
            this.lblMessage.TabIndex = 16;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(143, 342);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(90, 36);
            this.btnSearch.TabIndex = 17;
            this.btnSearch.Text = "SEARCH USING ID";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(20, 342);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(90, 36);
            this.btnClear.TabIndex = 18;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnShowMarks
            // 
            this.btnShowMarks.Location = new System.Drawing.Point(266, 342);
            this.btnShowMarks.Name = "btnShowMarks";
            this.btnShowMarks.Size = new System.Drawing.Size(90, 36);
            this.btnShowMarks.TabIndex = 19;
            this.btnShowMarks.Text = "SHOW MARKS";
            this.btnShowMarks.UseVisualStyleBackColor = true;
            // 
            // StudentDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 425);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnShowMarks);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.gbStudent);
            this.Controls.Add(this.gbMarks);
            this.Controls.Add(this.lblTitle);
            this.Name = "StudentDatabase";
            this.Text = "STUDENT";
            this.Load += new System.EventHandler(this.StudentDatabase_Load);
            this.gbMarks.ResumeLayout(false);
            this.pnlResult.ResumeLayout(false);
            this.pnlResult.PerformLayout();
            this.pnlMarks.ResumeLayout(false);
            this.pnlMarks.PerformLayout();
            this.gbStudent.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlDOB.ResumeLayout(false);
            this.pnlDOB.PerformLayout();
            this.pnlID.ResumeLayout(false);
            this.pnlID.PerformLayout();
            this.pnlName.ResumeLayout(false);
            this.pnlName.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox gbMarks;
        private System.Windows.Forms.Panel pnlResult;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.TextBox txtAverage;
        private System.Windows.Forms.Label lblAverage;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Panel pnlMarks;
        private System.Windows.Forms.TextBox txtSubj6;
        private System.Windows.Forms.Label lblSubj6;
        private System.Windows.Forms.TextBox txtSubj5;
        private System.Windows.Forms.Label lblSubj5;
        private System.Windows.Forms.TextBox txtSubj4;
        private System.Windows.Forms.Label lblSubj4;
        private System.Windows.Forms.TextBox txtSubj3;
        private System.Windows.Forms.Label lblSubj3;
        private System.Windows.Forms.TextBox txtSubj2;
        private System.Windows.Forms.Label lblSubj2;
        private System.Windows.Forms.TextBox txtSubj1;
        private System.Windows.Forms.Label lblSubj1;
        private System.Windows.Forms.GroupBox gbStudent;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Panel pnlDOB;
        private System.Windows.Forms.DateTimePicker dtDOB;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Panel pnlID;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Panel pnlName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ToolTip ttNotify;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnShowMarks;
    }
}

