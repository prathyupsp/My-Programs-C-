﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace StudentDatabase
{
    public partial class StudentDatabase : Form
    {
        string name, id, gender, dob, status, output;
        double total, average;
        double[] mark = new double[6];
        string sql, connectionString;
        public StudentDatabase()
        {
            InitializeComponent();
            //tooltip defenitions
            ttNotify.SetToolTip(txtName, "Student Name");
            ttNotify.SetToolTip(txtID, "Student ID");
            ttNotify.SetToolTip(txtSubj1, "Mark of Subject 1");
            ttNotify.SetToolTip(txtSubj2, "Mark of Subject 2");
            ttNotify.SetToolTip(txtSubj3, "Mark of Subject 3");
            ttNotify.SetToolTip(txtSubj4, "Mark of Subject 4");
            ttNotify.SetToolTip(txtSubj5, "Mark of Subject 5");
            ttNotify.SetToolTip(txtSubj6, "Mark of Subject 6");
            ttNotify.SetToolTip(dtDOB, "Pick Date of Birth");
            ttNotify.SetToolTip(rbMale, "Male");
            ttNotify.SetToolTip(rbFemale, "FEMALE");
            ttNotify.SetToolTip(txtTotal, "TOTAL MARKS");
            ttNotify.SetToolTip(txtAverage, "AVERAGE MARKS");
            //ttNotify.SetToolTip(btnClear, "CLEAR THE FORM");
            //ttNotify.SetToolTip(btnSearch, "SEARCH STUDENT DETAILS USING ID AND SHOW THEIR DETAILS");
            //ttNotify.SetToolTip(btnShowMarks, "SEARCH STUDENT DETAILS USING ID AND SHOW THEIR MARKS DETAILS");
            //ttNotify.SetToolTip(btnSubmit, "SUBMIT AND SAVE THE DETAILS");
            //tsLabel.Text = "You started filling this form at   :   " + DateTime.Now.ToString();
        }


        private void StudentDatabase_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
            txtTotal.Text = ""; txtAverage.Text = ""; txtStatus.Text = "";

            String id = txtID.Text;
            try
            {
                //Check for invalid characters in name
                foreach (char x in txtName.Text)
                {
                    if (!((x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z')))
                    {
                        throw new InvalidNameException();
                    }
                }
                //CHECK INCOMPLETE MARK DETAILS
                if (txtSubj1.Text == "")
                {
                    throw new IncompleteException();
                }
                if (txtSubj2.Text == "")
                {
                    throw new IncompleteException();
                }
                if (txtSubj3.Text == "")
                {
                    throw new IncompleteException();
                }
                if (txtSubj4.Text == "")
                {
                    throw new IncompleteException();
                }
                if (txtSubj5.Text == "")
                {
                    throw new IncompleteException();
                }
                if (txtSubj6.Text == "")
                {
                    throw new IncompleteException();
                }
                if (CheckMOB())
                {
                    throw new MOBException();
                }

                else
                {
                    int output = 0;
                    name = txtName.Text;
                    id = txtID.Text;
                    if (rbMale.Checked == true)
                        gender = "Male";
                    else
                        gender = "Female";
                    dob = dtDOB.Value.ToShortDateString();
                    mark[0] = Convert.ToDouble(txtSubj1.Text);
                    mark[1] = Convert.ToDouble(txtSubj2.Text);
                    mark[2] = Convert.ToDouble(txtSubj3.Text);
                    mark[3] = Convert.ToDouble(txtSubj4.Text);
                    mark[4] = Convert.ToDouble(txtSubj5.Text);
                    mark[5] = Convert.ToDouble(txtSubj6.Text);
                    //finding total and average
                    total = mark[0] + mark[1] + mark[2] + mark[3] + mark[4] + mark[5];
                    txtTotal.Text = total.ToString();
                    average = Math.Round(total / 6, 2);
                    txtAverage.Text = average.ToString();
                    //check pass or fail
                    bool flagm = false;
                    for (int i = 0; i < 6; i++)
                    {
                        if (mark[i] < 40)
                            flagm = true;
                    }
                    if (flagm == true)
                        status = "FAILED";
                    else
                        status = "PASSED";
                    txtStatus.Text = status;
                    //string sql;
                    sql = "INSERT INTO tbl_studentMark values(";
                    sql += id + ",'" + name + "'," + "'" + gender + "'," + mark[0] + "," + mark[1] + "," + mark[2] + "," + mark[3] + "," + mark[4] + "," + mark[5];
                    sql += "," + total + "," + average + ",'" + status + "')";
                    connectionString = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Windows_program__1026781\\StudentDatabase\\StudentDatabase\\StudentDatabase\\DatabaseStudent.mdf;Integrated Security=True";
                    //database

                }
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    int output = 0;
                    connection.Open();
                    SqlCommand command = new SqlCommand(sql, connection);
                    output = command.ExecuteNonQuery();
                    if (output > 0)
                    {
                        lblMessage.Text = "SUCCESS";
                    }
                    else
                        lblMessage.Text = "ERROR";
                }
            }

            catch (Exception ex)
            {
                lblMessage.Text = "ERROR !!";
            }
            finally
            {

            }
        }

        //check MOB EXCEPTION
        public bool CheckMOB()
        {
            bool flagMOB = false;
            for (int i = 0; i < 6; i++)
            {
                if (mark[i] > 100 || mark[i] < 0)
                {
                    flagMOB = true;
                }
            }
            return flagMOB;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtID.Text = "";
            txtSubj1.Text = "";
            rbMale.Checked = false; rbFemale.Checked = false;
            txtSubj1.Text = "";
            txtSubj2.Text = "";
            txtSubj3.Text = "";
            txtSubj4.Text = "";
            txtSubj5.Text = "";
            txtSubj6.Text = "";
            txtTotal.Text = ""; txtAverage.Text = ""; txtStatus.Text = "";
            dtDOB.Text = DateTime.Now.ToString();
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

    }
    //exception : details are incomplete
    class IncompleteException : Exception
    {
        public IncompleteException()
        {
            string error = "ERROR!! \nENTER COMPLETE DETAILS & THEN PRESS SUBMIT BUTTON";
            MessageBox.Show(error, "ERROR !");
        }
    }

    //check for invalid name
    class InvalidNameException : Exception
    {
        public InvalidNameException()
        {
            string error = "ERROR!! INVALID NAME";
            MessageBox.Show(error, "ERROR !");
        }
    }
    //mark out of bound exception
    class MOBException : Exception
    {
        public MOBException()
        {
            string error = "Enter Valid Marks !!!! AND TRY AGAIN";
            MessageBox.Show(error, "ERROR !");
        }
    }
}
