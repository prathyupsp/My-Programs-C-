﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace StudentMarksheetSerializable
{
   
    public partial class StudentDetails : Form
    {
        private Dictionary<string, Student> StudentDictionary; 
        string name,id, gender, dob, status, output;
        double total, average;
        double[] mark = new double[6];
        public StudentDetails()
        {
            InitializeComponent();
            //tooltip defenitions
            ttNotify.SetToolTip(txtName, "Student Name");
            ttNotify.SetToolTip(txtID, "Student ID");
            ttNotify.SetToolTip(txtSubj1, "Mark of Subject 1");
            ttNotify.SetToolTip(txtSubj2, "Mark of Subject 2");
            ttNotify.SetToolTip(txtSubj3, "Mark of Subject 3");
            ttNotify.SetToolTip(txtSubj4, "Mark of Subject 4");
            ttNotify.SetToolTip(txtSubj5, "Mark of Subject 5");
            ttNotify.SetToolTip(txtSubj6, "Mark of Subject 6");
            ttNotify.SetToolTip(dtDOB, "Pick Date of Birth");
            ttNotify.SetToolTip(rbMale, "Male");
            ttNotify.SetToolTip(rbFemale, "FEMALE");
            ttNotify.SetToolTip(txtTotal, "TOTAL MARKS");
            ttNotify.SetToolTip(txtAverage, "AVERAGE MARKS");
            ttNotify.SetToolTip(btnClear, "CLEAR THE FORM");
            ttNotify.SetToolTip(btnSearch, "SEARCH STUDENT DETAILS USING ID AND SHOW THEIR DETAILS");
            ttNotify.SetToolTip(btnShowMarks, "SEARCH STUDENT DETAILS USING ID AND SHOW THEIR MARKS DETAILS");
            ttNotify.SetToolTip(btnSubmit, "SUBMIT AND SAVE THE DETAILS");
            tsLabel.Text = "You started filling this form at   :   " + DateTime.Now.ToString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void label1_Click_4(object sender, EventArgs e)
        {

        }

        private void txtTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void gbStudent_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click_5(object sender, EventArgs e)
        {

        }
        //search using id button
        private void btnVerify_Click(object sender, EventArgs e)
        {
             Dictionary<string, Student> students; 
             String id = txtID.Text; 
             try             
             {
                    students = Helper.ReadStudent();
                    if (students.ContainsKey(id))                     
                    {
                        lblMessage.Text = "ID FOUND";
                        Student student = students[id]; 
                        SetStudentDetails(student);
                    }                     
                    else                     
                    {                           
                        lblMessage.Text = "No student with this id";                     
                    } 
             }             
             catch (Exception ex)             
             {                 
                 lblMessage.Text = "ERROR !!!";             
             }  
        }
        //save to file
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            txtTotal.Text = ""; txtAverage.Text = ""; txtStatus.Text = "";
            Dictionary<string, Student> students;
            String id = txtID.Text;
            students = Helper.ReadStudent();
            if (students.ContainsKey(id))   //CHECK FOR DUPLICATE ID
            {
                MessageBox.Show("DUPLICATE DETAILS FOUND", "ERROR");
                lblMessage.Text = "DUPLICATE DETAILS FOUND";
            }
            else
            {
                try
                { 
                    //Check for invalid characters in name
                    foreach (char x in txtName.Text)
                    {
                        if (!((x >= 'a' && x <= 'z') || (x >= 'A' && x <='Z')))
                        {
                            throw new InvalidNameException();
                        }
                    }
                    //CHECK INCOMPLETE MARK DETAILS
                        if (txtSubj1.Text=="")
                        {
                            throw new IncompleteException();
                        }
                        if (txtSubj2.Text == "")
                        {
                            throw new IncompleteException();
                        }
                        if (txtSubj3.Text == "")
                        {
                            throw new IncompleteException();
                        }
                        if (txtSubj4.Text == "")
                        {
                            throw new IncompleteException();
                        }
                        if (txtSubj5.Text == "")
                        {
                            throw new IncompleteException();
                        }
                        if (txtSubj6.Text == "")
                        {
                            throw new IncompleteException();
                        }
                        if (CheckMOB())
                        {
                            throw new MOBException();
                        }
                        else
                        {
                            Calculate();
                            //CHECK NULL VALUE IN NAME, ID OR GENDER
                            if (name == null || id == null || gender == null)
                            {
                                throw new IncompleteException();
                            }
                            else
                            {
                                Student student = new Student
                                {
                                    StudentName = name,
                                    StudentId = id,
                                    Gender = gender,
                                    DOB = dob,
                                    Mark1 = mark[0].ToString(),
                                    Mark2 = mark[1].ToString(),
                                    Mark3 = mark[2].ToString(),
                                    Mark4 = mark[3].ToString(),
                                    Mark5 = mark[4].ToString(),
                                    Mark6 = mark[5].ToString(),
                                    Status = status,
                                    Total = total.ToString(),
                                    Average = average.ToString()
                                };

                                StudentDictionary = new Dictionary<string, Student>();
                                StudentDictionary.Add(id, student);      //add to dictionary        
                                if (Helper.WriteStudent(StudentDictionary))
                                {
                                    lblMessage.Text = "Details Added Successfully"; //writing to file successful
                                }
                                else
                                {
                                    lblMessage.Text = "Unsuccessful Attempt";    //error in writing                                  
                                }
                            }
                            output = "Name : " + name + "\nID : " + id + "\nGender : " + gender + "\nDOB : " + dob + "\nmarks : " + mark[0] + "  " + mark[1] + "  " +
                                    mark[2] + "  " + mark[3] + "  " + mark[4] + "  " + mark[5] + "\ntotal : " + total + "\naverage : " + average + "\n" + status;
                            MessageBox.Show(output, "STUDENT DETAILS"); //message box
                            Helper.WriteStudent(StudentDictionary); //write to file methode
                        }
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "ERROR !!";
                }
            }
        }
        //calculate total avg and status
        private void button2_Click(object sender, EventArgs e)
        {
            bool flag = true;
            try
            {
                {
                    name = txtName.Text;
                    id = txtID.Text;
                    if (rbMale.Checked == true)
                        gender = "Male";
                    else
                        gender = "Male";
                    dob = dtDOB.Value.ToShortDateString();
                    mark[0] = Convert.ToDouble(txtSubj1.Text);
                    mark[1] = Convert.ToDouble(txtSubj2.Text);
                    mark[2] = Convert.ToDouble(txtSubj3.Text);
                    mark[3] = Convert.ToDouble(txtSubj4.Text);
                    mark[4] = Convert.ToDouble(txtSubj5.Text);
                    mark[5] = Convert.ToDouble(txtSubj6.Text);
                    total = mark[0] + mark[1] + mark[2] + mark[3] + mark[4] + mark[5];
                    txtTotal.Text = total.ToString();
                    average = Math.Round(total / 6, 2);
                    txtAverage.Text = average.ToString();
                    bool flagm = false;
                    for (int i = 0; i < 6; i++)
                    {
                        if (mark[i] < 40)
                            flagm = true;
                    }
                    if (flagm == true)
                        status = "FAILED";
                    else
                        status = "PASSED";
                    txtStatus.Text = status;
                }
            }
            catch
            {

            }
        }           
        //fill form using existing data from file
        private void SetStudentDetails(Student student)
        {
            lblMessage.Text = ""; txtName.Text = student.StudentName; txtID.Text = student.StudentId;
            if (student.Gender.Contains("Male")) { rbMale.Checked = true; } else { rbFemale.Checked = true; }
            dtDOB.Text = student.DOB;
        }

        private void label1_Click_6(object sender, EventArgs e)
        {

        }
        //clear all data from the form
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            txtName.Text = ""; 
            txtID.Text = "";
            txtSubj1.Text = "";
            rbMale.Checked = false; rbFemale.Checked = false;
            txtSubj1.Text = "";
            txtSubj2.Text = "";
            txtSubj3.Text = "";
            txtSubj4.Text = "";
            txtSubj5.Text = "";
            txtSubj6.Text = "";
            txtTotal.Text = ""; txtAverage.Text = " "; txtStatus.Text = " ";
            dtDOB.Text = DateTime.Now.ToString();
        }
        //showmarks button
        private void btnShowMarks_Click(object sender, EventArgs e)
        {
            Dictionary<string, Student> students;
            String id = txtID.Text;
            try
            {
                students = Helper.ReadStudent();
                if (students.ContainsKey(id))
                {
                    lblMessage.Text = "ID FOUND";
                    Student student = students[id];
                    SetStudentMarks(student);
                }
                else
                {
                    lblMessage.Text = "No student with this id";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = "ERROR !!!";
            }  
        }
        //Display student details
        private void SetStudentMarks(Student student)
        {
            lblMessage.Text = ""; txtName.Text = student.StudentName; txtID.Text = student.StudentId;
            txtSubj1.Text = student.Mark1; txtSubj2.Text = student.Mark2;
            txtSubj3.Text = student.Mark3; txtSubj4.Text = student.Mark4;
            txtSubj5.Text = student.Mark5; txtSubj6.Text = student.Mark6;
            if (student.Gender.Contains("Male")) 
            { 
                rbMale.Checked = true; 
            } 
            else 
            { 
                rbFemale.Checked = true; 
            }
            dtDOB.Text = student.DOB;
            txtAverage.Text = student.Average;
            txtTotal.Text = student.Total;
            txtStatus.Text = student.Status;
        }
        //check pass or fail
        private void Calculate()
        {
            bool flag = true;
            try
            {
                {
                    name = txtName.Text;
                    id = txtID.Text;
                    if (rbMale.Checked == true)
                        gender = "Male";
                    else
                        gender = "Female";
                    dob = dtDOB.Value.ToShortDateString();
                    mark[0] = Convert.ToDouble(txtSubj1.Text);
                    mark[1] = Convert.ToDouble(txtSubj2.Text);
                    mark[2] = Convert.ToDouble(txtSubj3.Text);
                    mark[3] = Convert.ToDouble(txtSubj4.Text);
                    mark[4] = Convert.ToDouble(txtSubj5.Text);
                    mark[5] = Convert.ToDouble(txtSubj6.Text);
                    //finding total and average
                    total = mark[0] + mark[1] + mark[2] + mark[3] + mark[4] + mark[5];
                    txtTotal.Text = total.ToString();
                    average = Math.Round(total / 6, 2);
                    txtAverage.Text = average.ToString();
                    //check pass or fail
                    bool flagm = false;
                    for (int i = 0; i < 6; i++)
                    {
                        if (mark[i] < 40)
                            flagm = true;
                    }
                    if (flagm == true)
                        status = "FAILED";
                    else
                        status = "PASSED";
                    txtStatus.Text = status;
                }
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        
        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {
           
        }
        //check MOB EXCEPTION
        public bool CheckMOB()
        {
            bool flagMOB=false;
            for (int i = 0; i < 6; i++)
            {
                if (mark[i] > 100 || mark[i] < 0)
                {
                    flagMOB = true;
                }
            }
            return flagMOB;
        }

       

        private void txtSubj1_Leave(object sender, EventArgs e)
        {
            bool flagMOB = false;
            int mark1 =Convert.ToInt32(txtSubj1.Text.ToString());
            if (mark1 > 100 ||mark1 < 0)
                {
                   MessageBox.Show("Mark should be in between(0-100)");
                }
         }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click_1(object sender, EventArgs e)
        {

        }

        private void txtSubj1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(txtSubj1.Text);
                if (x < 0 || x > 100)
                {
                    throw new MOBException();
                }
            }
            catch(Exception)
            {
                
            }
            
        }

        private void txtSubj1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //int x = Convert.ToInt32(txtSubj1.Text);
            //if (x < 0 || x > 100)
            //{
            //    throw new MOBException();
            //}
        }

        private void txtSubj2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(txtSubj2.Text);
                if (x < 0 || x > 100)
                {
                    throw new MOBException();
                }
            }
            catch (Exception)
            {

            }
        }

        private void txtSubj3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(txtSubj3.Text);
                if (x < 0 || x > 100)
                {
                    throw new MOBException();
                }
            }
            catch (Exception)
            {

            }
        }

        private void txtSubj4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(txtSubj4.Text);
                if (x < 0 || x > 100)
                {
                    throw new MOBException();
                }
            }
            catch (Exception)
            {

            }
        }

        private void txtSubj5_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(txtSubj5.Text);
                if (x < 0 || x > 100)
                {
                    throw new MOBException();
                }
            }
            catch (Exception)
            {

            }
        }

        private void txtSubj6_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(txtSubj6.Text);
                if (x < 0 || x > 100)
                {
                    throw new MOBException();
                }
            }
            catch (Exception)
            {

            }
        } 
    }
    //exception : details are incomplete
    class IncompleteException : Exception
    {
        public IncompleteException()
        {
            string error = "ERROR!! \nENTER COMPLETE DETAILS & THEN PRESS SUBMIT BUTTON";
            MessageBox.Show(error, "ERROR !");
        }
    }
    //check for invalid name
    class InvalidNameException : Exception
    {
        public InvalidNameException()
        {
            string error = "ERROR!! INVALID NAME";
            MessageBox.Show(error, "ERROR !");
        }
    }
    //mark out of bound exception
    class MOBException : Exception
    {
        public MOBException()
        {
            string error = "Enter Valid Marks !!!! AND TRY AGAIN";
            MessageBox.Show(error, "ERROR !");
        }
    }
}
