﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentMarksheetSerializable
{
    [Serializable]
    public class Student
    {
        //static int Count = 1000;
        //properties for student
        public string StudentName { get; set; }
        public string StudentId { get; set; }
        public string Gender { get; set; }
        public string Mark1 { get; set; }
        public string Mark2 { get; set; }
        public string Mark3 { get; set; }
        public string Mark4 { get; set; }
        public string Mark5 { get; set; }
        public string Mark6 { get; set; }
        public string DOB { get; set; }
        public string Average { get; set; }
        public string Total { get; set; }
        public string Status { get; set; }
    /*    public Student()
        {
            StudentId = ++Count;
        }       */
    }
}
