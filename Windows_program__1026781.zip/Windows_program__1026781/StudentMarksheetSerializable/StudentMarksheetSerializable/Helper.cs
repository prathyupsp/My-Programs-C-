﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;        //for files
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;       //for serialization

namespace StudentMarksheetSerializable
{
    class Helper
    {
        //write to file
        public static bool WriteStudent(Dictionary<string,Student> StudentDictionary)
        {
            bool result = true;
            try
            {
                FileStream fstream = new FileStream("C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Files for program\\Student.dat", FileMode.OpenOrCreate);
                BinaryFormatter formatter = new BinaryFormatter();      //Object of binary formatter class
                formatter.Serialize(fstream, StudentDictionary);    //serialization
                fstream.Close();
            }
            catch
            {
                result = false;
            }
            return result;
        }
        //read from file
        public static Dictionary<string, Student> ReadStudent()
        {
            Dictionary<string, Student> StudentDictionary = null;
            try
            {
                FileStream fstream = new FileStream("C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Files for program\\Student.dat", FileMode.OpenOrCreate);
                BinaryFormatter formatter = new BinaryFormatter();      //Object of binary formatter class
                StudentDictionary = (Dictionary<string, Student>)formatter.Deserialize(fstream);    //deserialisation
                fstream.Close();
            }
            catch
            {
                //no catch statement
            }
            return StudentDictionary;
        }
    }
}
