﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ModuleTesthread3
{
    class Program
    {
        //main method
        static void Main(string[] args)
        {
            //object declaration
            MultiplicationTable m1=new MultiplicationTable();
            //threads defenition
            Thread thread1 = new Thread(m1.GenerateTable);
            Thread thread2 = new Thread(m1.GenerateTable);
            Thread thread3 = new Thread(m1.GenerateTable);
            Thread thread4 = new Thread(m1.GenerateTable);
            thread1.Name = "THREAD  1";
            thread2.Name = "THREAD  2";
            thread3.Name = "THREAD  3";
            thread4.Name = "THREAD  4";
            //start threads with different inputs
            thread1.Start(2);
            thread2.Start(6);
            thread3.Start(20);
            thread4.Start(5);
            Console.ReadKey();
        }
    }
    class MultiplicationTable
    {
        //variable declaration
        int number;
        //method to generate multiplication table
        public void GenerateTable(object obj1)
        {
            lock (this)     //locking Object (synchronisation)
            {
                   number = (int)obj1;
                   Console.WriteLine("***************");
                   //generate multiplication table
                    for (int iteration = 1; iteration <= 10; iteration++)
                    {
                        Console.WriteLine(number + "  x  " + iteration + "  =  " + number * iteration);
                    }
            }  
        }
    }
}
