﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace ObservableCollectionDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        ObservableCollection<Player> players = new ObservableCollection<Player>();
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this.Get_Players();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            players.Add(new Player() { ID = 104, Name = "XYZ" });
        }
        public ObservableCollection<Player> Get_Players()
        {
            players.Add(new Player(){ID=101,Name="Deepu"});
            players.Add(new Player(){ID=102,Name="ABC"});
            players.Add(new Player(){ID=103,Name="PQR"});
            return players;
        }
    }
}
