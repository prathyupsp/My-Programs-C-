﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linq_CRUD
{
    public partial class DepartmentMaster : Form
    {
        public DepartmentMaster()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            DepartmentContextDataContext context = new DepartmentContextDataContext();
            tbl_Department objDepartment = new tbl_Department();
            objDepartment.department_Id = Convert.ToInt32(txtDeptId.Text);
            objDepartment.department_Name = txtDeptName.Text;
            context.tbl_Departments.InsertOnSubmit(objDepartment);
            context.SubmitChanges();
            MessageBox.Show("Details Added Successfully");
        }
    }
}
