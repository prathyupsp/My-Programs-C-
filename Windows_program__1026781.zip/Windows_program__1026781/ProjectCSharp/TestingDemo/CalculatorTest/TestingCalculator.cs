﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestingDemo;

namespace CalculatorTest
{
    [TestClass]
    public class TestingCalculator
    {
        [TestMethod]
        public void TestAdd()
        {
            //arrange
            Calculator calculator = new Calculator();

            //act
            var result = calculator.Add(4, 8);

            //assert
            Assert.AreEqual(12, result);
        }

        [TestMethod]
        public void TestSub()
        {
            //arrange
            Calculator calculator = new Calculator();

            //act
            var result = calculator.Sub(18,13);

            //assert
            Assert.AreEqual(5, result);
        }
    }
}