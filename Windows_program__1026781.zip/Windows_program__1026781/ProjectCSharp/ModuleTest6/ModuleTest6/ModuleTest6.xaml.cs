﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ModuleTest6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer;
        string[] numbers = new string[9];
        int score = 0;
        int count = 0;
        public MainWindow()
        {
            InitializeComponent();
            for (int i = 0; i < 9; i++)
                numbers[i] = null;
            Disable();
        }
        private int i = 0;
        //start button : enable buttons and start timer
        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            timer = new DispatcherTimer();
            i = 0;
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += timer_tick;
            timer.Start();
            Clear();
            Enable();
            score = 0;
            count = 0;
        }

        //for timer
        private void timer_tick(object sender, EventArgs e)
        {
            i++;
            int hr = 0, min = 0, sec = 0;
            sec = i;
            hr = sec / 3600;
            min = (sec - hr * 3600) / 60;
            sec = sec - (min * 60) % 60;
            txtTimer.Text = hr + " Hrs  " + min + " Mins  " + sec + " Sec  ";
        }

        //refresh button
        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            Enable();
            count = 0;
        }

        //stop button :  show score and time taken
        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            int hr=0, min=0, sec=0;
            sec=i;
            hr = sec / 3600;
            min = (sec-hr*3600) / 60;
            sec = sec - (min * 60) % 60;
            MessageBox.Show("Total Score : " + score.ToString() + "\nTime Taken : " + hr + " Hrs  " + min + " Mins  " + sec + " Sec  ");
            Clear();
            Disable();
            txtTimer.Text = "";
        }

        //reset button
        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            score = 0;
            count = 0;
        }

        //Button Click Event for all buttons
        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            int index = Convert.ToInt32(btn.Name.Substring(3))-1;
            SetButton(btn);
            numbers[index] = btn.Content.ToString();
            count++;
            btn.IsEnabled = false;
            if (count > 8)
                Check();
        }

        //generate random number
        private int RandomNumber()
        {
            Random rnd = new Random();
            int val1 = rnd.Next(1, 4);
            return val1;
        }
       
        private void SetButton(Button btn)
        {
            btn.Content = RandomNumber().ToString();
        }

        //clear all
        private void Clear()
        {
            btn1.Content = "";
            btn2.Content = "";
            btn3.Content = "";
            btn4.Content = "";
            btn5.Content = "";
            btn6.Content = "";
            btn7.Content = "";
            btn8.Content = "";
            btn9.Content = "";
        }
        //enable buttons
        private void Enable()
        {
            btn1.IsEnabled = true;
            btn2.IsEnabled = true;
            btn3.IsEnabled = true;
            btn4.IsEnabled = true;
            btn5.IsEnabled = true;
            btn6.IsEnabled = true;
            btn7.IsEnabled = true;
            btn8.IsEnabled = true;
            btn9.IsEnabled = true;
        }
        //disable buttons
        private void Disable()
        {
            btn1.IsEnabled = false;
            btn2.IsEnabled = false;
            btn3.IsEnabled = false;
            btn4.IsEnabled = false;
            btn5.IsEnabled = false;
            btn6.IsEnabled = false;
            btn7.IsEnabled = false;
            btn8.IsEnabled = false;
            btn9.IsEnabled = false;
        }
        //check for score
        private void Check()
        {
            if (((numbers[0] == numbers[1])&&(numbers[0] == numbers[2])))
            {

                if (numbers[6] != null && numbers[1] != null && numbers[2] != null)
                {
                    score++;
                    
                }

            }
            if ((numbers[3] == numbers[4]) && (numbers[3] == numbers[5]))
            {

                if (numbers[3] != null && numbers[4] != null && numbers[5] != null)
                {
                    score++;
                   
                }

            }
            if ((numbers[6] == numbers[7]) && (numbers[6] == numbers[8]))
            {

                if (numbers[6] != null && numbers[7] != null && numbers[8] != null)
                {
                    score++;
                   
                }
                ;
            }
            if ((numbers[0] == numbers[3]) && (numbers[0] == numbers[6]))
            {

                if (numbers[0] != null && numbers[3] != null && numbers[6] != null)
                {
                    score++;
                   
                }
                ;
            }
            if ((numbers[1] == numbers[4]) && (numbers[1] == numbers[7]))
            {

                if (numbers[1] != null && numbers[4] != null && numbers[7] != null)
                {
                    score++;
                    
                }
                ;
            }
            if ((numbers[2] == numbers[5]) && (numbers[2] == numbers[8]))
            {

                if (numbers[2] != null && numbers[5] != null && numbers[8] != null)
                {
                    score++;
                    
                }
                ;
            }

        }
    }
}
