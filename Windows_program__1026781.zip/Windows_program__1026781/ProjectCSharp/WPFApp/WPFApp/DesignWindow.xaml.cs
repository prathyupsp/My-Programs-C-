﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFApp
{
    /// <summary>
    /// Interaction logic for DesignWindow.xaml
    /// </summary>
    public partial class DesignWindow : Window
    {
        public DesignWindow()
        {
            InitializeComponent();
        }

        private void btnApply_Click(object sender, RoutedEventArgs e)       //Event handler for Apply  button
        {
            MessageBox.Show(txtDescription.Text);
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)       //Event handler for  Reset button
        {
            cbweld.IsChecked = cbdrill.IsChecked = cbassembly.IsChecked = cbfold.IsChecked = cblaser.IsChecked = cblathe.IsChecked = cbplasma.IsChecked = cbpurchase.IsChecked = cbroll.IsChecked = cbsaw.IsChecked = false;
        }

        private void cb_Checked(object sender, RoutedEventArgs e)       //Common event handler for Checked event of all CheckBoxes
        {
            CheckBox cb = (CheckBox)sender;
            txtLength.Text += cb.Content.ToString()+" ";
        }

        private void cb_Unchecked(object sender, RoutedEventArgs e)     //Common event handler for Unchecked event of all CheckBoxes
        {
            CheckBox cb = (CheckBox)sender;
            txtLength.Text=txtLength.Text.Replace(cb.Content.ToString()+" ", null);
        }

        private void cmbFinish_SelectionChanged(object sender, SelectionChangedEventArgs e)     //Event handler for combobox selection change
        {
            if (txtNote == null)
                return;
            ComboBoxItem cbItem=(ComboBoxItem)cmbFinish.SelectedItem;
            txtNote.Text = cbItem.Content.ToString();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cmbFinish_SelectionChanged(cmbFinish, null);
        }
    }
}
