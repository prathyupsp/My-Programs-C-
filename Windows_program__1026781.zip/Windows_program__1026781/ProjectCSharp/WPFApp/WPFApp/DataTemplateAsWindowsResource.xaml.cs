﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFApp
{
    /// <summary>
    /// Interaction logic for DataTemplateAsWindowsResource.xaml
    /// </summary>
    public partial class DataTemplateAsWindowsResource : Window
    {
        public Employee emp { get; set;}
        public DataTemplateAsWindowsResource()
        {
            InitializeComponent();
            emp = new Employee();
            emp.EmployeeName = "Deepu";
            emp.EmployeeID = 10;
            this.DataContext = this;
        }
    }
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
    }
}
