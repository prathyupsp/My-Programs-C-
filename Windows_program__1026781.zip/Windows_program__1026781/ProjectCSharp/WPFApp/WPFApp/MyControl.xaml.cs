﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFApp
{
    /// <summary>
    /// Interaction logic for MyControl.xaml
    /// </summary>
    public partial class MyControl : UserControl
    {
        public MyControl()
        {
            InitializeComponent();
           
        }

        public string SetGreenText
        {
            get { return (string)GetValue(SetTextProperty); }
            set { SetValue(SetTextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SetTextProperty =
            DependencyProperty.Register("SetGreenText", typeof(string), typeof(MyControl), new PropertyMetadata("",new PropertyChangedCallback(OnSetTextC)));

        private static void OnSetTextC(DependencyObject d,DependencyPropertyChangedEventArgs e)
        {
            MyControl myControl = d as MyControl;
            myControl.OnSetTextChanged(e);
        }

        private void OnSetTextChanged(DependencyPropertyChangedEventArgs e)
        {
            txtBox1.Text = e.NewValue.ToString();
            txtBox1.Background = Brushes.Red;
            txtBox1.Foreground = Brushes.White;
        }
    }
}
