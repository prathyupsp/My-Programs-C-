﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFApp
{
    /// <summary>
    /// Interaction logic for AttachedProperty.xaml
    /// </summary>
    public partial class AttachedProperty : Window
    {
        public AttachedProperty()
        {
            InitializeComponent();
        }


        public static string GetPetName(DependencyObject obj)
        {
            return (string)obj.GetValue(PetNameProperty);
        }

        public static void SetPetName(DependencyObject obj, string value)
        {
            obj.SetValue(PetNameProperty, value);
        }

        // Using a DependencyProperty as the backing store for PetName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PetNameProperty =
            DependencyProperty.RegisterAttached("PetName", typeof(string), typeof(AttachedProperty), new PropertyMetadata());

        private void UIElement_Click(object sender, RoutedEventArgs e)
        {
            UIElement element = (UIElement)sender;
            MessageBox.Show("my pet name : " + GetPetName(element));
        }


        
    }
}
