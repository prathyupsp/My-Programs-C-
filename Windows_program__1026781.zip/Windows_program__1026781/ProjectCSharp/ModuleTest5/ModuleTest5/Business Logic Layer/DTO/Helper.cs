﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest5.Business_Logic_Layer.DTO
{
    class Helper
    {
        static string placeId = "PLA";
        static int id = 100;
        public static string GenerateId()
        {
            id++;
            string ID = placeId + id.ToString();
            return ID;
        }
    }
}
