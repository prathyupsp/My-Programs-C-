﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest5.Business_Logic_Layer.DTO
{
    class Place
    {
        public string PlaceId { get; set; }
        public string PlaceName { get; set; }
        public string PlaceType { get; set; }
        public string Description { get; set; }
        public string Connectivity { get; set; }
        public string State { get; set; }
        public string District { get; set; }
        public Place(string placeId,string placeName,string placeType, string description, string connectivity, string state, string district)
        {
            PlaceId = placeId;
            PlaceName = placeName;
            PlaceType = placeType;
            Description = description;
            Connectivity = connectivity;
            State = state;
            District = district;
        }
        public Place()
        {

        }

    }
}
