﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using ModuleTest5.Back_End.DAO;
using ModuleTest5.Business_Logic_Layer.DTO;
using System.Data;

namespace ModuleTest5.Business_Logic_Layer.BLL
{
    class Place_BLL
    {
        public static int InsertPlace(Place place)
        {
            int output = 0;
            output = Place_DAO.InsertPlace(place);
            return output;
        }
        public static int Update(Place place)
        {
            int output = 0;
            output = Place_DAO.Update(place);
            return output;
        }
        public static Place ReadPlace(string id)
        {
            Place place = null;
            DataSet dataset = Place_DAO.ReadPlace(id);
            place.PlaceId = dataset.Tables[0].Rows[0]["placeId"].ToString();
            place.PlaceName = dataset.Tables[0].Rows[0]["placeName"].ToString();
            place.PlaceType = dataset.Tables[0].Rows[0]["placeType"].ToString();
            place.Description = dataset.Tables[0].Rows[0]["description"].ToString();
            place.Connectivity = dataset.Tables[0].Rows[0]["connectivity"].ToString();
            place.State = dataset.Tables[0].Rows[0]["state"].ToString();
            place.District = dataset.Tables[0].Rows[0]["district"].ToString();
            return place;
        }
        public static DataSet ReadState()
        {
            DataSet dataset = Place_DAO.ReadState();
            return dataset;
        }
        public static DataSet ReadDistrict(int stateId)
        {
            DataSet dataset = Place_DAO.ReadDistrict(stateId);
            return dataset;
        }
    }
}
