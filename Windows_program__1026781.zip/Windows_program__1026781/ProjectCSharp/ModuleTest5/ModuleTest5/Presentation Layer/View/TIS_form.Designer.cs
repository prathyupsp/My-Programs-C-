﻿namespace ModuleTest5.Presentation_Layer.View
{
    partial class TIS_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlForm = new System.Windows.Forms.Panel();
            this.cmbPlaceId = new System.Windows.Forms.ComboBox();
            this.cmbDistrict = new System.Windows.Forms.ComboBox();
            this.lblDistrict = new System.Windows.Forms.Label();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.lblState = new System.Windows.Forms.Label();
            this.cbAir = new System.Windows.Forms.CheckBox();
            this.cbTrain = new System.Windows.Forms.CheckBox();
            this.cbSea = new System.Windows.Forms.CheckBox();
            this.cbRoad = new System.Windows.Forms.CheckBox();
            this.lblConnectivity = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.cmbPlaceType = new System.Windows.Forms.ComboBox();
            this.lblPlaceType = new System.Windows.Forms.Label();
            this.txtPlaceName = new System.Windows.Forms.TextBox();
            this.lblPlaceName = new System.Windows.Forms.Label();
            this.txtPlaceId = new System.Windows.Forms.TextBox();
            this.lblPlaceId = new System.Windows.Forms.Label();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvPlace = new System.Windows.Forms.DataGridView();
            this.cmbTypeFilter = new System.Windows.Forms.ComboBox();
            this.cmbDistrictFilter = new System.Windows.Forms.ComboBox();
            this.cmbStateFilter = new System.Windows.Forms.ComboBox();
            this.pnlTitle.SuspendLayout();
            this.pnlForm.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlace)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTitle
            // 
            this.pnlTitle.Controls.Add(this.lblTitle);
            this.pnlTitle.Location = new System.Drawing.Point(12, 2);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(348, 38);
            this.pnlTitle.TabIndex = 19;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(25, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(271, 18);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "TOURIST INFORMATION SYSTEM";
            // 
            // pnlForm
            // 
            this.pnlForm.Controls.Add(this.cmbPlaceId);
            this.pnlForm.Controls.Add(this.cmbDistrict);
            this.pnlForm.Controls.Add(this.lblDistrict);
            this.pnlForm.Controls.Add(this.cmbState);
            this.pnlForm.Controls.Add(this.lblState);
            this.pnlForm.Controls.Add(this.cbAir);
            this.pnlForm.Controls.Add(this.cbTrain);
            this.pnlForm.Controls.Add(this.cbSea);
            this.pnlForm.Controls.Add(this.cbRoad);
            this.pnlForm.Controls.Add(this.lblConnectivity);
            this.pnlForm.Controls.Add(this.txtDescription);
            this.pnlForm.Controls.Add(this.lblDescription);
            this.pnlForm.Controls.Add(this.cmbPlaceType);
            this.pnlForm.Controls.Add(this.lblPlaceType);
            this.pnlForm.Controls.Add(this.txtPlaceName);
            this.pnlForm.Controls.Add(this.lblPlaceName);
            this.pnlForm.Controls.Add(this.txtPlaceId);
            this.pnlForm.Controls.Add(this.lblPlaceId);
            this.pnlForm.Location = new System.Drawing.Point(13, 44);
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Size = new System.Drawing.Size(347, 297);
            this.pnlForm.TabIndex = 20;
            // 
            // cmbPlaceId
            // 
            this.cmbPlaceId.FormattingEnabled = true;
            this.cmbPlaceId.Location = new System.Drawing.Point(122, 5);
            this.cmbPlaceId.Name = "cmbPlaceId";
            this.cmbPlaceId.Size = new System.Drawing.Size(157, 21);
            this.cmbPlaceId.TabIndex = 18;
            // 
            // cmbDistrict
            // 
            this.cmbDistrict.FormattingEnabled = true;
            this.cmbDistrict.Location = new System.Drawing.Point(122, 235);
            this.cmbDistrict.Name = "cmbDistrict";
            this.cmbDistrict.Size = new System.Drawing.Size(157, 21);
            this.cmbDistrict.TabIndex = 17;
            this.cmbDistrict.SelectedIndexChanged += new System.EventHandler(this.cmbDistrict_SelectedIndexChanged);
            this.cmbDistrict.SelectedValueChanged += new System.EventHandler(this.cmbDistrict_SelectedValueChanged);
            // 
            // lblDistrict
            // 
            this.lblDistrict.AutoSize = true;
            this.lblDistrict.Location = new System.Drawing.Point(45, 239);
            this.lblDistrict.Name = "lblDistrict";
            this.lblDistrict.Size = new System.Drawing.Size(39, 13);
            this.lblDistrict.TabIndex = 16;
            this.lblDistrict.Text = "District";
            // 
            // cmbState
            // 
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Location = new System.Drawing.Point(122, 202);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(157, 21);
            this.cmbState.TabIndex = 15;
            this.cmbState.SelectedIndexChanged += new System.EventHandler(this.cmbState_SelectedIndexChanged);
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(45, 206);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(32, 13);
            this.lblState.TabIndex = 14;
            this.lblState.Text = "State";
            // 
            // cbAir
            // 
            this.cbAir.AutoSize = true;
            this.cbAir.Location = new System.Drawing.Point(227, 174);
            this.cbAir.Name = "cbAir";
            this.cbAir.Size = new System.Drawing.Size(38, 17);
            this.cbAir.TabIndex = 13;
            this.cbAir.Text = "Air";
            this.cbAir.UseVisualStyleBackColor = true;
            // 
            // cbTrain
            // 
            this.cbTrain.AutoSize = true;
            this.cbTrain.Location = new System.Drawing.Point(122, 174);
            this.cbTrain.Name = "cbTrain";
            this.cbTrain.Size = new System.Drawing.Size(50, 17);
            this.cbTrain.TabIndex = 12;
            this.cbTrain.Text = "Train";
            this.cbTrain.UseVisualStyleBackColor = true;
            // 
            // cbSea
            // 
            this.cbSea.AutoSize = true;
            this.cbSea.Location = new System.Drawing.Point(227, 151);
            this.cbSea.Name = "cbSea";
            this.cbSea.Size = new System.Drawing.Size(45, 17);
            this.cbSea.TabIndex = 11;
            this.cbSea.Text = "Sea";
            this.cbSea.UseVisualStyleBackColor = true;
            // 
            // cbRoad
            // 
            this.cbRoad.AutoSize = true;
            this.cbRoad.Location = new System.Drawing.Point(122, 151);
            this.cbRoad.Name = "cbRoad";
            this.cbRoad.Size = new System.Drawing.Size(52, 17);
            this.cbRoad.TabIndex = 10;
            this.cbRoad.Text = "Road";
            this.cbRoad.UseVisualStyleBackColor = true;
            // 
            // lblConnectivity
            // 
            this.lblConnectivity.AutoSize = true;
            this.lblConnectivity.Location = new System.Drawing.Point(45, 151);
            this.lblConnectivity.Name = "lblConnectivity";
            this.lblConnectivity.Size = new System.Drawing.Size(65, 13);
            this.lblConnectivity.TabIndex = 9;
            this.lblConnectivity.Text = "Connectivity";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(122, 113);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(157, 20);
            this.txtDescription.TabIndex = 8;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(45, 116);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(60, 13);
            this.lblDescription.TabIndex = 7;
            this.lblDescription.Text = "Description";
            // 
            // cmbPlaceType
            // 
            this.cmbPlaceType.FormattingEnabled = true;
            this.cmbPlaceType.Items.AddRange(new object[] {
            "Sea Shore",
            "Hilly Area",
            "Pilgrim center",
            "Historical"});
            this.cmbPlaceType.Location = new System.Drawing.Point(122, 77);
            this.cmbPlaceType.Name = "cmbPlaceType";
            this.cmbPlaceType.Size = new System.Drawing.Size(157, 21);
            this.cmbPlaceType.TabIndex = 6;
            // 
            // lblPlaceType
            // 
            this.lblPlaceType.AutoSize = true;
            this.lblPlaceType.Location = new System.Drawing.Point(45, 81);
            this.lblPlaceType.Name = "lblPlaceType";
            this.lblPlaceType.Size = new System.Drawing.Size(61, 13);
            this.lblPlaceType.TabIndex = 5;
            this.lblPlaceType.Text = "Place Type";
            // 
            // txtPlaceName
            // 
            this.txtPlaceName.Location = new System.Drawing.Point(122, 42);
            this.txtPlaceName.Name = "txtPlaceName";
            this.txtPlaceName.Size = new System.Drawing.Size(157, 20);
            this.txtPlaceName.TabIndex = 4;
            // 
            // lblPlaceName
            // 
            this.lblPlaceName.AutoSize = true;
            this.lblPlaceName.Location = new System.Drawing.Point(45, 45);
            this.lblPlaceName.Name = "lblPlaceName";
            this.lblPlaceName.Size = new System.Drawing.Size(65, 13);
            this.lblPlaceName.TabIndex = 3;
            this.lblPlaceName.Text = "Place Name";
            // 
            // txtPlaceId
            // 
            this.txtPlaceId.Location = new System.Drawing.Point(122, 6);
            this.txtPlaceId.Name = "txtPlaceId";
            this.txtPlaceId.Size = new System.Drawing.Size(157, 20);
            this.txtPlaceId.TabIndex = 2;
            // 
            // lblPlaceId
            // 
            this.lblPlaceId.AutoSize = true;
            this.lblPlaceId.Location = new System.Drawing.Point(45, 9);
            this.lblPlaceId.Name = "lblPlaceId";
            this.lblPlaceId.Size = new System.Drawing.Size(48, 13);
            this.lblPlaceId.TabIndex = 1;
            this.lblPlaceId.Text = "Place ID";
            // 
            // pnlButtons
            // 
            this.pnlButtons.Controls.Add(this.btnClose);
            this.pnlButtons.Controls.Add(this.btnSearch);
            this.pnlButtons.Controls.Add(this.btnEdit);
            this.pnlButtons.Controls.Add(this.btnNew);
            this.pnlButtons.Location = new System.Drawing.Point(13, 345);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(347, 44);
            this.pnlButtons.TabIndex = 21;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(268, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(70, 32);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(181, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(70, 32);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(94, 5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(70, 32);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "EDIT";
            this.btnEdit.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Location = new System.Drawing.Point(7, 5);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(70, 32);
            this.btnNew.TabIndex = 0;
            this.btnNew.Text = "NEW";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvPlace);
            this.panel1.Controls.Add(this.cmbTypeFilter);
            this.panel1.Controls.Add(this.cmbDistrictFilter);
            this.panel1.Controls.Add(this.cmbStateFilter);
            this.panel1.Location = new System.Drawing.Point(366, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(493, 385);
            this.panel1.TabIndex = 22;
            // 
            // dgvPlace
            // 
            this.dgvPlace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPlace.Location = new System.Drawing.Point(4, 41);
            this.dgvPlace.Name = "dgvPlace";
            this.dgvPlace.Size = new System.Drawing.Size(486, 341);
            this.dgvPlace.TabIndex = 21;
            // 
            // cmbTypeFilter
            // 
            this.cmbTypeFilter.FormattingEnabled = true;
            this.cmbTypeFilter.Location = new System.Drawing.Point(334, 7);
            this.cmbTypeFilter.Name = "cmbTypeFilter";
            this.cmbTypeFilter.Size = new System.Drawing.Size(116, 21);
            this.cmbTypeFilter.TabIndex = 20;
            this.cmbTypeFilter.Text = "TYPE";
            // 
            // cmbDistrictFilter
            // 
            this.cmbDistrictFilter.FormattingEnabled = true;
            this.cmbDistrictFilter.Location = new System.Drawing.Point(183, 7);
            this.cmbDistrictFilter.Name = "cmbDistrictFilter";
            this.cmbDistrictFilter.Size = new System.Drawing.Size(116, 21);
            this.cmbDistrictFilter.TabIndex = 19;
            this.cmbDistrictFilter.Text = "DISTRICT";
            // 
            // cmbStateFilter
            // 
            this.cmbStateFilter.FormattingEnabled = true;
            this.cmbStateFilter.Location = new System.Drawing.Point(32, 8);
            this.cmbStateFilter.Name = "cmbStateFilter";
            this.cmbStateFilter.Size = new System.Drawing.Size(116, 21);
            this.cmbStateFilter.TabIndex = 18;
            this.cmbStateFilter.Text = "STATE";
            // 
            // TIS_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 391);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlButtons);
            this.Controls.Add(this.pnlForm);
            this.Controls.Add(this.pnlTitle);
            this.Name = "TIS_form";
            this.Text = "Tourist Infromation System";
            this.Load += new System.EventHandler(this.TIS_form_Load);
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            this.pnlForm.ResumeLayout(false);
            this.pnlForm.PerformLayout();
            this.pnlButtons.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlace)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlForm;
        private System.Windows.Forms.ComboBox cmbPlaceId;
        private System.Windows.Forms.ComboBox cmbDistrict;
        private System.Windows.Forms.Label lblDistrict;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.CheckBox cbAir;
        private System.Windows.Forms.CheckBox cbTrain;
        private System.Windows.Forms.CheckBox cbSea;
        private System.Windows.Forms.CheckBox cbRoad;
        private System.Windows.Forms.Label lblConnectivity;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.ComboBox cmbPlaceType;
        private System.Windows.Forms.Label lblPlaceType;
        private System.Windows.Forms.TextBox txtPlaceName;
        private System.Windows.Forms.Label lblPlaceName;
        private System.Windows.Forms.TextBox txtPlaceId;
        private System.Windows.Forms.Label lblPlaceId;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvPlace;
        private System.Windows.Forms.ComboBox cmbTypeFilter;
        private System.Windows.Forms.ComboBox cmbDistrictFilter;
        private System.Windows.Forms.ComboBox cmbStateFilter;
    }
}