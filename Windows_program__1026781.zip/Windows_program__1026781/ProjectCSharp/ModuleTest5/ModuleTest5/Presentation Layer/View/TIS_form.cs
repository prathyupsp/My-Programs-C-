﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using ModuleTest5.Business_Logic_Layer.DTO;
using ModuleTest5.Business_Logic_Layer.BLL;

namespace ModuleTest5.Presentation_Layer.View
{
    public partial class TIS_form : Form
    {
        public TIS_form()
        {
            InitializeComponent();
            
        }

        private void TIS_form_Load(object sender, EventArgs e)
        {
            if (btnNew.Text.Equals("NEW"))
            {
                txtPlaceId.Visible = false;
                cmbPlaceId.Visible = true;
            }   
            else
            {
                txtPlaceId.Visible = false;
                cmbPlaceId.Visible = true;
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            
            int output = 0;
            
            if(btnNew.Text.Equals("NEW"))
            {
                btnNew.Text = "SAVE";
                
                try
                {
                    Clear();
                    LoadStateCombo();
                    
                }
                catch(Exception ex)
                {
                    Debug.WriteLine("ModuleTest5.Presentation_Layer.View.TIS_Form  /  new button : " + ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    cmbPlaceId.Visible = false;
                    txtPlaceId.Visible = true;
                    //txtPlaceId.Text = Helper.GenerateId();
                    //MessageBox.Show("ID Generated  : "+txtPlaceId.Text);
                    Place place = new Place();
                    place.PlaceId = Helper.GenerateId();
                    txtPlaceId.Text = place.PlaceId;
                    MessageBox.Show(place.PlaceId);
                    place.PlaceName = txtPlaceName.Text;
                    place.Description = txtDescription.Text;
                    place.District = cmbDistrict.SelectedValue.ToString();
                    place.State = cmbState.SelectedValue.ToString();
                    place.PlaceType = cmbPlaceType.SelectedItem.ToString();
                    place.Connectivity = "";
                    if (cbAir.Checked == true)
                        place.Connectivity += "Air";
                    if (cbRoad.Checked == true)
                        place.Connectivity += "Road";
                    if (cbSea.Checked == true)
                        place.Connectivity += "Sea";
                    if (cbTrain.Checked == true)
                        place.Connectivity += "Train";
                    output = Place_BLL.InsertPlace(place);
                    if (output > 0)
                    {
                        MessageBox.Show("Inserted Successfully" + "TIS");
                        btnNew.Text = "NEW";
                        Clear();
                    }
                    else
                        MessageBox.Show("ERROR !!!" + "TIS");
                   // Place_BLL.InsertPlace(place);
                    btnNew.Text = "NEW";
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("ModuleTest5.Presentation_Layer.View.TIS_Form  /  new button : " + ex.Message.ToString());
                }
                
            }
        }
        public void LoadStateCombo()
        {
            DataSet dataset=null;
            dataset=Place_BLL.ReadState();
            cmbState.DataSource = dataset.Tables[0];
            cmbState.DisplayMember = "stateName";
            cmbState.ValueMember = "stateName";
            LoadDistrictCombo(cmbState.SelectedIndex + 1);
        }
        public void Clear()
        {
            txtPlaceId.Text = "";
            txtPlaceName.Text = "";
            txtDescription.Text = "";
            cbAir.Checked = false;
            cbRoad.Checked = false;
            cbSea.Checked = false;
            cbTrain.Checked = false;
            cmbDistrict.SelectedItem = null;
            cmbState.SelectedItem = null;
            cmbPlaceType.SelectedItem = null;
        }

        private void cmbDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        public void LoadDistrictCombo(int stateId)
        {
            DataSet dataset = null;
            dataset = Place_BLL.ReadDistrict(stateId);
            cmbDistrict.DataSource = dataset.Tables[0];
            cmbDistrict.DisplayMember = "districtName";
            cmbDistrict.ValueMember = "districtName";
        }

        private void cmbDistrict_SelectedValueChanged(object sender, EventArgs e)
        {
           
        }

        private void cmbState_SelectedIndexChanged(object sender, EventArgs e)
        {
            int stateId = cmbState.SelectedIndex + 1;
            LoadDistrictCombo(stateId);
        }
    }
}
