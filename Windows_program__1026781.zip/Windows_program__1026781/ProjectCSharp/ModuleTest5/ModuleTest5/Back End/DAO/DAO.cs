﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace ModuleTest5.Back_End.DAO
{
    class DAO
    {
        static string connectionString="Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Windows_program__1026781\\ProjectCSharp\\ModuleTest5\\ModuleTest5\\DATA\\dbTouristPlaces.mdf;Integrated Security=True";
        //execute NON-Query
        public static int ExecuteNonQuery(string sql)
        {
            int output = 0;
            try
            {
                
                Debug.WriteLine("SQL  : " + sql);

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(sql, con);
                    output = cmd.ExecuteNonQuery();
                }
                
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ModuleTest5.Back_End.DAO.DAO  /  ExecuteNonQuery : " + ex.Message.ToString());
            }
            return output;
        }

        //execute Query
        public static DataSet ExecuteQuery(string sql)
        {
            DataSet dataset = new DataSet();
            Debug.WriteLine("SQL  : " + sql);
            
            using(SqlConnection con=new SqlConnection(connectionString))
            {
                con.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dataset);
            }
            return dataset;
        }
    }
}
