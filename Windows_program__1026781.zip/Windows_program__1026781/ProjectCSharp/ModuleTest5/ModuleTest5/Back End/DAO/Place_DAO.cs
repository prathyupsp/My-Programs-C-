﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using ModuleTest5.Business_Logic_Layer.DTO;
using System.Data;

namespace ModuleTest5.Back_End.DAO
{
    class Place_DAO
    {
        //insert data into table
        public static int InsertPlace(Place place)
        {
            int output = 0;
            string sql = "";
            sql = "INSERT INTO tbl_Place VALUES(";
            sql += "'" + place.PlaceId + "','" + place.PlaceName;
            sql += "','" + place.PlaceType + "','" + place.Description + "'";
            sql += ",'" + place.Connectivity + "','" + place.State;
            sql += "','" + place.District + "')";
            Debug.WriteLine("SQL  : " + sql);
            DAO.ExecuteNonQuery(sql);
            return output;
        }
        //update table
        public static int Update(Place place)
        {
            int output = 0;
            string sql = "";
            sql = "UPDATE tbl_Place SET ";
            sql += "placeId='" + place.PlaceId + "',placeName='" + place.PlaceName;
            sql += "',placeType='" + place.PlaceType + "',description='" + place.Description + "'";
            sql += ",connectivity='" + place.Connectivity + "',state='" + place.State;
            sql += "',district='" + place.District + "' WHERE placeId='"+place.PlaceId;
            
            DAO.ExecuteNonQuery(sql);
            return output;
        }
        //read from table
        public static DataSet ReadPlace(string id)
        {
            DataSet dataset = null;
            string sql = "";
            sql = "SELECT * FROM tbl_Place WHERE placeId='"+id+"'";
            
            dataset = DAO.ExecuteQuery(sql);
            return dataset;
        }
        public static DataSet ReadState()
        {
            DataSet dataset = null;
            string sql = "";
            sql = "SELECT * FROM tbl_State";
            dataset = DAO.ExecuteQuery(sql);
            return dataset;
        }
        public static DataSet ReadDistrict(int stateId)
        {
            DataSet dataset = null;
            string sql = "";
            sql = "SELECT * FROM tbl_District WHERE stateId="+stateId;
            dataset = DAO.ExecuteQuery(sql);
            return dataset;
        }
    }
}
