﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGrid_DataSet
{
    public partial class LinqLambda : Form
    {
        Student[] studentArray ={
                                 new Student(){StudentId=1,StudentName="Ahhrtyb",Age=19},
                                 new Student(){StudentId=2,StudentName="guhsxh",Age=21},
                                 new Student(){StudentId=3,StudentName="Cjhkjkj",Age=68},
                                 new Student(){StudentId=4,StudentName="gkjkjk",Age=46},
                                 new Student(){StudentId=5,StudentName="utgf",Age=17}
                             };
        public LinqLambda()
        {
            InitializeComponent();
        }

        private void btnLambda1_Click(object sender, EventArgs e)
        {
            List<Student> teenAgerStudents = studentArray.Where(s => s.Age > 12 && s.Age < 20).ToList();
            dgvLambda.DataSource = teenAgerStudents;
        }

        private void btnLambda2_Click(object sender, EventArgs e)
        {
            List<Student> teenAgerStudents = studentArray.Where(s => s.StudentName.StartsWith("g")).ToList();
            dgvLambda.DataSource = teenAgerStudents;
        }

        private void btnLambda3_Click(object sender, EventArgs e)
        {
            List<Student> teenAgerStudents = studentArray.Where(s => s.Age%2==0).ToList();
            dgvLambda.DataSource = teenAgerStudents;
        }

        private void LinqLambda_Load(object sender, EventArgs e)
        {

        }
    }
}
