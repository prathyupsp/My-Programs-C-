﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGrid_DataSet
{
    public partial class LinqDB : Form
    {
        public LinqDB()
        {
            InitializeComponent();
        }

        private void LinqDB_Load(object sender, EventArgs e)
        {
            LoadMethod();
        }

        private void LoadMethod()
        {
            LinqDbDataContext linqdbcontext = new LinqDbDataContext();
            dgvLinqDb.DataSource = from student in linqdbcontext.tbl_Students select student;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadMethod();
        }
    }
}
