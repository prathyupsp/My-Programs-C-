﻿namespace DataGrid_DataSet
{
    partial class LinqArray
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbNumbers = new System.Windows.Forms.ComboBox();
            this.cbNames = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // cbNumbers
            // 
            this.cbNumbers.FormattingEnabled = true;
            this.cbNumbers.Location = new System.Drawing.Point(108, 26);
            this.cbNumbers.Name = "cbNumbers";
            this.cbNumbers.Size = new System.Drawing.Size(121, 21);
            this.cbNumbers.TabIndex = 0;
            this.cbNumbers.SelectedIndexChanged += new System.EventHandler(this.cbNumbers_SelectedIndexChanged);
            // 
            // cbNames
            // 
            this.cbNames.FormattingEnabled = true;
            this.cbNames.Location = new System.Drawing.Point(108, 99);
            this.cbNames.Name = "cbNames";
            this.cbNames.Size = new System.Drawing.Size(121, 21);
            this.cbNames.TabIndex = 1;
            // 
            // LinqArray
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 237);
            this.Controls.Add(this.cbNames);
            this.Controls.Add(this.cbNumbers);
            this.Name = "LinqArray";
            this.Text = "LinqArray";
            this.Load += new System.EventHandler(this.LinqArray_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbNumbers;
        private System.Windows.Forms.ComboBox cbNames;
    }
}