﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGrid_DataSet
{
    public partial class LinqArray : Form
    {
        public LinqArray()
        {
            InitializeComponent();
            LoadNumbers();
            LoadNames();
        }

        private void LinqArray_Load(object sender, EventArgs e)
        {

        }
        private void LoadNumbers()
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
            var LinqQuery = from num in numbers
                            where (num % 2) == 0
                            select num;
            List<int> NumbersList = LinqQuery.ToList();
            foreach (int num in NumbersList)
                cbNumbers.Items.Add(num);
        }
        private void LoadNames()
        {
            string[] names = { "AasdsadA", "BsaderfB", "CfdghghC", "DuiuiD", "EkljklE", "FioF", "GadsdG" };
            var LinqQuery = from name in names
                            where name.Contains('d')
                            select name;

            foreach (var name in LinqQuery)
                cbNames.Items.Add(name);
        }

        private void cbNumbers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
