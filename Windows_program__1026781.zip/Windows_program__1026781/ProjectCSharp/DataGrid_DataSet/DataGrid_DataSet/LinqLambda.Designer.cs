﻿namespace DataGrid_DataSet
{
    partial class LinqLambda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvLambda = new System.Windows.Forms.DataGridView();
            this.btnLambda1 = new System.Windows.Forms.Button();
            this.btnLambda2 = new System.Windows.Forms.Button();
            this.btnLambda3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLambda)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvLambda
            // 
            this.dgvLambda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLambda.Location = new System.Drawing.Point(9, 10);
            this.dgvLambda.Name = "dgvLambda";
            this.dgvLambda.Size = new System.Drawing.Size(465, 329);
            this.dgvLambda.TabIndex = 0;
            // 
            // btnLambda1
            // 
            this.btnLambda1.Location = new System.Drawing.Point(506, 27);
            this.btnLambda1.Name = "btnLambda1";
            this.btnLambda1.Size = new System.Drawing.Size(106, 32);
            this.btnLambda1.TabIndex = 1;
            this.btnLambda1.Text = "LAMBDA 1";
            this.btnLambda1.UseVisualStyleBackColor = true;
            this.btnLambda1.Click += new System.EventHandler(this.btnLambda1_Click);
            // 
            // btnLambda2
            // 
            this.btnLambda2.Location = new System.Drawing.Point(506, 93);
            this.btnLambda2.Name = "btnLambda2";
            this.btnLambda2.Size = new System.Drawing.Size(106, 32);
            this.btnLambda2.TabIndex = 2;
            this.btnLambda2.Text = "LAMBDA 2";
            this.btnLambda2.UseVisualStyleBackColor = true;
            this.btnLambda2.Click += new System.EventHandler(this.btnLambda2_Click);
            // 
            // btnLambda3
            // 
            this.btnLambda3.Location = new System.Drawing.Point(506, 165);
            this.btnLambda3.Name = "btnLambda3";
            this.btnLambda3.Size = new System.Drawing.Size(106, 32);
            this.btnLambda3.TabIndex = 3;
            this.btnLambda3.Text = "LAMBDA 3";
            this.btnLambda3.UseVisualStyleBackColor = true;
            this.btnLambda3.Click += new System.EventHandler(this.btnLambda3_Click);
            // 
            // LinqLambda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 349);
            this.Controls.Add(this.btnLambda3);
            this.Controls.Add(this.btnLambda2);
            this.Controls.Add(this.btnLambda1);
            this.Controls.Add(this.dgvLambda);
            this.Name = "LinqLambda";
            this.Text = "LinqLambda";
            this.Load += new System.EventHandler(this.LinqLambda_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLambda)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvLambda;
        private System.Windows.Forms.Button btnLambda1;
        private System.Windows.Forms.Button btnLambda2;
        private System.Windows.Forms.Button btnLambda3;
    }
}