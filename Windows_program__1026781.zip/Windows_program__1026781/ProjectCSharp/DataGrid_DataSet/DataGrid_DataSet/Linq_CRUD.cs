﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGrid_DataSet
{
    public partial class Linq_CRUD : Form
    {
        public Linq_CRUD()
        {
            InitializeComponent();
        }

        private void Linq_CRUD_Load(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            LinqDbDataContext linqdbcontext = new LinqDbDataContext();
            tbl_Student student = new tbl_Student();
            student.Id = Convert.ToInt32(txtId.Text);
            student.name = txtName.Text;
            student.mark = Convert.ToInt32(txtTotal.Text);
            linqdbcontext.tbl_Students.InsertOnSubmit(student);
            linqdbcontext.SubmitChanges();
            MessageBox.Show("Success !");
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            new LinqDB().Show();
        }
    }
}
