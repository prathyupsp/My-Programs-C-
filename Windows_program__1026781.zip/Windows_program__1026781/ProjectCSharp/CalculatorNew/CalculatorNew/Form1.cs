﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorNew
{
    public partial class Calculator : Form
    {
        double result;
        bool flag = false;
        char operation='=';
        public Calculator()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //*************************************************************************************************************************************

        //button 0
        private void btn0_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "0";
            else
                txtDisplay.Text += "0";
        }
        //button 1
        private void btn1_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "1";
            else
                txtDisplay.Text += "1";
        }
        //button 2
        private void btn2_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "2";
            else
                txtDisplay.Text += "2";
        }
        //button 3
        private void btn3_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "3";
            else
                txtDisplay.Text += "3";
        }
        //button 4
        private void btn4_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "4";
            else
                txtDisplay.Text += "4";
        }
        //button 5
        private void btn5_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "5";
            else
                txtDisplay.Text += "5";
        }
        //button 6
        private void btn6_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "6";
            else
                txtDisplay.Text += "6";
        }
        //button 9
        private void btn9_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "9";
            else
                txtDisplay.Text += "9";
        }
        //button 8
        private void btn8_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "8";
            else
                txtDisplay.Text += "8";
        }
        private void txtDisplay_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "7";
            else
                txtDisplay.Text += "7";
        }

        private void btnDecimalPoint_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += ".";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            Check();
            operation = '+';
            txtDisplay.Text = "";
        }
        

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            
            Check();
            operation = '-';
        }

        private void btnMultiplication_Click(object sender, EventArgs e)
        {
            
            Check();
            operation = '*';
        }

        private void btnDivision_Click(object sender, EventArgs e)
        {
            
            Check();
            operation = '/';
        }
        bool change = true;
        private void Check()
        {
            if (operation == '+' && change)
            {
                result += Convert.ToDouble(txtDisplay.Text);
                //txtDisplay.Text = "";
                txtDisplay.Text = result.ToString();
                change = false;
                return;
            }

            if (operation == '-')
            {
                result -= Convert.ToDouble(txtDisplay.Text);
                //txtDisplay.Text = "";
                txtDisplay.Text = result.ToString();
            }
            if (operation == '*')
            {
                result *= Convert.ToDouble(txtDisplay.Text);
                txtDisplay.Text = "";
                txtDisplay.Text = result.ToString();
            }
            if (operation == '/')
            {
                result /= Convert.ToDouble(txtDisplay.Text);
                txtDisplay.Text = "";
                txtDisplay.Text = result.ToString();
            }
            //else
            //{
            //    result = Convert.ToDouble(txtDisplay.Text);
            //    txtDisplay.Text = "";
            //    txtDisplay.Text = result.ToString();
            //}
            else
            {

            }
            operation = '|';
        }

        private void txtDisplay_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
