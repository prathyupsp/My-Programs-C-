﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;        //for BackgroundWorker class

namespace BackgroundWorkerDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BackgroundWorker worker = new BackgroundWorker();
        private delegate void MyDelegate(int i);

        public MainWindow()
        {
            InitializeComponent();
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted+=worker_RunWorkCompleted;
        }

        private void btnBackground_Click(object sender, RoutedEventArgs e)
        {
            worker.RunWorkerAsync();
        }

        private void btnOtherWork_Click(object sender, RoutedEventArgs e)
        {
            lblOtherWork.Content = txtOtherWork.Text;
        }

        private void Display(int i)
        {
            lblBackground.Content += i.ToString() + " ";
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            for(int i=0;i<=20;i++)
            {
                System.Threading.Thread.Sleep(40);
                if(worker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }
                MyDelegate myDelegate = new MyDelegate(Display);
                lblBackground.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, myDelegate, i);
            }
        }

        private void worker_RunWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if(!e.Cancelled)
            {
                lblBackground.Content = "Work Completed ";
            }
            else
            {
                lblBackground.Content = "Work Failed !! ";
            }
        }
    }
}
