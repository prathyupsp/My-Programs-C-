﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Diagnostics;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;

namespace EmployeeManagementSystem.Data_Access_Layer.DAO
{
    class IdDetails
    {
        //query to insert data into tblID 
        public static int Insert_EmployeeID(Employee employee)
        {
            int output = 0;
            string sql = "";
            try
            {
                sql = "insert into tblID values('";
                sql += employee.employeeId + "','";
                sql += employee.govIdNo + "','Current Employee'" + ")";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);
            }
            catch (Exception ex)
            {

                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO Insert_EmployeeID " + ex.Message.ToString());
            }

            return output;
        }
       //query to update data in tblID
       public static int Update_Employee_ID(Employee employee)
        {
            int output = 0;
            string sql = "";

            try
            {

                sql = "update tblID set ";

                sql += "govIdNo='" + employee.govIdNo;
                sql += "' WHERE employeeId='" + employee.employeeId + "'";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);

            }
            catch (Exception ex)
            {

                Debug.WriteLine("*** Error:  EmployeeManagementSystem.Data_Access_Layer.DAO Update_Employee_ID " + ex.Message.ToString());


            }

            return output;
        }
    }
}
