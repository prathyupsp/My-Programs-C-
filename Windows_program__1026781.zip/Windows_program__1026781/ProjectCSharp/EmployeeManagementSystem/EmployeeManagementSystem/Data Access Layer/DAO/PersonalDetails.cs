﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using System.Data;

namespace EmployeeManagementSystem.Data_Access_Layer.DAO
{
    class PersonalDetails
    {
        //query to insert an employee into tblEmployeePersonal
        public static int Insert_Employee(Employee employee)
        {
            int output = 0;
            string sql = "";

            try
            {
                sql = "insert into tblEmployeePersonal values('";
                sql += employee.employeeId + "','" + employee.employeeName + "','" + employee.govIdType + "','";
                sql += employee.govIdNo + "','" + employee.gender + "','";
                sql += employee.dob + "','" + employee.permanentAddress + "'," + employee.permanentPin + ",'" + employee.tempAddress + "'," + employee.tempPin + ",'" + employee.personalContact + "','";
                sql += employee.emailId + "','" + employee.education + "','" + employee.skills + "','"+employee.status+"')";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO Insert_Employee " + ex.Message.ToString());
            }

            return output;
        }

        // query to Add new User 
        public static int Add_User(User user)
        {
            int output = 0;
            string sql = "";

            try
            {
                sql = "insert into tblUser values('";
                sql += user.userName + "','" + user.password + "','" + user.question + "','";
                sql += user.answer +"','" + user.userType + "')";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO Add_User " + ex.Message.ToString());
            }

            return output;
        }
        
        //query to get an employee from tblEmployeePersonal
        public static DataSet Get_Employee(int employee_id)
        {
            DataSet dataset = null;
            string sql = "";
            try
            {
                sql = "select * from tblEmployeePersonal  where employeeId='" + employee_id+"'";
                dataset = DAO.DBConnection.ExecuteQuery(sql);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO  Get_Employee " + ex.Message.ToString());
            }
            return dataset;
        }
        public static int Update_Employee(Employee employee)
        {
            int output = 0;
            string sql = "";

            try
            {
                sql = "update tblEmployeePersonal set ";
                sql += "employeeName='" + employee.employeeName + "',govIdType='" + employee.govIdType + "',govIdNo=" + employee.govIdNo + ",gender='" + employee.gender;
                sql += "',dob ='" + employee.dob + "',permanentAddress='" + employee.permanentAddress + "',permanentPin=" + employee.permanentPin + ",tempAddress='" + employee.tempAddress + "',tempPin=";
                sql += employee.tempPin + ",personalContact='" + employee.personalContact + "',emailId='" + employee.emailId + "',education='" + employee.education + "',skills='" + employee.skills + "'";
                sql += " WHERE employeeId='" + employee.employeeId+"'";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error:  EmployeeManagementSystem.Data_Access_Layer.DAO Update_Employee " + ex.Message.ToString());
            }

            return output;
        }
        public static DataSet Get_User(string  username)
        {
            DataSet dataset = null;
            string sql = "";
            try
            {
                sql = "select * from tblUser  where userName='" + username + "'";
                dataset = DAO.DBConnection.ExecuteQuery(sql);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO  Get_User " + ex.Message.ToString());
            }
            return dataset;
        }
        //update user password
        public static int Update_User(User user)
        {
            int output = 0;
            string sql = "";

            try
            {
                sql = "update tblUser set ";
                sql += "userName='" + user.userName + "', password='" + user.password + "', secQuestion='" + user.question;
                sql += "', secAnswer='" + user.answer + "'";
                sql += " WHERE userName='" + user.userName + "'";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error:  EmployeeManagementSystem.Data_Access_Layer.DAO Update_User " + ex.Message.ToString());
            }

            return output;
        }
    }
}
