﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using EmployeeManagementSystem.Data_Access_Layer.DAO;
using System.Diagnostics;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;

namespace EmployeeManagementSystem.Data_Access_Layer.DAO
{
    class ReadEmployee
    {
        //query to get all employee
        public static DataSet Get_All_Employee()
        {
            DataSet dataset = null;
            string sql = "";
            try
            {
                sql = "SELECT * FROM tblID";
                dataset = DBConnection.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_All_Employee ** " + ex.Message.ToString());
            }
            return dataset;
        }

        //Get All details of "USER" from database
        public static DataSet Get_Users()
        {
            DataSet dataset = null;
            string sql = "";
            try
            {
               sql = "SELECT * FROM tblUser";
                dataset = DBConnection.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_Users ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to get user from tblUser
        public static DataSet Get_Users_Like(string name_like)
        {
            DataSet dataset = null;
            string sql = "";
            try
            {
                sql = "SELECT * FROM tblUser WHERE userName = '" + name_like + "'";
                dataset = DBConnection.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_Users_Like ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to get employee with similar content from tblEmployeePersonal
        public static DataSet Get_Employee_Like(string like)
        {
            DataSet dataset = null;
            string sql = "SELECT * FROM tblEmployeePersonal WHERE";
            sql += like;
            try
            {
               
                dataset = DBConnection.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_Employee_Like ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to get employee data with similar content from tblProfessionalDetails
        public static DataSet Get_EmployeeProfessional_Like(string like)
        {
            DataSet dataset = null;
            string sql = "SELECT * FROM tblProfessionalDetails WHERE";
            sql += like;
            try
            {

                dataset = DBConnection.ExecuteQuery(sql);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_EmployeeProfessional_Like ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to update data in tblEmployeePersonal and tblProfessionalDetails
        public static int Update_Status( Employee employee)
        {
            int output = 0;
            string sql = "";
            try
            {
                //store update query in string sql
                sql = "UPDATE tblEmployeePersonal SET";
                sql += " status='"+employee.status+"'";
                sql += " WHERE employeeId='" + employee.employeeId + "'";
                Debug.WriteLine("Update : " + sql);
                output = DBConnection.ExecuteNonQuery(sql);      //call execute method in DAO class

                sql = "UPDATE tblID SET";
                sql += " status='" + employee.status + "'";
                sql += " WHERE employeeId='" + employee.employeeId + "'";
                Debug.WriteLine("Update : " + sql);
                output = DBConnection.ExecuteNonQuery(sql);

                sql = "UPDATE tblProfessionalDetails SET";
                sql += " status='" + employee.status + "'";
                sql += " WHERE employeeId='" + employee.employeeId + "'";
                Debug.WriteLine("Update : " + sql);
                output = DBConnection.ExecuteNonQuery(sql);   
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Update_employee_Status ** " + ex.Message.ToString());
            }
            return output;
        }
        //query to delete an user from tblUser
        public static int Delete_User(string username)
        {
            string sql = "";
            int output = 0;
            try
            {
                //store delete query in string sql
                sql = "DELETE FROM tblUser WHERE userName='" + username + "'";
                Debug.WriteLine("Delete : " + sql);
                output = DBConnection.ExecuteNonQuery(sql);      //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Delete_User ** " + ex.Message.ToString());
            }
            return output;
        }
        //query to get employee data from tblEmployeePersonal
        public static DataSet Get_EmployeePersonal(string employee_id)
        {
            DataSet dataset = null;
            string sql1 = "";
            try
            {
                sql1 = "SELECT * FROM tblEmployeePersonal WHERE employeeId='" + employee_id+"'";
                dataset = DBConnection.ExecuteQuery(sql1);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_EmployeePersonal ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to get employee data from tblProfessionalDetails
        public static DataSet Get_EmployeeProfessional(string employee_id)
        {
            DataSet dataset = null;
            string sql1 = "";
            try
            {
                sql1 = "SELECT * FROM tblProfessionalDetails WHERE employeeId='" + employee_id + "'";
                dataset = DBConnection.ExecuteQuery(sql1);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_EmployeeProfessional ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to get id from tblID
        public static DataSet Get_Id(string employee_id)
        {
            DataSet dataset = null;
            string sql1 = "";
            try
            {
                sql1 = "SELECT * FROM tblID WHERE employeeId='" + employee_id + "'";
                dataset = DBConnection.ExecuteQuery(sql1);        //execute query and store result in dataset
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Data_Access_Layer.DAO.ReadEmployee / Get_Id ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to update data of an employee
        public static int Update_Employee(Employee employee)
        {
            int output1 = 0;
            int output2 = 0;
            int output = 0;
            string sql1 = "";
            string sql2 = "";
            try
            {
                sql1 = "update tblEmployeePersonal set employeeName='";
                sql1 += employee.employeeName + "',govIdType='" + employee.govIdType + "',govIdNo='" + employee.govIdNo + "',gender='" + employee.gender + "',dob='";
                sql1 += employee.dob + "',permanentAddress='" + employee.permanentAddress + "',permanentPin=" + employee.permanentPin + ",tempAddress='" + employee.tempAddress;
                sql1 += "',tempPin=" + employee.tempPin + ",personalContact='" + employee.personalContact + "',emailId='" + employee.emailId + "',education='" + employee.education + "',skills='" + employee.skills + "' where employeeId='"+employee.employeeId+"'";
                Debug.WriteLine("SQL: " + sql1);
                output1 = DBConnection.ExecuteNonQuery(sql1);

                sql2 = "update tblProfessionalDetails set designation='";
                sql2 += employee.designation + "',ctc=" + employee.ctc + ",jobLocation='" + employee.jobLocation + "',officialContact='" + employee.officialContact + "' where employeeId='" + employee.employeeId + "'";
                output2 = DBConnection.ExecuteNonQuery(sql2);
                Debug.WriteLine("SQL: " + sql2);
                output = output1 * output2;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("***Error: EmployeeManagementSystem.Data_Access_Layer.DAO   Update_Employee" + ex.Message.ToString());

            }
            return output;
        }
    }
}
