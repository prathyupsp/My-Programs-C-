﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace EmployeeManagementSystem.Data_Access_Layer.DAO
{
    class DBConnection
    {
        static string connectionString = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Windows_program__1026781\\ProjectCSharp\\EmployeeManagementSystem\\EmployeeManagementSystem\\DATA\\EmployeeDatabase.mdf;Integrated Security=True";
        //method to execute NonQuery
        public static int ExecuteNonQuery(String sql)
        {

            int output = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(sql, con);
                    output = cmd.ExecuteNonQuery();
                    Debug.WriteLine(sql);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO ExecuteNonQuery " + ex.Message.ToString());
            }

            return output;
        }
        //method to execute query
        public static DataSet ExecuteQuery(String sql)
        {

            DataSet dataSet = null;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                    con.Open();
                    dataSet = new DataSet();

                    SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                    adapter.Fill(dataSet);
                    Debug.WriteLine(sql);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO  ExecuteQuery " + ex.Message.ToString());
            }
            return dataSet;
        }

    }
}
