﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using System.Data;

namespace EmployeeManagementSystem.Data_Access_Layer.DAO
{
    class ProfessionalDetails
    {
        //query to insert data into tblProfessionalDetails
        public static int Insert_Employee(Employee employee)
        {
            int output = 0;
            string sql = "";

            try
            {

                sql = "insert into tblProfessionalDetails values('";
                sql += employee.employeeId + "','" + employee.designation + "'," + employee.ctc + ",'";
                sql += employee.jobLocation + "','" + employee.officialContact +"', '"+employee.status+"')";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);

            }
            catch (Exception ex)
            {

                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO Insert_Employee " + ex.Message.ToString());            }

            return output;
        }
        //query to get emolyee data from tblProfessionalDetails
        public static DataSet Get_Employee(int employee_id)
        {
            DataSet dataset = null;
            string sql = "";
            try
            {                sql = "select * from tblProfessionalDetails  where employeeId='" + employee_id+"'";
                dataset = DAO.DBConnection.ExecuteQuery(sql);
            }
            catch (Exception ex)
            {

                Debug.WriteLine("*** Error: EmployeeManagementSystem.Data_Access_Layer.DAO  Get_Employee " + ex.Message.ToString());
            }
            return dataset;
        }
        //query to update details in tblProfessionalDetails
        public static int Update_Employee(Employee employee)
        {
            int output = 0;
            string sql = "";

            try
            {

                sql = "update tblProfessionalDetails set ";
               
                sql += "designation='" + employee.designation + "',ctc=" + employee.ctc + ",jobLocation='" + employee.jobLocation + "',officialContact='" + employee.officialContact;
                sql += "' WHERE employeeId='" + employee.employeeId + "'";
                Debug.WriteLine("SQL: " + sql);
                output = DAO.DBConnection.ExecuteNonQuery(sql);

            }
            catch (Exception ex)
            {

                Debug.WriteLine("*** Error:  EmployeeManagementSystem.Data_Access_Layer.DAO Update_Employee " + ex.Message.ToString());


            }

            return output;
        }

    }
}
