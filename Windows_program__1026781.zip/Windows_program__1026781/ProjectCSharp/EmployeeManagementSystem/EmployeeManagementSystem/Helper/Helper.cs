﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using EmployeeManagementSystem.Data_Access_Layer.DAO;
using System.Diagnostics;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Business_Logic_Layer.BLL;
using EmployeeManagementSystem.Presentation_Layer.View;

namespace EmployeeManagementSystem.Helper
{
    class Helper
    {
        static string prefix;
        public static string userName="";
        //method to generate the prefix an Id
        public static string GenerateId(string designation)
        {
            if (designation == "Trainee Engineer")
            {
                prefix = "TRN";
            }

            if (designation == "Software Engineer")
            {
                prefix = "SFT";
            }

            if (designation == "Senior Software Engineer")
            {
                prefix = "SSE";
            }

            if (designation == "Project Lead")
            {
                prefix = "PRL";
            }

            if (designation == "Project Manager")
            {
                prefix = "PRM";
            }

            if (designation == "Senior Manager")
            {
                prefix = "SNM";
            }

            return GenerateID(prefix);
        }
        //method to validate email
        public static bool ValidateEmail(string mail)
        {
            bool flag = true;
            if (!(('A' <= mail[0] && mail[0] <= 'Z') || ('a' <= mail[0] && mail[0] <= 'z')))
            {
                flag = false;
            }
            else if (!mail.Contains('@') || !mail.Contains('.'))
            {
                flag = false;
            }
            return flag;
        }
        //method to generate an Id
        public static string GenerateID(string prefix)
        {
            string new_ID = "";
            string current_ID;
            DataSet dataSet = null;
            string sql = "";

            try
            {
                sql = "select * from tblID order by SUBSTRING(employeeId,4,4) desc";
                dataSet = DBConnection.ExecuteQuery(sql);
                if (dataSet != null)
                {
                    if (dataSet.Tables[0].Rows.Count > 0)
                    {
                        current_ID = dataSet.Tables[0].Rows[0]["employeeId"].ToString();
                        int suffix = Convert.ToInt32(current_ID.Substring(3, 4));
                        suffix++;
                        new_ID = prefix + Convert.ToString(suffix);
                    }
                    else
                    {
                        new_ID = prefix+"1001";
                    }
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Helper / GenerateID ** " + ex.Message.ToString());
            }
            return new_ID;
        }
    }
}
            
    