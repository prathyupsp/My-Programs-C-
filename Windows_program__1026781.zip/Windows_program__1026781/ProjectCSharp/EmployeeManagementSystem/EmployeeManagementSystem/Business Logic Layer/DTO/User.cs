﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.Business_Logic_Layer.DTO
{
    class User
    {
        public string userName { get; set; }
        public string password { get; set; }
        public string question { get; set; }
        public string answer { get; set; }
        public string userType { get; set; }
    }
}
