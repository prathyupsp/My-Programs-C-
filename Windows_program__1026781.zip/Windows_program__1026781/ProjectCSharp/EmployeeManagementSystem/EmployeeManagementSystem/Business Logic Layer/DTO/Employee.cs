﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.Business_Logic_Layer.DTO
{
    public class Employee
    {
        public string employeeId { get; set; }
        public string employeeName { get; set; }
        public string govIdType { get; set; }
        public string govIdNo { get; set; }
        public string gender { get; set; }
        public string dob { get; set; }
        public string permanentAddress { get; set; }
        public int permanentPin { get; set; }
        public string tempAddress { get; set; }
        public int tempPin { get; set; }
        public string personalContact { get; set; }
        public string emailId { get; set; }
        public string designation { get; set; }
        public double ctc { get; set; }
        public string jobLocation { get; set; }
        public string officialContact { get; set; }
        public string education { get; set; }
        public string skills { get; set; }
        public string status { get; set; }

    }
}
