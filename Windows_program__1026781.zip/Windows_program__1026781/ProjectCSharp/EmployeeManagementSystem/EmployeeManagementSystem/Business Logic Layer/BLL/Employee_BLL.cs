﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Data_Access_Layer.DAO;
using System.Data;
using EmployeeManagementSystem.Helper;
namespace EmployeeManagementSystem.Business_Logic_Layer.BLL
{
    class Employee_BLL
    {
        //insert personal details of employee method in BLL
        public static int Insert_Employee_Personal(Employee employee)
        {
            int output = 0;
            try
            {
                output = PersonalDetails.Insert_Employee(employee);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Insert_Employee_Personal ** " + ex.Message.ToString());
            }
            return output;
        }
        //insert personal details of employee method in BLL
        public static int Insert_Employee_Professional(Employee employee)
        {
            int output = 0;
            try
            {
                output = ProfessionalDetails.Insert_Employee(employee);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Insert_Employee_Professional ** " + ex.Message.ToString());
            }
            return output;
        }
        //method to insert details into tblId
        public static int Insert_Employee_ID(Employee employee)
        {
            int output = 0;
            try
            {
                output = IdDetails.Insert_EmployeeID(employee);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Insert_Employee_ID ** " + ex.Message.ToString());
            }
            return output;
        }
        //method to read details of all employee
        public static DataSet Read_All_Employee()
        {
            DataSet dataset = null;
            try
            {
                dataset = ReadEmployee.Get_All_Employee();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Read_All_Employee ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //add user
        public static int Add_User(User user)
        {
            int output = 0;
            try
            {
                output = PersonalDetails.Add_User(user);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Add_User ** " + ex.Message.ToString());
            }
            return output;
        }
        //get user for validation
        public static User Get_User(string username)
        {
            User user = null;
            DataSet dataset = null;
            try
            {
                dataset =PersonalDetails.Get_User(username);
                int count = dataset.Tables[0].Rows.Count;
                if (count > 0)
                {
                   user = new User();
                   user.userName = dataset.Tables[0].Rows[0]["userName"].ToString();
                   user.password = dataset.Tables[0].Rows[0]["password"].ToString();
                   user.question = dataset.Tables[0].Rows[0]["secQuestion"].ToString();
                   user.answer = dataset.Tables[0].Rows[0]["secAnswer"].ToString();
                   user.userType = dataset.Tables[0].Rows[0]["typeOfUser"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_User ** " + ex.Message.ToString());
            }
            return user;
        }
        //update password
        public static int Update_User(User user)
        {
            int output=0;
            try
            {
                output = PersonalDetails.Update_User(user);
                return output;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Update_User ** " + ex.Message.ToString());
            }
            return output;
        }

        //Get All Details method in BLL
        public static DataSet Get_Users()
        {
            DataSet dataset = null;
            try
            {
                dataset = ReadEmployee.Get_Users();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_students ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //method to identify whether the person is user or employee
        public static int Get_users_Like(string name_like)
        {
            DataSet dataset = null;
            int count = 0;
            try
            {
                dataset = ReadEmployee.Get_Users_Like(name_like);
                count = dataset.Tables[0].Rows.Count;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_users_Like ** " + ex.Message.ToString());
            }
            return count;
        }
        //method to get details of employees
        public static DataSet Get_Employee_Like(string like)
        {
            DataSet dataset = null;
            Employee employee = null;
            int count = 0;
            try
            {
                dataset = ReadEmployee.Get_Employee_Like(like);
                count = dataset.Tables[0].Rows.Count;
                if(count>0)
                {
                    employee.employeeName = dataset.Tables[0].Rows[0]["employeeName"].ToString();
                    employee.employeeId = dataset.Tables[0].Rows[0]["employeeId"].ToString();
                    employee.govIdNo =dataset.Tables[0].Rows[0]["govIdNo"].ToString();
                    employee.govIdType = dataset.Tables[0].Rows[0]["govIdType"].ToString();
                    employee.gender = dataset.Tables[0].Rows[0]["gender"].ToString();
                    employee.dob = dataset.Tables[0].Rows[0]["dob"].ToString();
                    employee.permanentAddress = dataset.Tables[0].Rows[0]["permanentAddress"].ToString();
                    employee.permanentPin = Convert.ToInt32(dataset.Tables[0].Rows[0]["permanentPin"].ToString());
                    employee.tempAddress = dataset.Tables[0].Rows[0]["tempAddress"].ToString();
                    employee.tempPin = Convert.ToInt32(dataset.Tables[0].Rows[0]["tempPin"].ToString());
                    employee.personalContact = dataset.Tables[0].Rows[0]["personalContact"].ToString();
                    employee.emailId = dataset.Tables[0].Rows[0]["emailId"].ToString();
                    employee.education = dataset.Tables[0].Rows[0]["education"].ToString();
                    employee.skills = dataset.Tables[0].Rows[0]["skills"].ToString();
                    employee.designation = dataset.Tables[0].Rows[0]["designation"].ToString();
                    employee.ctc = Convert.ToDouble(dataset.Tables[0].Rows[0]["ctc"].ToString());
                    employee.officialContact = dataset.Tables[0].Rows[0]["officialContact"].ToString();
                    employee.jobLocation = dataset.Tables[0].Rows[0]["jobLocation"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_Employee_Like ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //method to get professional details of employees
        public static DataSet Get_Employee_Professional_Like(string like)
        {
            DataSet dataset = null;
            Employee employee = null;
            int count = 0;
            try
            {
                dataset = ReadEmployee.Get_EmployeeProfessional_Like(like);
                count = dataset.Tables[0].Rows.Count;
                if (count > 0)
                {
                    employee.employeeName = dataset.Tables[0].Rows[0]["employeeName"].ToString();
                    employee.employeeId = dataset.Tables[0].Rows[0]["employeeId"].ToString();
                    employee.govIdNo = dataset.Tables[0].Rows[0]["govIdNo"].ToString();
                    employee.govIdType = dataset.Tables[0].Rows[0]["govIdType"].ToString();
                    employee.gender = dataset.Tables[0].Rows[0]["gender"].ToString();
                    employee.dob = dataset.Tables[0].Rows[0]["dob"].ToString();
                    employee.permanentAddress = dataset.Tables[0].Rows[0]["permanentAddress"].ToString();
                    employee.permanentPin = Convert.ToInt32(dataset.Tables[0].Rows[0]["permanentPin"].ToString());
                    employee.tempAddress = dataset.Tables[0].Rows[0]["tempAddress"].ToString();
                    employee.tempPin = Convert.ToInt32(dataset.Tables[0].Rows[0]["tempPin"].ToString());
                    employee.personalContact = dataset.Tables[0].Rows[0]["personalContact"].ToString();
                    employee.emailId = dataset.Tables[0].Rows[0]["emailId"].ToString();
                    employee.education = dataset.Tables[0].Rows[0]["education"].ToString();
                    employee.skills = dataset.Tables[0].Rows[0]["skills"].ToString();
                    employee.designation = dataset.Tables[0].Rows[0]["designation"].ToString();
                    employee.ctc = Convert.ToDouble(dataset.Tables[0].Rows[0]["ctc"].ToString());
                    employee.officialContact = dataset.Tables[0].Rows[0]["officialContact"].ToString();
                    employee.jobLocation = dataset.Tables[0].Rows[0]["jobLocation"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_Employee_Professional_Like ** " + ex.Message.ToString());
            }
            return dataset;
        }
        //method to update the status of an employee
        public static int Update_Status(Employee employee)
        {
            int output = 0;
            try
            {
                output = ReadEmployee.Update_Status(employee);
                return output;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Business_Logic_Layer.BLL / Update_Status ** " + ex.Message.ToString());
            }
            return output;
        }
        //method to remove an existing user
        public static int Delete_User(string username)
        {
            int output = 0;
            try
            {
                output = ReadEmployee.Delete_User(username);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Delete_User ** " + ex.Message.ToString());
            }
            return output;
        }
        //method to get personal details of an mployee
        public static Employee Get_EmployeePersonal(string employee_id)
        {
            Employee employee = null;
            DataSet dataset = null;
            try
            {
                dataset = ReadEmployee.Get_EmployeePersonal(employee_id);
                int count = dataset.Tables[0].Rows.Count;
                if (count > 0)
                {
                    employee=new Employee();
                    employee.employeeId = dataset.Tables[0].Rows[0]["employeeId"].ToString();
                    employee.employeeName = dataset.Tables[0].Rows[0]["employeeName"].ToString();
                    employee.govIdType = dataset.Tables[0].Rows[0]["govIdType"].ToString();
                    employee.govIdNo = dataset.Tables[0].Rows[0]["govIdNo"].ToString();
                    employee.gender = dataset.Tables[0].Rows[0]["gender"].ToString();
                    employee.dob = dataset.Tables[0].Rows[0]["dob"].ToString();
                    employee.permanentAddress = dataset.Tables[0].Rows[0]["permanentAddress"].ToString();
                    employee.permanentPin = Convert.ToInt32(dataset.Tables[0].Rows[0]["permanentPin"].ToString());
                    employee.tempAddress = dataset.Tables[0].Rows[0]["tempAddress"].ToString();
                    employee.tempPin = Convert.ToInt32(dataset.Tables[0].Rows[0]["tempPin"].ToString());
                    employee.personalContact = dataset.Tables[0].Rows[0]["personalContact"].ToString();
                    employee.emailId = dataset.Tables[0].Rows[0]["emailId"].ToString();
                    employee.education = dataset.Tables[0].Rows[0]["education"].ToString();
                    employee.skills = dataset.Tables[0].Rows[0]["skills"].ToString();
                    employee.status = dataset.Tables[0].Rows[0]["status"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_EmployeePersonal ** " + ex.Message.ToString());
            }
            return employee;
        }
        //meyhod to get professional details of an employee
        public static Employee Get_EmployeeProfessional(string employee_id)
        {
            Employee employee = null;
            DataSet dataset = null;
            try
            {
                dataset = ReadEmployee.Get_EmployeeProfessional(employee_id);
                int count = dataset.Tables[0].Rows.Count;
                if (count > 0)
                {
                    employee = new Employee();
                    employee.employeeId = dataset.Tables[0].Rows[0]["employeeId"].ToString();
                    employee.designation = dataset.Tables[0].Rows[0]["designation"].ToString();
                    employee.ctc = Convert.ToDouble(dataset.Tables[0].Rows[0]["ctc"].ToString());
                    employee.officialContact = dataset.Tables[0].Rows[0]["officialContact"].ToString();
                    employee.jobLocation = dataset.Tables[0].Rows[0]["jobLocation"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_EmployeeProfessional ** " + ex.Message.ToString());
            }
            return employee;
        }
        //method to get the 
        public static Employee Get_Id(string employee_id)
        {
            Employee employee = null;
            DataSet dataset = null;
            try
            {
                dataset = ReadEmployee.Get_Id(employee_id);
                int count = dataset.Tables[0].Rows.Count;
                if (count > 0)
                {
                    employee = new Employee();
                    employee.employeeId = dataset.Tables[0].Rows[0]["employeeId"].ToString();
                    employee.govIdNo = dataset.Tables[0].Rows[0]["govIdNo"].ToString();
                    employee.status = dataset.Tables[0].Rows[0]["status"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Business_Logic_Layer.BLL / Get_EmployeeProfessional ** " + ex.Message.ToString());
            }
            return employee;
        }

        public static int Update_Employee(Employee employee)
        {
            int output = 0;
            try
            {
                output = ReadEmployee.Update_Employee(employee);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error: EmployeeManagementSystem.Business_Logic_Layer.BLL Update_Employee" + ex.Message.ToString());
            }
            return output;
        }
    }
}
