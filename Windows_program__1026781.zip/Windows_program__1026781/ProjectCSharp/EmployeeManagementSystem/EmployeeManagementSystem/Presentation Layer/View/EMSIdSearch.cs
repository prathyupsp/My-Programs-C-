﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementSystem.Business_Logic_Layer.BLL;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Presentation_Layer.View;
using System.Diagnostics;

namespace EmployeeManagementSystem.Presentation_Layer.View
{
    public partial class EMSIdSearch : Form
    {
        string query = "";
        public EMSIdSearch()
        {
            InitializeComponent();
        }

        private void EMSIdSearch_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(txtDetails1, "Enter the Employee Id");
        }
        //method to search for details in database
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string operation="";
            sslSearchId.Text = "Click on the Button to search";
            if ((txtDetails1.Text == "") && (txtDetails2.Text == ""))
                MessageBox.Show("Enter atleast one details to search");
            else
            {
                if ((txtDetails1.Text != "") && (txtDetails2.Text != "") && (!cbOperation.SelectedItem.ToString().Equals("AND/OR")))
                {
                    operation = cbOperation.SelectedItem.ToString();
                    query = " " + cbDetails1.SelectedItem.ToString() + " LIKE '" + txtDetails1.Text + "%' " + operation + " " + cbDetails2.SelectedItem.ToString() + " LIKE'" + txtDetails2.Text + "%'";
                }
                else if ((txtDetails1.Text != "") && (txtDetails2.Text == ""))
                    query = " " + cbDetails1.SelectedItem.ToString() + " LIKE '" + txtDetails1.Text+"%'";
                else
                    query = " " + cbDetails2.SelectedItem.ToString() + " LIKE '" + txtDetails2.Text+"%'";
                   
                Debug.WriteLine(query);
                LoadEmployeeGrid();
                LoadProfessionalGrid();
            }
        }

        private void cbDetails1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //method to load gridview
        private void LoadEmployeeGrid()
        {
            DataSet dataset = null;
            try
            {
                dataset = Employee_BLL.Get_Employee_Like(query);
                if (dataset != null)
                {
                    dgvEmployee.DataSource = dataset.Tables[0];
                }
                else
                {
                    MessageBox.Show("No Employee details available");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Presentation_Layer.View / LoadEmployeeGrid ** " + ex.Message.ToString());
            }
        }
        //method to  lod gridview
        private void LoadProfessionalGrid()
        {
            DataSet dataset = null;
            try
            {
                dataset = Employee_BLL.Get_Employee_Professional_Like(query);
                if (dataset != null)
                {
                    dgvProfessional.DataSource = dataset.Tables[0];
                }
                else
                {
                    MessageBox.Show("No Employee details available");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Presentation_Layer.View / LoadProfessionalGrid ** " + ex.Message.ToString());
            }
        }
        //method to mark an employee as resigned
        private void btnResigned_Click(object sender, EventArgs e)
        {
            if (txtEmployeeId.Text == "")
                MessageBox.Show("Select a row");
            else
            {
                Employee employee = new Employee();
                employee.employeeId = id;
                employee.status = "Resigned";
                MessageBox.Show(txtEmployeeId.Text + "   Resigned");
                Employee_BLL.Update_Status(employee);
                btnGo.PerformClick();
            }
            
        }

        private void txtEmployeeId_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dgvEmployee_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        string id = "";
        //method to get id of the selected row in personal grid
        private void dgvEmployee_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvEmployee.SelectedCells.Count > 0)
            {
                int selectedrowindex = dgvEmployee.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dgvEmployee.Rows[selectedrowindex];

                id = Convert.ToString(selectedRow.Cells["employeeId"].Value);
                txtEmployeeId.Text = id;
            }
        }

        private void dgvEmployee_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        //method to get the id of the selected row in professional grid
        private void dgvProfessional_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProfessional.SelectedCells.Count > 0)
            {
                int selectedrowindex = dgvProfessional.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dgvProfessional.Rows[selectedrowindex];

                id = Convert.ToString(selectedRow.Cells["employeeId"].Value);
                txtEmployeeId.Text = id;
            }
        }

        private void dgvProfessional_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        //method to view details about the employee
        private void btnView_Click(object sender, EventArgs e)
        {
            Employee employee = new Employee();
            Employee employee1 = new Employee();


            if (txtEmployeeId.Text == "")
                MessageBox.Show("Select a row");
            else
            {
                string id = txtEmployeeId.Text;
                employee1 = Employee_BLL.Get_EmployeePersonal(id);
                employee1 = Employee_BLL.Get_EmployeeProfessional(id);
                EMS ems = new EMS();

                ems.SetEmployee(employee1);
                ems.ShowDialog();
            }
        }
        //method to mark an employee as resigned
        private void button1_Click(object sender, EventArgs e)
        {

            if (txtEmployeeId.Text == "")
                MessageBox.Show("Select a row");
            else
            {
                Employee employee = new Employee();
                employee.employeeId = id;
                employee.status = "Employee";
                MessageBox.Show(txtEmployeeId.Text + "   Marked as Current Employee");
                Employee_BLL.Update_Status(employee);
                btnGo.PerformClick();
            }
        }
       
    }
}
