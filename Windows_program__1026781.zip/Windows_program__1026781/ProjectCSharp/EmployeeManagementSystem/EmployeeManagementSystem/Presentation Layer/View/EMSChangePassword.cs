﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Data_Access_Layer.DAO;
using EmployeeManagementSystem.Business_Logic_Layer.BLL;

namespace EmployeeManagementSystem.Presentation_Layer.View
{
    public partial class EMSChangePassword : Form
    {
        public EMSChangePassword()
        {
            InitializeComponent();
            toolTip1.SetToolTip(txtUsername, "Enter the Username");
            toolTip1.SetToolTip(txtCurrentPass, "Enter the Old Password");
            toolTip1.SetToolTip(txtNewPassword, "Enter the New Password");
            toolTip1.SetToolTip(txtReenterpassword, "Re-enter new password");
            toolTip1.SetToolTip(btnChangePassword, "Change Password Button");
        }
        //method to change password
        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (validateuserNewPassword(txtUsername.Text))
            {
                this.Hide();               
                MessageBox.Show("Password Changed Successfully.");
                EMSLogin ems = new EMSLogin();
                ems.ShowDialog();
                this.Close();
            }
            else
                MessageBox.Show("Invalid Entry");
        }
        //validate user in change password form
        private bool validateuserNewPassword(string username)
        {
            User userver = null;
            if (ValidateEmptyChange())
            {
                userver = Employee_BLL.Get_User(txtUsername.Text);
                if (txtCurrentPass.Text != userver.password)
                    return false;
                else if (txtNewPassword.Text != txtReenterpassword.Text)
                    return false;
                else
                {
                    userver.userName = txtUsername.Text;
                    userver.password = txtNewPassword.Text;
                    if (Employee_BLL.Update_User(userver) > 0)
                        return true;
                    else
                        return false;
                }
            }
            else
            {
                MessageBox.Show("Fill all details");
                return false;
            }
        }
        //method to validate
        private bool ValidateEmptyChange()
        {
            if (txtUsername.Text == "")
                return false;
            if (txtCurrentPass.Text == "")
                return false;
            if (txtNewPassword.Text == "")
                return false;
            if (txtReenterpassword.Text == "")
                return false;
            else
                return true;
        }

        private void EMSChangePassword_Load(object sender, EventArgs e)
        {

        }

    }
}
