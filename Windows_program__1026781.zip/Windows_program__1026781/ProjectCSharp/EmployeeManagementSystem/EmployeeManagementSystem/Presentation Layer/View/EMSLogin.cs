﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Business_Logic_Layer.BLL;
using System.Diagnostics;
using EmployeeManagementSystem.Helper;

namespace EmployeeManagementSystem.Presentation_Layer.View
{
    public partial class EMSLogin : Form
    {
        public string type = null;
        public bool loginFlag = false;
        public EMSLogin()
        {
            CenterToScreen();
            IsMdiContainer = false;
            InitializeComponent();
            Logout();
            RandomNumber();
            ClearForm();
        }
        //to set tooltip
        private void EMSLogin_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(txtUsername, "Enter the Username");
            toolTip1.SetToolTip(txtPassword, "Enter the Password");
            toolTip1.SetToolTip(txtSum, "Enter the Sum");
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            
        }
        //method to load EMS Forgot form
        private void btnForgot_Click(object sender, EventArgs e)
        {
            this.Hide();
            EMSForgot obj = new EMSForgot();
            obj.ShowDialog();
            this.Close();
        }
        //method to login
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if(btnLogin.Text=="Login")
                {
                    if (txtUsername.Text == "")
                    {
                        MessageBox.Show("Enter the username");
                        RandomNumber();
                        txtUsername.Focus();

                    }
                    else if (txtPassword.Text == "")
                    {
                        MessageBox.Show("Enter the Password");
                        RandomNumber();
                        txtPassword.Focus();
                    }
                    else
                    {
                        if (txtSum.Text == "")
                        {
                            MessageBox.Show("enter the captcha");
                            RandomNumber();
                        }
                        else
                        {
                            int val3check = Convert.ToInt32(txtSum.Text.ToString());
                            int val1 = Convert.ToInt32(txtValue1.Text.ToString());
                            int val2 = Convert.ToInt32(txtValue2.Text.ToString());
                            int sum = Convert.ToInt32(txtSum.Text.ToString());
                            if (val1 + val2 == sum && ValidateUser(txtUsername.Text, txtPassword.Text))
                            {
                                
                                MessageBox.Show("Verified");
                                sslLogin.Text = "Login Successfull : " + txtUsername.Text;
                                loginFlag = true;
                               
                                txtUsername.ReadOnly = true;
                                txtPassword.ReadOnly = true;
                                txtSum.ReadOnly = true;
                                btnForgot.Enabled = false;
                                btnChangePassword.Enabled = false;
                                btnLogin.Text = "Logout";
                                RandomNumber();
                                LoginSuccess();
                                Helper.Helper.userName = txtUsername.Text;
                            }
                            else
                            {
                                MessageBox.Show("Login invalid");
                                loginFlag = false;
                                RandomNumber();
                            }

                        }
                    }
                }
                else if(btnLogin.Text=="Logout")
                {
                    MessageBox.Show("Logout Successfull : Login Again ");
                    //for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
                    //{
                    //    if (Application.OpenForms[i].Name != "EMSLogin")
                    //        Application.OpenForms[i].Close();
                    //}
                    Logout();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Presentation_Layer.View / LoginButton ** " + ex.Message.ToString());
            }
        }
        //method to logout
        private void Logout()
        {
            loginFlag = false;
            txtUsername.ReadOnly = false;
            txtUsername.Text = "";
            txtPassword.ReadOnly = false;
            txtPassword.Text = "";
            txtSum.ReadOnly = false;
            txtSum.Text = "";
            txtLoginType.Text = "";
            btnForgot.Enabled = true;
            btnChangePassword.Enabled = true;
            btnLogin.Text = "Login";
            ClearForm();
        }

        //method to validate user
        private bool ValidateUser(string username,string password)
        {
            User userver = new User();
            userver = Employee_BLL.Get_User(username);
            if (userver.password.Equals(password))
            {
                txtLoginType.Text=userver.userType;
                return true;
            }
            else
                return false;
        }
        //method to check login type
        private string CheckLoginType(string username)
        {
            string usertype;
            try
            {
                User userver = new User();
                userver = Employee_BLL.Get_User(username);
                usertype = userver.userType;
                    return usertype;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("**  EmployeeManagementSystem.Presentation_Layer.View / CheckLoginType ** " + ex.Message.ToString());
                return "";
            }
        }
        private void txtValue1_TextChanged(object sender, EventArgs e)
        {

        }
        //method to produce random number
        private void RandomNumber()
        {
            Random rnd = new Random();
            int val1 = rnd.Next(0,9);
            int val2 = rnd.Next(0,9);
            txtValue1.Text = val1.ToString();
            txtValue2.Text = val2.ToString();
        }
        //to refresh random number 
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RandomNumber();
        }

        private void EMSLogin_MouseHover(object sender, EventArgs e)
        {
            sslLogin.Text = "Login Button";
        }

        private void btnForgot_MouseHover(object sender, EventArgs e)
        {
            sslLogin.Text = "Forgot Password button";
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void txtSum_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLogin_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void txtSum_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnLogin.PerformClick();
        }
       public void ClearForm()
        {          
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtSum.Text = "";
            RandomNumber();            
        }

       private void EMSLogin_FormClosing(object sender, FormClosingEventArgs e)
       {

       }

       private void panel1_Paint(object sender, PaintEventArgs e)
       {

       }
        //method to load EMS change password form
       private void btnChangePassword_Click(object sender, EventArgs e)
       {
           this.Hide();
           EMSChangePassword obj = new EMSChangePassword();
           obj.ShowDialog();
           this.Close();
       }

       private void menuToolStripMenuItem_Click(object sender, EventArgs e)
       {
           LoginSuccess();

       }
        //method to load admin menu form or menu from
       private void LoginSuccess()
       {
           if (loginFlag)
           {
               if (txtLoginType.Text == "Admin")
               {
                   this.Hide();
                   AdminMenu objAdmin = new AdminMenu();
                   objAdmin.ShowDialog();
                   this.Close();
               }
               else if (txtLoginType.Text == "User")
               {
                   this.Hide();
                   menuForm objUser = new menuForm();
                   objUser.ShowDialog();
                   this.Close();
               }
           }
           else
               MessageBox.Show("Login First"); 
       }
    }
}
