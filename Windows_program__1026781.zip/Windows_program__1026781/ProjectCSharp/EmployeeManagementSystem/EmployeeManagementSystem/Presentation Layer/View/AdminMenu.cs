﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeManagementSystem.Presentation_Layer.View
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
        }
        //method to load EMS form
        private void btnInsertMenu_MouseClick(object sender, MouseEventArgs e)
        {
           
            EMS objEMS = new EMS();
            objEMS.Show();
            

        }
        //method to load Add user form
        private void btnAddUser_Click(object sender, EventArgs e)
        {
           
            AddUserForm objAdmin = new AddUserForm();
            objAdmin.ShowDialog();
            
        }
        //method to load EMS ID search form
        private void btnViewMenu_Click(object sender, EventArgs e)
        {
           
            EMSIdSearch emsid = new EMSIdSearch();
            emsid.ShowDialog();
           
        }
        
        private void btnInsertMenu_Click(object sender, EventArgs e)
        {
            
        }

        private void AdminMenu_Load(object sender, EventArgs e)
        {

        }
        //method to load EMS Login form
        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            EMSLogin ems = new EMSLogin();
            ems.ShowDialog();
            this.Close();
        }
    }
}
