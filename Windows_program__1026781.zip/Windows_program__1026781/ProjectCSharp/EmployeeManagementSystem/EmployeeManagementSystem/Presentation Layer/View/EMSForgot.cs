﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Data_Access_Layer.DAO;
using EmployeeManagementSystem.Business_Logic_Layer.BLL;

namespace EmployeeManagementSystem.Presentation_Layer.View
{
    public partial class EMSForgot : Form
    {
        public EMSForgot()
        {
            InitializeComponent();
        }
        //to set tooltip
        private void EMSForgot_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(txtUsername, "Enter the Username");
            toolTip1.SetToolTip(txtNewPassword, "Enter the New Password");
            toolTip1.SetToolTip(txtReenterpassword, "Re enter the password");
            toolTip1.SetToolTip(txtAnswer, "Enter the Answer");
            toolTip1.SetToolTip(cbSecuirty, "Select the Security Question");
            toolTip1.SetToolTip(btnChangePassword, "Change Password Button");
        }
        //method to chamge password
        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            ForgotPassword.Text = "Click on the button to set password";
            if(validateuserChangePassword(txtUsername.Text))
            {
                MessageBox.Show("Password Changed Successfully.");
                this.Hide();
                EMSLogin ems = new EMSLogin();
                ems.ShowDialog();
                this.Close();
            }
            else
                MessageBox.Show("Invalid Entry");

        }
        //validate user in change password form
        private bool validateuserChangePassword(string username)
        {
            User userver = null;
            if(ValidateEmptyChange())
            {
                userver = Employee_BLL.Get_User(txtUsername.Text);
                if (userver.question != cbSecuirty.SelectedItem.ToString())
                    return false;
                else if (userver.answer != txtAnswer.Text)
                    return false;
                else if (txtNewPassword.Text != txtReenterpassword.Text)
                    return false;
                else
                {
                    userver.userName=txtUsername.Text;
                    userver.password=txtNewPassword.Text;
                    userver.question=cbSecuirty.SelectedItem.ToString();
                    userver.answer=txtAnswer.Text;
                    if(Employee_BLL.Update_User(userver)>0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                
            }
            else
            {
                MessageBox.Show("Fill all details");
                return false;
            }
        }
        //check for empty field in change password
        private bool ValidateEmptyChange()
        {
            if (txtUsername.Text == "")
                return false;
            if (txtNewPassword.Text == "")
                return false;
            if (txtReenterpassword.Text == "")
                return false;
            if (cbSecuirty.SelectedItem == null)
                return false;
            if (txtAnswer.Text == "")
                return false;
            else
                return true;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnChangePassword_MouseHover(object sender, EventArgs e)
        {
            
        }
    }
}
