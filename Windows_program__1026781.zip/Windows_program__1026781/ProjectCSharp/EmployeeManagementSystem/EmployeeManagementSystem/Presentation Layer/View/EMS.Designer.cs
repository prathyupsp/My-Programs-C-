﻿namespace EmployeeManagementSystem.Presentation_Layer.View
{
    partial class EMS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ssLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnView1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbEmpId = new System.Windows.Forms.ComboBox();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.lblEmpId = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.msEMS = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.validateAndSubmitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveForLaterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goToMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ttEmployee = new System.Windows.Forms.ToolTip(this.components);
            this.ssEmployee = new System.Windows.Forms.StatusStrip();
            this.ssTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.pnlForm = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPersonal = new System.Windows.Forms.TabPage();
            this.gbPersonal = new System.Windows.Forms.GroupBox();
            this.mtbPersonal = new System.Windows.Forms.MaskedTextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblContactPersonal = new System.Windows.Forms.Label();
            this.cbSameAsPerm = new System.Windows.Forms.CheckBox();
            this.lblTempPin = new System.Windows.Forms.Label();
            this.txtTempPin = new System.Windows.Forms.TextBox();
            this.txtTempAddress = new System.Windows.Forms.TextBox();
            this.lblTempAddress = new System.Windows.Forms.Label();
            this.lblPermPIN = new System.Windows.Forms.Label();
            this.txtPermPIN = new System.Windows.Forms.TextBox();
            this.txtPermAddress = new System.Windows.Forms.TextBox();
            this.lblPermAddress = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.lblDOB = new System.Windows.Forms.Label();
            this.rbTG = new System.Windows.Forms.RadioButton();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.lblGender = new System.Windows.Forms.Label();
            this.cbIdType = new System.Windows.Forms.ComboBox();
            this.txtIdCardNo = new System.Windows.Forms.TextBox();
            this.lblIdCard = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.tabProfessional = new System.Windows.Forms.TabPage();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.pnlDeclaration = new System.Windows.Forms.Panel();
            this.tbConfirmation = new System.Windows.Forms.TextBox();
            this.cbDeclaration = new System.Windows.Forms.CheckBox();
            this.gbProfessional = new System.Windows.Forms.GroupBox();
            this.mtbOfficial = new System.Windows.Forms.MaskedTextBox();
            this.lblContactOfficial = new System.Windows.Forms.Label();
            this.lbSkills = new System.Windows.Forms.ListBox();
            this.lblSkills = new System.Windows.Forms.Label();
            this.txtEducational = new System.Windows.Forms.TextBox();
            this.lblEducation = new System.Windows.Forms.Label();
            this.cbJobLocation = new System.Windows.Forms.ComboBox();
            this.lblJobLocation = new System.Windows.Forms.Label();
            this.txtCTC = new System.Windows.Forms.TextBox();
            this.lblCTC = new System.Windows.Forms.Label();
            this.cbDesignation = new System.Windows.Forms.ComboBox();
            this.lblDesignation = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.msEMS.SuspendLayout();
            this.ssEmployee.SuspendLayout();
            this.pnlForm.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPersonal.SuspendLayout();
            this.gbPersonal.SuspendLayout();
            this.tabProfessional.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.pnlDeclaration.SuspendLayout();
            this.gbProfessional.SuspendLayout();
            this.SuspendLayout();
            // 
            // ssLabel1
            // 
            this.ssLabel1.Name = "ssLabel1";
            this.ssLabel1.Size = new System.Drawing.Size(174, 17);
            this.ssLabel1.Text = "Employee Management System";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnView1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lblTitle);
            this.panel1.Location = new System.Drawing.Point(10, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(493, 82);
            this.panel1.TabIndex = 30;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnView1
            // 
            this.btnView1.Location = new System.Drawing.Point(432, 41);
            this.btnView1.Name = "btnView1";
            this.btnView1.Size = new System.Drawing.Size(46, 23);
            this.btnView1.TabIndex = 30;
            this.btnView1.Text = "Edit";
            this.btnView1.UseVisualStyleBackColor = true;
            this.btnView1.Click += new System.EventHandler(this.btnView1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbEmpId);
            this.panel2.Controls.Add(this.txtEmployeeID);
            this.panel2.Controls.Add(this.lblEmpId);
            this.panel2.Location = new System.Drawing.Point(66, 39);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(360, 32);
            this.panel2.TabIndex = 29;
            // 
            // cbEmpId
            // 
            this.cbEmpId.FormattingEnabled = true;
            this.cbEmpId.Location = new System.Drawing.Point(125, 5);
            this.cbEmpId.Name = "cbEmpId";
            this.cbEmpId.Size = new System.Drawing.Size(208, 21);
            this.cbEmpId.TabIndex = 32;
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Location = new System.Drawing.Point(125, 5);
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.ReadOnly = true;
            this.txtEmployeeID.Size = new System.Drawing.Size(223, 20);
            this.txtEmployeeID.TabIndex = 31;
            this.txtEmployeeID.TextChanged += new System.EventHandler(this.txtEmployeeID_TextChanged);
            // 
            // lblEmpId
            // 
            this.lblEmpId.AutoSize = true;
            this.lblEmpId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpId.Location = new System.Drawing.Point(12, 6);
            this.lblEmpId.Name = "lblEmpId";
            this.lblEmpId.Size = new System.Drawing.Size(86, 15);
            this.lblEmpId.TabIndex = 0;
            this.lblEmpId.Text = "Employee ID : ";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(44, 2);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(409, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "EMPLOYEE MANAGEMENT SYSTEM";
            // 
            // msEMS
            // 
            this.msEMS.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.msEMS.Location = new System.Drawing.Point(0, 0);
            this.msEMS.Name = "msEMS";
            this.msEMS.Size = new System.Drawing.Size(521, 24);
            this.msEMS.TabIndex = 27;
            this.msEMS.Text = "menuStrip1";
            this.msEMS.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.msEMS_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.validateAndSubmitToolStripMenuItem,
            this.saveForLaterToolStripMenuItem,
            this.goToMenuToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // validateAndSubmitToolStripMenuItem
            // 
            this.validateAndSubmitToolStripMenuItem.Name = "validateAndSubmitToolStripMenuItem";
            this.validateAndSubmitToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.validateAndSubmitToolStripMenuItem.Text = "Validate and Submit";
            // 
            // saveForLaterToolStripMenuItem
            // 
            this.saveForLaterToolStripMenuItem.Name = "saveForLaterToolStripMenuItem";
            this.saveForLaterToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.saveForLaterToolStripMenuItem.Text = "Save for later";
            // 
            // goToMenuToolStripMenuItem
            // 
            this.goToMenuToolStripMenuItem.Name = "goToMenuToolStripMenuItem";
            this.goToMenuToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.goToMenuToolStripMenuItem.Text = "Go To Menu";
            this.goToMenuToolStripMenuItem.Click += new System.EventHandler(this.goToMenuToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click_1);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click_1);
            // 
            // ssEmployee
            // 
            this.ssEmployee.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ssLabel1,
            this.ssTime});
            this.ssEmployee.Location = new System.Drawing.Point(0, 552);
            this.ssEmployee.Name = "ssEmployee";
            this.ssEmployee.Size = new System.Drawing.Size(521, 22);
            this.ssEmployee.TabIndex = 28;
            this.ssEmployee.Text = "statusStrip1";
            // 
            // ssTime
            // 
            this.ssTime.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ssTime.Name = "ssTime";
            this.ssTime.Size = new System.Drawing.Size(10, 17);
            this.ssTime.Text = " ";
            // 
            // pnlForm
            // 
            this.pnlForm.Controls.Add(this.tabControl1);
            this.pnlForm.Controls.Add(this.panel1);
            this.pnlForm.Location = new System.Drawing.Point(3, 27);
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Size = new System.Drawing.Size(514, 522);
            this.pnlForm.TabIndex = 26;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPersonal);
            this.tabControl1.Controls.Add(this.tabProfessional);
            this.tabControl1.Location = new System.Drawing.Point(6, 94);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(503, 418);
            this.tabControl1.TabIndex = 31;
            // 
            // tabPersonal
            // 
            this.tabPersonal.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tabPersonal.Controls.Add(this.gbPersonal);
            this.tabPersonal.Location = new System.Drawing.Point(4, 22);
            this.tabPersonal.Name = "tabPersonal";
            this.tabPersonal.Padding = new System.Windows.Forms.Padding(3);
            this.tabPersonal.Size = new System.Drawing.Size(495, 392);
            this.tabPersonal.TabIndex = 0;
            this.tabPersonal.Text = "Personal Details";
            // 
            // gbPersonal
            // 
            this.gbPersonal.Controls.Add(this.mtbPersonal);
            this.gbPersonal.Controls.Add(this.txtEmail);
            this.gbPersonal.Controls.Add(this.lblEmail);
            this.gbPersonal.Controls.Add(this.lblContactPersonal);
            this.gbPersonal.Controls.Add(this.cbSameAsPerm);
            this.gbPersonal.Controls.Add(this.lblTempPin);
            this.gbPersonal.Controls.Add(this.txtTempPin);
            this.gbPersonal.Controls.Add(this.txtTempAddress);
            this.gbPersonal.Controls.Add(this.lblTempAddress);
            this.gbPersonal.Controls.Add(this.lblPermPIN);
            this.gbPersonal.Controls.Add(this.txtPermPIN);
            this.gbPersonal.Controls.Add(this.txtPermAddress);
            this.gbPersonal.Controls.Add(this.lblPermAddress);
            this.gbPersonal.Controls.Add(this.txtAge);
            this.gbPersonal.Controls.Add(this.lblAge);
            this.gbPersonal.Controls.Add(this.dtpDOB);
            this.gbPersonal.Controls.Add(this.lblDOB);
            this.gbPersonal.Controls.Add(this.rbTG);
            this.gbPersonal.Controls.Add(this.rbFemale);
            this.gbPersonal.Controls.Add(this.rbMale);
            this.gbPersonal.Controls.Add(this.lblGender);
            this.gbPersonal.Controls.Add(this.cbIdType);
            this.gbPersonal.Controls.Add(this.txtIdCardNo);
            this.gbPersonal.Controls.Add(this.lblIdCard);
            this.gbPersonal.Controls.Add(this.txtName);
            this.gbPersonal.Controls.Add(this.lblName);
            this.gbPersonal.Location = new System.Drawing.Point(3, 5);
            this.gbPersonal.Name = "gbPersonal";
            this.gbPersonal.Size = new System.Drawing.Size(489, 385);
            this.gbPersonal.TabIndex = 30;
            this.gbPersonal.TabStop = false;
            this.gbPersonal.Text = "PERSONAL DETAILS";
            // 
            // mtbPersonal
            // 
            this.mtbPersonal.Location = new System.Drawing.Point(182, 315);
            this.mtbPersonal.Mask = "0000000000";
            this.mtbPersonal.Name = "mtbPersonal";
            this.mtbPersonal.Size = new System.Drawing.Size(121, 20);
            this.mtbPersonal.TabIndex = 13;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(182, 344);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(242, 20);
            this.txtEmail.TabIndex = 14;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(8, 347);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(60, 15);
            this.lblEmail.TabIndex = 37;
            this.lblEmail.Text = "Email ID: ";
            // 
            // lblContactPersonal
            // 
            this.lblContactPersonal.AutoSize = true;
            this.lblContactPersonal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactPersonal.Location = new System.Drawing.Point(8, 320);
            this.lblContactPersonal.Name = "lblContactPersonal";
            this.lblContactPersonal.Size = new System.Drawing.Size(128, 15);
            this.lblContactPersonal.TabIndex = 35;
            this.lblContactPersonal.Text = "Personal Contact No : ";
            // 
            // cbSameAsPerm
            // 
            this.cbSameAsPerm.AutoSize = true;
            this.cbSameAsPerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.cbSameAsPerm.Location = new System.Drawing.Point(185, 220);
            this.cbSameAsPerm.Name = "cbSameAsPerm";
            this.cbSameAsPerm.Size = new System.Drawing.Size(186, 19);
            this.cbSameAsPerm.TabIndex = 10;
            this.cbSameAsPerm.Text = "Same as Permanent Address";
            this.cbSameAsPerm.UseVisualStyleBackColor = true;
            this.cbSameAsPerm.CheckedChanged += new System.EventHandler(this.cbSameAsPerm_CheckedChanged_1);
            this.cbSameAsPerm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbSameAsPerm_KeyDown);
            // 
            // lblTempPin
            // 
            this.lblTempPin.AutoSize = true;
            this.lblTempPin.BackColor = System.Drawing.Color.Transparent;
            this.lblTempPin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempPin.Location = new System.Drawing.Point(336, 288);
            this.lblTempPin.Name = "lblTempPin";
            this.lblTempPin.Size = new System.Drawing.Size(36, 15);
            this.lblTempPin.TabIndex = 22;
            this.lblTempPin.Text = "PIN : ";
            // 
            // txtTempPin
            // 
            this.txtTempPin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtTempPin.Location = new System.Drawing.Point(378, 287);
            this.txtTempPin.Name = "txtTempPin";
            this.txtTempPin.Size = new System.Drawing.Size(84, 21);
            this.txtTempPin.TabIndex = 12;
            // 
            // txtTempAddress
            // 
            this.txtTempAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtTempAddress.Location = new System.Drawing.Point(182, 249);
            this.txtTempAddress.Multiline = true;
            this.txtTempAddress.Name = "txtTempAddress";
            this.txtTempAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtTempAddress.Size = new System.Drawing.Size(280, 29);
            this.txtTempAddress.TabIndex = 11;
            // 
            // lblTempAddress
            // 
            this.lblTempAddress.AutoSize = true;
            this.lblTempAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempAddress.Location = new System.Drawing.Point(8, 219);
            this.lblTempAddress.Name = "lblTempAddress";
            this.lblTempAddress.Size = new System.Drawing.Size(150, 15);
            this.lblTempAddress.TabIndex = 19;
            this.lblTempAddress.Text = "Communication Address : ";
            // 
            // lblPermPIN
            // 
            this.lblPermPIN.AutoSize = true;
            this.lblPermPIN.BackColor = System.Drawing.Color.Transparent;
            this.lblPermPIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPermPIN.Location = new System.Drawing.Point(336, 188);
            this.lblPermPIN.Name = "lblPermPIN";
            this.lblPermPIN.Size = new System.Drawing.Size(36, 15);
            this.lblPermPIN.TabIndex = 18;
            this.lblPermPIN.Text = "PIN : ";
            // 
            // txtPermPIN
            // 
            this.txtPermPIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtPermPIN.Location = new System.Drawing.Point(378, 186);
            this.txtPermPIN.Name = "txtPermPIN";
            this.txtPermPIN.Size = new System.Drawing.Size(84, 21);
            this.txtPermPIN.TabIndex = 9;
            // 
            // txtPermAddress
            // 
            this.txtPermAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtPermAddress.Location = new System.Drawing.Point(182, 150);
            this.txtPermAddress.Multiline = true;
            this.txtPermAddress.Name = "txtPermAddress";
            this.txtPermAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPermAddress.Size = new System.Drawing.Size(280, 29);
            this.txtPermAddress.TabIndex = 8;
            // 
            // lblPermAddress
            // 
            this.lblPermAddress.AutoSize = true;
            this.lblPermAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPermAddress.Location = new System.Drawing.Point(8, 156);
            this.lblPermAddress.Name = "lblPermAddress";
            this.lblPermAddress.Size = new System.Drawing.Size(124, 15);
            this.lblPermAddress.TabIndex = 13;
            this.lblPermAddress.Text = "Permanent Address : ";
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(416, 119);
            this.txtAge.Name = "txtAge";
            this.txtAge.ReadOnly = true;
            this.txtAge.Size = new System.Drawing.Size(46, 20);
            this.txtAge.TabIndex = 32;
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.Location = new System.Drawing.Point(359, 121);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(37, 15);
            this.lblAge.TabIndex = 11;
            this.lblAge.Text = "Age : ";
            // 
            // dtpDOB
            // 
            this.dtpDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDOB.Location = new System.Drawing.Point(182, 119);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(121, 21);
            this.dtpDOB.TabIndex = 7;
            this.dtpDOB.Value = new System.DateTime(2019, 8, 27, 10, 55, 40, 0);
            this.dtpDOB.ValueChanged += new System.EventHandler(this.dtpDOB_ValueChanged_1);
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.Location = new System.Drawing.Point(8, 125);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(42, 15);
            this.lblDOB.TabIndex = 9;
            this.lblDOB.Text = "DOB : ";
            // 
            // rbTG
            // 
            this.rbTG.AutoSize = true;
            this.rbTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.rbTG.Location = new System.Drawing.Point(406, 93);
            this.rbTG.Name = "rbTG";
            this.rbTG.Size = new System.Drawing.Size(41, 19);
            this.rbTG.TabIndex = 6;
            this.rbTG.TabStop = true;
            this.rbTG.Text = "TG";
            this.rbTG.UseVisualStyleBackColor = true;
            this.rbTG.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rbTG_KeyDown);
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.rbFemale.Location = new System.Drawing.Point(286, 93);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(67, 19);
            this.rbFemale.TabIndex = 5;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            this.rbFemale.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rbFemale_KeyDown);
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.rbMale.Location = new System.Drawing.Point(182, 93);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(53, 19);
            this.rbMale.TabIndex = 4;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            this.rbMale.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rbMale_KeyDown);
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(8, 93);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(57, 15);
            this.lblGender.TabIndex = 5;
            this.lblGender.Text = "Gender : ";
            // 
            // cbIdType
            // 
            this.cbIdType.FormattingEnabled = true;
            this.cbIdType.Items.AddRange(new object[] {
            "PAN",
            "AADHAAR",
            "VOTER ID",
            "DRIVING LICENCE",
            "PASSPORT NO:"});
            this.cbIdType.Location = new System.Drawing.Point(182, 60);
            this.cbIdType.Name = "cbIdType";
            this.cbIdType.Size = new System.Drawing.Size(121, 21);
            this.cbIdType.TabIndex = 2;
            // 
            // txtIdCardNo
            // 
            this.txtIdCardNo.Location = new System.Drawing.Point(318, 60);
            this.txtIdCardNo.Name = "txtIdCardNo";
            this.txtIdCardNo.Size = new System.Drawing.Size(144, 20);
            this.txtIdCardNo.TabIndex = 3;
            // 
            // lblIdCard
            // 
            this.lblIdCard.AutoSize = true;
            this.lblIdCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdCard.Location = new System.Drawing.Point(8, 62);
            this.lblIdCard.Name = "lblIdCard";
            this.lblIdCard.Size = new System.Drawing.Size(132, 15);
            this.lblIdCard.TabIndex = 2;
            this.lblIdCard.Text = "ID Card Type and No. : ";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(182, 30);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(280, 20);
            this.txtName.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(8, 32);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(50, 15);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name : ";
            // 
            // tabProfessional
            // 
            this.tabProfessional.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tabProfessional.Controls.Add(this.pnlButtons);
            this.tabProfessional.Controls.Add(this.pnlDeclaration);
            this.tabProfessional.Controls.Add(this.gbProfessional);
            this.tabProfessional.Location = new System.Drawing.Point(4, 22);
            this.tabProfessional.Name = "tabProfessional";
            this.tabProfessional.Padding = new System.Windows.Forms.Padding(3);
            this.tabProfessional.Size = new System.Drawing.Size(495, 392);
            this.tabProfessional.TabIndex = 1;
            this.tabProfessional.Text = "Professional Details and Submission";
            // 
            // pnlButtons
            // 
            this.pnlButtons.Controls.Add(this.btnUpdate);
            this.pnlButtons.Controls.Add(this.btnView);
            this.pnlButtons.Controls.Add(this.btnClear);
            this.pnlButtons.Controls.Add(this.btnSubmit);
            this.pnlButtons.Location = new System.Drawing.Point(3, 280);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(489, 38);
            this.pnlButtons.TabIndex = 35;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(249, 5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(63, 28);
            this.btnUpdate.TabIndex = 24;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.update_Click);
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(116, 4);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(63, 28);
            this.btnView.TabIndex = 25;
            this.btnView.Text = "VIEW";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click_1);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(8, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(63, 28);
            this.btnClear.TabIndex = 26;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click_1);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(372, 5);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(106, 28);
            this.btnSubmit.TabIndex = 23;
            this.btnSubmit.Text = "SUBMIT";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click_1);
            // 
            // pnlDeclaration
            // 
            this.pnlDeclaration.Controls.Add(this.tbConfirmation);
            this.pnlDeclaration.Controls.Add(this.cbDeclaration);
            this.pnlDeclaration.Location = new System.Drawing.Point(3, 228);
            this.pnlDeclaration.Name = "pnlDeclaration";
            this.pnlDeclaration.Size = new System.Drawing.Size(489, 38);
            this.pnlDeclaration.TabIndex = 34;
            // 
            // tbConfirmation
            // 
            this.tbConfirmation.Location = new System.Drawing.Point(35, 1);
            this.tbConfirmation.Multiline = true;
            this.tbConfirmation.Name = "tbConfirmation";
            this.tbConfirmation.ReadOnly = true;
            this.tbConfirmation.Size = new System.Drawing.Size(453, 36);
            this.tbConfirmation.TabIndex = 1;
            this.tbConfirmation.Text = "I hereby declare that the details furnished above are true and correct to the bes" +
    "t of my knowledge.";
            // 
            // cbDeclaration
            // 
            this.cbDeclaration.AutoSize = true;
            this.cbDeclaration.Location = new System.Drawing.Point(8, 11);
            this.cbDeclaration.Name = "cbDeclaration";
            this.cbDeclaration.Size = new System.Drawing.Size(15, 14);
            this.cbDeclaration.TabIndex = 22;
            this.cbDeclaration.UseVisualStyleBackColor = true;
            this.cbDeclaration.CheckedChanged += new System.EventHandler(this.cbDeclaration_CheckedChanged);
            this.cbDeclaration.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbDeclaration_KeyDown);
            // 
            // gbProfessional
            // 
            this.gbProfessional.Controls.Add(this.mtbOfficial);
            this.gbProfessional.Controls.Add(this.lblContactOfficial);
            this.gbProfessional.Controls.Add(this.lbSkills);
            this.gbProfessional.Controls.Add(this.lblSkills);
            this.gbProfessional.Controls.Add(this.txtEducational);
            this.gbProfessional.Controls.Add(this.lblEducation);
            this.gbProfessional.Controls.Add(this.cbJobLocation);
            this.gbProfessional.Controls.Add(this.lblJobLocation);
            this.gbProfessional.Controls.Add(this.txtCTC);
            this.gbProfessional.Controls.Add(this.lblCTC);
            this.gbProfessional.Controls.Add(this.cbDesignation);
            this.gbProfessional.Controls.Add(this.lblDesignation);
            this.gbProfessional.Location = new System.Drawing.Point(3, 6);
            this.gbProfessional.Name = "gbProfessional";
            this.gbProfessional.Size = new System.Drawing.Size(490, 204);
            this.gbProfessional.TabIndex = 31;
            this.gbProfessional.TabStop = false;
            this.gbProfessional.Text = "ACADEMIC AND PROFESSIONAL DETAILS";
            // 
            // mtbOfficial
            // 
            this.mtbOfficial.Location = new System.Drawing.Point(182, 109);
            this.mtbOfficial.Mask = "0000000000";
            this.mtbOfficial.Name = "mtbOfficial";
            this.mtbOfficial.Size = new System.Drawing.Size(121, 20);
            this.mtbOfficial.TabIndex = 18;
            // 
            // lblContactOfficial
            // 
            this.lblContactOfficial.AutoSize = true;
            this.lblContactOfficial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactOfficial.Location = new System.Drawing.Point(8, 112);
            this.lblContactOfficial.Name = "lblContactOfficial";
            this.lblContactOfficial.Size = new System.Drawing.Size(116, 15);
            this.lblContactOfficial.TabIndex = 40;
            this.lblContactOfficial.Text = "Official Contact No : ";
            // 
            // lbSkills
            // 
            this.lbSkills.FormattingEnabled = true;
            this.lbSkills.Items.AddRange(new object[] {
            "JAVA",
            "C#",
            "C++",
            "HTML",
            "Python",
            "Android",
            "C Language",
            "Web Development"});
            this.lbSkills.Location = new System.Drawing.Point(182, 156);
            this.lbSkills.Name = "lbSkills";
            this.lbSkills.ScrollAlwaysVisible = true;
            this.lbSkills.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbSkills.Size = new System.Drawing.Size(192, 30);
            this.lbSkills.TabIndex = 21;
            // 
            // lblSkills
            // 
            this.lblSkills.AutoSize = true;
            this.lblSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSkills.Location = new System.Drawing.Point(8, 164);
            this.lblSkills.Name = "lblSkills";
            this.lblSkills.Size = new System.Drawing.Size(98, 15);
            this.lblSkills.TabIndex = 31;
            this.lblSkills.Text = "Technical Skills :";
            // 
            // txtEducational
            // 
            this.txtEducational.Location = new System.Drawing.Point(182, 133);
            this.txtEducational.Name = "txtEducational";
            this.txtEducational.Size = new System.Drawing.Size(192, 20);
            this.txtEducational.TabIndex = 19;
            // 
            // lblEducation
            // 
            this.lblEducation.AutoSize = true;
            this.lblEducation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEducation.Location = new System.Drawing.Point(8, 135);
            this.lblEducation.Name = "lblEducation";
            this.lblEducation.Size = new System.Drawing.Size(122, 15);
            this.lblEducation.TabIndex = 28;
            this.lblEducation.Text = "Educational Details : ";
            // 
            // cbJobLocation
            // 
            this.cbJobLocation.FormattingEnabled = true;
            this.cbJobLocation.Items.AddRange(new object[] {
            "Chennai",
            "Thiruvananthapuram",
            "Bangalore",
            "Others (India)",
            "Others (Other than India)"});
            this.cbJobLocation.Location = new System.Drawing.Point(182, 81);
            this.cbJobLocation.Name = "cbJobLocation";
            this.cbJobLocation.Size = new System.Drawing.Size(192, 21);
            this.cbJobLocation.TabIndex = 17;
            // 
            // lblJobLocation
            // 
            this.lblJobLocation.AutoSize = true;
            this.lblJobLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobLocation.Location = new System.Drawing.Point(8, 81);
            this.lblJobLocation.Name = "lblJobLocation";
            this.lblJobLocation.Size = new System.Drawing.Size(83, 15);
            this.lblJobLocation.TabIndex = 26;
            this.lblJobLocation.Text = "Job Location :";
            // 
            // txtCTC
            // 
            this.txtCTC.Location = new System.Drawing.Point(182, 53);
            this.txtCTC.Name = "txtCTC";
            this.txtCTC.Size = new System.Drawing.Size(192, 20);
            this.txtCTC.TabIndex = 16;
            // 
            // lblCTC
            // 
            this.lblCTC.AutoSize = true;
            this.lblCTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCTC.Location = new System.Drawing.Point(8, 55);
            this.lblCTC.Name = "lblCTC";
            this.lblCTC.Size = new System.Drawing.Size(96, 15);
            this.lblCTC.TabIndex = 24;
            this.lblCTC.Text = "CTC (in Lakhs) : ";
            // 
            // cbDesignation
            // 
            this.cbDesignation.FormattingEnabled = true;
            this.cbDesignation.Items.AddRange(new object[] {
            "Trainee Engineer",
            "Software Engineer",
            "Senior Software Engineer",
            "Project Lead",
            "Project Manager",
            "Senior Manager"});
            this.cbDesignation.Location = new System.Drawing.Point(182, 24);
            this.cbDesignation.Name = "cbDesignation";
            this.cbDesignation.Size = new System.Drawing.Size(192, 21);
            this.cbDesignation.TabIndex = 15;
            this.cbDesignation.SelectedIndexChanged += new System.EventHandler(this.cbDesignation_SelectedIndexChanged);
            this.cbDesignation.SelectedValueChanged += new System.EventHandler(this.cbDesignation_SelectedValueChanged);
            // 
            // lblDesignation
            // 
            this.lblDesignation.AutoSize = true;
            this.lblDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesignation.Location = new System.Drawing.Point(8, 24);
            this.lblDesignation.Name = "lblDesignation";
            this.lblDesignation.Size = new System.Drawing.Size(79, 15);
            this.lblDesignation.TabIndex = 24;
            this.lblDesignation.Text = "Designation :";
            // 
            // EMS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(521, 574);
            this.Controls.Add(this.msEMS);
            this.Controls.Add(this.ssEmployee);
            this.Controls.Add(this.pnlForm);
            this.Name = "EMS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "EMS";
            this.Load += new System.EventHandler(this.EMS_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.msEMS.ResumeLayout(false);
            this.msEMS.PerformLayout();
            this.ssEmployee.ResumeLayout(false);
            this.ssEmployee.PerformLayout();
            this.pnlForm.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPersonal.ResumeLayout(false);
            this.gbPersonal.ResumeLayout(false);
            this.gbPersonal.PerformLayout();
            this.tabProfessional.ResumeLayout(false);
            this.pnlButtons.ResumeLayout(false);
            this.pnlDeclaration.ResumeLayout(false);
            this.pnlDeclaration.PerformLayout();
            this.gbProfessional.ResumeLayout(false);
            this.gbProfessional.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripStatusLabel ssLabel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.Label lblEmpId;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.MenuStrip msEMS;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem validateAndSubmitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveForLaterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolTip ttEmployee;
        private System.Windows.Forms.StatusStrip ssEmployee;
        private System.Windows.Forms.ToolStripStatusLabel ssTime;
        private System.Windows.Forms.Panel pnlForm;
        private System.Windows.Forms.ToolStripMenuItem goToMenuToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPersonal;
        private System.Windows.Forms.TabPage tabProfessional;
        private System.Windows.Forms.GroupBox gbPersonal;
        private System.Windows.Forms.MaskedTextBox mtbPersonal;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblContactPersonal;
        private System.Windows.Forms.CheckBox cbSameAsPerm;
        private System.Windows.Forms.Label lblTempPin;
        private System.Windows.Forms.TextBox txtTempPin;
        private System.Windows.Forms.TextBox txtTempAddress;
        private System.Windows.Forms.Label lblTempAddress;
        private System.Windows.Forms.Label lblPermPIN;
        private System.Windows.Forms.TextBox txtPermPIN;
        private System.Windows.Forms.TextBox txtPermAddress;
        private System.Windows.Forms.Label lblPermAddress;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.RadioButton rbTG;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.ComboBox cbIdType;
        private System.Windows.Forms.TextBox txtIdCardNo;
        private System.Windows.Forms.Label lblIdCard;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.GroupBox gbProfessional;
        private System.Windows.Forms.MaskedTextBox mtbOfficial;
        private System.Windows.Forms.Label lblContactOfficial;
        private System.Windows.Forms.ListBox lbSkills;
        private System.Windows.Forms.Label lblSkills;
        private System.Windows.Forms.TextBox txtEducational;
        private System.Windows.Forms.Label lblEducation;
        private System.Windows.Forms.ComboBox cbJobLocation;
        private System.Windows.Forms.Label lblJobLocation;
        private System.Windows.Forms.TextBox txtCTC;
        private System.Windows.Forms.Label lblCTC;
        private System.Windows.Forms.ComboBox cbDesignation;
        private System.Windows.Forms.Label lblDesignation;
        private System.Windows.Forms.Panel pnlDeclaration;
        private System.Windows.Forms.TextBox tbConfirmation;
        private System.Windows.Forms.CheckBox cbDeclaration;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnView1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ComboBox cbEmpId;
    }
}