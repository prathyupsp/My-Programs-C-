﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Data_Access_Layer.DAO;
using EmployeeManagementSystem.Business_Logic_Layer.BLL;
using System.Diagnostics;

namespace EmployeeManagementSystem.Presentation_Layer.View
{
    public partial class AddUserForm : Form
    {
        public AddUserForm()
        {
            InitializeComponent();
        }
        //method to add user
        private void btnAddUser_Click(object sender, EventArgs e)
        {
            User user = new User();
            try
            {
                if (ValidateUser())
                {
                    user.userName = txtUsername.Text.ToString();
                    user.password = txtReenterpassword.Text.ToString();
                    user.question = cbSecurity.SelectedItem.ToString();
                    user.answer = txtAnswer.Text.ToString();
                    user.userType = cbUserType.SelectedItem.ToString();
                    if (Employee_BLL.Get_users_Like(txtUsername.Text) == 0)
                    {
                        if (PersonalDetails.Add_User(user) > 0)
                            MessageBox.Show("User Added Successful !");
                        this.Close();
                    }
                }
                else
                    MessageBox.Show("Error :  Enter Complete Details");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error:  EmployeeManagementSystem.Presentation_Layer.View.AddUserForm btnAddUser_Click " + ex.Message.ToString());
            }
        }

        private void cbLoginType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
        //method to remove user
        private void btnRemoveUser_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtUsername.Text != null)
                    if (Employee_BLL.Delete_User(txtUsername.Text) > 0)
                    {
                        MessageBox.Show("User Removed Successful !");
                        this.Close();
                    }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("*** Error:  EmployeeManagementSystem.Presentation_Layer.View.AddUserForm btnAddUser_Click " + ex.Message.ToString());
            }
        }

        private void AddUserForm_Load(object sender, EventArgs e)
        {
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        //method to validate user
        private bool ValidateUser()
        {
            if (txtUsername.Text == "")
                return false;
            if (txtNewPassword.Text == "")
                return false;
            if (txtReenterpassword.Text != txtNewPassword.Text)
                return false;
            if (cbSecurity.SelectedItem == null)
                return false;
            if (cbUserType.SelectedItem == null)
                return false;
            if (txtAnswer.Text == "")
                return false;
            else
                return true;
        }

        private void lblUserType_Click(object sender, EventArgs e)
        {

        }
        
    }
}
