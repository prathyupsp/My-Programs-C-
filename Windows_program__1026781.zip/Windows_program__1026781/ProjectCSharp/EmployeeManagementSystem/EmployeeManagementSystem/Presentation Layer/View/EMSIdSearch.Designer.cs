﻿namespace EmployeeManagementSystem.Presentation_Layer.View
{
    partial class EMSIdSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMarkasEmployee = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.btnResigned = new System.Windows.Forms.Button();
            this.txtEmployeeId = new System.Windows.Forms.TextBox();
            this.cbOperation = new System.Windows.Forms.ComboBox();
            this.txtDetails2 = new System.Windows.Forms.TextBox();
            this.cbDetails2 = new System.Windows.Forms.ComboBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cbDetails1 = new System.Windows.Forms.ComboBox();
            this.lblEmployeeId = new System.Windows.Forms.Label();
            this.lblEnterId = new System.Windows.Forms.Label();
            this.btnGo = new System.Windows.Forms.Button();
            this.txtDetails1 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchUsingEmployeeIdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.sslSearchId = new System.Windows.Forms.ToolStripStatusLabel();
            this.dgvEmployee = new System.Windows.Forms.DataGridView();
            this.dgvProfessional = new System.Windows.Forms.DataGridView();
            this.lblTable1 = new System.Windows.Forms.Label();
            this.lblTable2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProfessional)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel1.Controls.Add(this.btnMarkasEmployee);
            this.panel1.Controls.Add(this.btnView);
            this.panel1.Controls.Add(this.btnResigned);
            this.panel1.Controls.Add(this.txtEmployeeId);
            this.panel1.Controls.Add(this.cbOperation);
            this.panel1.Controls.Add(this.txtDetails2);
            this.panel1.Controls.Add(this.cbDetails2);
            this.panel1.Controls.Add(this.lblTitle);
            this.panel1.Controls.Add(this.cbDetails1);
            this.panel1.Controls.Add(this.lblEmployeeId);
            this.panel1.Controls.Add(this.lblEnterId);
            this.panel1.Controls.Add(this.btnGo);
            this.panel1.Controls.Add(this.txtDetails1);
            this.panel1.Location = new System.Drawing.Point(21, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(315, 431);
            this.panel1.TabIndex = 1;
            // 
            // btnMarkasEmployee
            // 
            this.btnMarkasEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMarkasEmployee.Location = new System.Drawing.Point(15, 359);
            this.btnMarkasEmployee.Name = "btnMarkasEmployee";
            this.btnMarkasEmployee.Size = new System.Drawing.Size(121, 23);
            this.btnMarkasEmployee.TabIndex = 13;
            this.btnMarkasEmployee.Text = "Mark as Employee";
            this.btnMarkasEmployee.UseVisualStyleBackColor = true;
            this.btnMarkasEmployee.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnView
            // 
            this.btnView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.Location = new System.Drawing.Point(94, 317);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(121, 23);
            this.btnView.TabIndex = 12;
            this.btnView.Text = "View";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // btnResigned
            // 
            this.btnResigned.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResigned.Location = new System.Drawing.Point(175, 359);
            this.btnResigned.Name = "btnResigned";
            this.btnResigned.Size = new System.Drawing.Size(121, 23);
            this.btnResigned.TabIndex = 11;
            this.btnResigned.Text = "Mark as Resigned";
            this.btnResigned.UseVisualStyleBackColor = true;
            this.btnResigned.Click += new System.EventHandler(this.btnResigned_Click);
            // 
            // txtEmployeeId
            // 
            this.txtEmployeeId.Location = new System.Drawing.Point(94, 291);
            this.txtEmployeeId.Name = "txtEmployeeId";
            this.txtEmployeeId.ReadOnly = true;
            this.txtEmployeeId.Size = new System.Drawing.Size(121, 20);
            this.txtEmployeeId.TabIndex = 10;
            this.txtEmployeeId.TextChanged += new System.EventHandler(this.txtEmployeeId_TextChanged);
            // 
            // cbOperation
            // 
            this.cbOperation.FormattingEnabled = true;
            this.cbOperation.Items.AddRange(new object[] {
            "AND",
            "OR"});
            this.cbOperation.Location = new System.Drawing.Point(119, 124);
            this.cbOperation.Name = "cbOperation";
            this.cbOperation.Size = new System.Drawing.Size(69, 21);
            this.cbOperation.TabIndex = 9;
            this.cbOperation.Text = "AND/OR";
            // 
            // txtDetails2
            // 
            this.txtDetails2.Location = new System.Drawing.Point(175, 155);
            this.txtDetails2.Name = "txtDetails2";
            this.txtDetails2.Size = new System.Drawing.Size(121, 20);
            this.txtDetails2.TabIndex = 8;
            // 
            // cbDetails2
            // 
            this.cbDetails2.FormattingEnabled = true;
            this.cbDetails2.Items.AddRange(new object[] {
            "employeeId",
            "employeeName",
            "govIdType",
            "govIdNo",
            "gender",
            "permanentPin",
            "tempPin",
            "skills",
            "ctc",
            "designation",
            "jobLocation",
            "status"});
            this.cbDetails2.Location = new System.Drawing.Point(15, 151);
            this.cbDetails2.Name = "cbDetails2";
            this.cbDetails2.Size = new System.Drawing.Size(121, 21);
            this.cbDetails2.TabIndex = 7;
            this.cbDetails2.Text = "Select an Item";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(41, 11);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(237, 14);
            this.lblTitle.TabIndex = 6;
            this.lblTitle.Text = "EMPLOYEE MANAGEMENT SYSTEM";
            // 
            // cbDetails1
            // 
            this.cbDetails1.FormattingEnabled = true;
            this.cbDetails1.Items.AddRange(new object[] {
            "employeeId",
            "employeeName",
            "govIdType",
            "govIdNo",
            "gender",
            "permanentPin",
            "tempPin",
            "skills",
            "ctc",
            "designation",
            "jobLocation",
            "status"});
            this.cbDetails1.Location = new System.Drawing.Point(15, 95);
            this.cbDetails1.Name = "cbDetails1";
            this.cbDetails1.Size = new System.Drawing.Size(121, 21);
            this.cbDetails1.TabIndex = 5;
            this.cbDetails1.Text = "Select an Item";
            this.cbDetails1.SelectedIndexChanged += new System.EventHandler(this.cbDetails1_SelectedIndexChanged);
            // 
            // lblEmployeeId
            // 
            this.lblEmployeeId.AutoSize = true;
            this.lblEmployeeId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeId.Location = new System.Drawing.Point(34, 67);
            this.lblEmployeeId.Name = "lblEmployeeId";
            this.lblEmployeeId.Size = new System.Drawing.Size(0, 16);
            this.lblEmployeeId.TabIndex = 4;
            // 
            // lblEnterId
            // 
            this.lblEnterId.AutoSize = true;
            this.lblEnterId.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterId.Location = new System.Drawing.Point(61, 45);
            this.lblEnterId.Name = "lblEnterId";
            this.lblEnterId.Size = new System.Drawing.Size(193, 13);
            this.lblEnterId.TabIndex = 3;
            this.lblEnterId.Text = "Enter Details to be Searched";
            // 
            // btnGo
            // 
            this.btnGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGo.Location = new System.Drawing.Point(84, 187);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(148, 23);
            this.btnGo.TabIndex = 2;
            this.btnGo.Text = "Go / Refresh";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtDetails1
            // 
            this.txtDetails1.Location = new System.Drawing.Point(176, 95);
            this.txtDetails1.Name = "txtDetails1";
            this.txtDetails1.Size = new System.Drawing.Size(121, 20);
            this.txtDetails1.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(905, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchUsingEmployeeIdToolStripMenuItem,
            this.searchToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // searchUsingEmployeeIdToolStripMenuItem
            // 
            this.searchUsingEmployeeIdToolStripMenuItem.Name = "searchUsingEmployeeIdToolStripMenuItem";
            this.searchUsingEmployeeIdToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.searchUsingEmployeeIdToolStripMenuItem.Text = "Search using Employee Id";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.searchToolStripMenuItem.Text = "Search";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sslSearchId});
            this.statusStrip1.Location = new System.Drawing.Point(0, 569);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(905, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // sslSearchId
            // 
            this.sslSearchId.BackColor = System.Drawing.SystemColors.Control;
            this.sslSearchId.Name = "sslSearchId";
            this.sslSearchId.Size = new System.Drawing.Size(42, 17);
            this.sslSearchId.Text = "Search";
            // 
            // dgvEmployee
            // 
            this.dgvEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployee.Location = new System.Drawing.Point(391, 54);
            this.dgvEmployee.Name = "dgvEmployee";
            this.dgvEmployee.Size = new System.Drawing.Size(460, 234);
            this.dgvEmployee.TabIndex = 4;
            this.dgvEmployee.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmployee_CellClick);
            this.dgvEmployee.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmployee_CellContentClick);
            this.dgvEmployee.SelectionChanged += new System.EventHandler(this.dgvEmployee_SelectionChanged);
            // 
            // dgvProfessional
            // 
            this.dgvProfessional.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProfessional.Location = new System.Drawing.Point(391, 316);
            this.dgvProfessional.Name = "dgvProfessional";
            this.dgvProfessional.Size = new System.Drawing.Size(460, 233);
            this.dgvProfessional.TabIndex = 5;
            this.dgvProfessional.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProfessional_CellContentClick);
            this.dgvProfessional.SelectionChanged += new System.EventHandler(this.dgvProfessional_SelectionChanged);
            // 
            // lblTable1
            // 
            this.lblTable1.AutoSize = true;
            this.lblTable1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTable1.Location = new System.Drawing.Point(539, 35);
            this.lblTable1.Name = "lblTable1";
            this.lblTable1.Size = new System.Drawing.Size(156, 16);
            this.lblTable1.TabIndex = 6;
            this.lblTable1.Text = "PERSONAL DETAILS";
            // 
            // lblTable2
            // 
            this.lblTable2.AutoSize = true;
            this.lblTable2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTable2.Location = new System.Drawing.Point(526, 297);
            this.lblTable2.Name = "lblTable2";
            this.lblTable2.Size = new System.Drawing.Size(190, 16);
            this.lblTable2.TabIndex = 7;
            this.lblTable2.Text = "PROFESSIONAL DETAILS";
            // 
            // EMSIdSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(905, 591);
            this.Controls.Add(this.lblTable2);
            this.Controls.Add(this.lblTable1);
            this.Controls.Add(this.dgvProfessional);
            this.Controls.Add(this.dgvEmployee);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "EMSIdSearch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Search Using Id";
            this.Load += new System.EventHandler(this.EMSIdSearch_Load);
            this.MouseHover += new System.EventHandler(this.EMSIdSearch_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProfessional)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblEnterId;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.TextBox txtDetails1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchUsingEmployeeIdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.Label lblEmployeeId;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel sslSearchId;
        private System.Windows.Forms.ComboBox cbDetails1;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtDetails2;
        private System.Windows.Forms.ComboBox cbDetails2;
        private System.Windows.Forms.ComboBox cbOperation;
        private System.Windows.Forms.DataGridView dgvEmployee;
        private System.Windows.Forms.DataGridView dgvProfessional;
        private System.Windows.Forms.Label lblTable1;
        private System.Windows.Forms.Label lblTable2;
        private System.Windows.Forms.Button btnResigned;
        private System.Windows.Forms.TextBox txtEmployeeId;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Button btnMarkasEmployee;
    }
}