﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using EmployeeManagementSystem.Helper;
using EmployeeManagementSystem.Business_Logic_Layer.DTO;
using EmployeeManagementSystem.Business_Logic_Layer.BLL;

namespace EmployeeManagementSystem.Presentation_Layer.View
{
    public partial class EMS : Form
    {      
        public EMS()
        {
            InitializeComponent();
            //Tool Tip
            ttEmployee.SetToolTip(txtEmployeeID, "Employee ID");
            ttEmployee.SetToolTip(txtName, "Employee Name");
            ttEmployee.SetToolTip(txtAge, "Age");
            ttEmployee.SetToolTip(dtpDOB, "Date Of Birth");
            ttEmployee.SetToolTip(cbIdType, "Type of Goverment issued ID Card");
            ttEmployee.SetToolTip(txtIdCardNo, "Goverment issued ID Card Number");
            ttEmployee.SetToolTip(rbFemale, "Female");
            ttEmployee.SetToolTip(rbMale, "Male");
            ttEmployee.SetToolTip(rbTG, "Transgender");
            ttEmployee.SetToolTip(txtPermAddress, "Permanent Address");
            ttEmployee.SetToolTip(txtPermPIN, "PIN");
            ttEmployee.SetToolTip(txtTempAddress, "Communication Address/Temporary Address");
            ttEmployee.SetToolTip(txtTempPin, "PIN");
            ttEmployee.SetToolTip(txtEmail, "Email ID");
            ttEmployee.SetToolTip(mtbOfficial, "Official Contact Number");
            ttEmployee.SetToolTip(mtbPersonal, "Personal Contact Number");
            ttEmployee.SetToolTip(cbDesignation, "Designation");
            ttEmployee.SetToolTip(cbJobLocation, "Job Location");
            ttEmployee.SetToolTip(cbSameAsPerm, "Same as Permanent Address");
            ttEmployee.SetToolTip(txtCTC, "Total Cost To Company");
            ttEmployee.SetToolTip(txtEducational, "Educational Details");
            ttEmployee.SetToolTip(lbSkills, "Additional Skills");
            ttEmployee.SetToolTip(btnClear, "Clear the form");

            ttEmployee.SetToolTip(btnSubmit, "Validate and Submit the Form");
            //status strip
            ssTime.Text = "                                                                             Today : " + DateTime.Now.ToShortDateString();

            if (cbDesignation.SelectedItem == null)
                txtEmployeeID.Text = "Employee Id will be generated Later";

        }

        private void txtPermAddress_TextChanged(object sender, EventArgs e)
        {

        }
        //method to clear the form
        private void Clear()
        {
            txtAge.Text = "";
            txtCTC.Text = "";
            txtEducational.Text = "";
            txtEmail.Text = "";
            txtEmployeeID.Text = "";
            txtIdCardNo.Text = "";
            txtName.Text = "";
            txtPermAddress.Text = "";
            txtPermPIN.Text = "";
            txtTempAddress.Text = "";
            txtTempPin.Text = "";
            txtEmployeeID.Text = "";
            cbDesignation.SelectedItem = null;
            cbIdType.SelectedItem = null;
            cbJobLocation.SelectedItem = null;
            cbSameAsPerm.Checked = false;
            rbFemale.Checked = false;
            rbMale.Checked = false;
            rbTG.Checked = false;
            lbSkills.SelectedItem = null;
            mtbOfficial.Text = "";
            mtbPersonal.Text = "";
            cbDeclaration.Checked = false;
            dtpDOB.Text = DateTime.Now.ToShortDateString();
        }
        //clear button in Edit menu
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Clear the form? : ", "E M S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //If YES button is clicked in the message box
                Clear();        //invoke method to clear
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Exit from the Application ? ", "E M S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //If YES button is clicked in the message box
                Environment.Exit(1);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Clear the form? ", "E M S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //If YES button is clicked in the message box
                Clear();        //invoke method to clear
            }
        }

        private void clearToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Clear the form? ", "E M S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //If YES button is clicked in the message box
                Clear();        //invoke method to clear
            }
        }

        private void btnClear_MouseHover(object sender, EventArgs e)
        {
            ssLabel1.Text = "Clear the Form";       //status strip
        }

        private void btnSave_MouseHover(object sender, EventArgs e)
        {
            ssLabel1.Text = "Save form for later";       //status strip
        }

        private void btnSubmit_MouseHover(object sender, EventArgs e)
        {
            ssLabel1.Text = "Validate and Submit the form";       //status strip
        }
        //check for empty inputs
        private bool Validate()
        {
            try
            {
                if (txtName.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtName.Focus();
                    return false;
                }
                if (txtIdCardNo.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtIdCardNo.Focus();
                    return false;
                }
                if (txtPermAddress.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtPermAddress.Focus();
                    return false;
                }
                if (txtPermPIN.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtPermPIN.Focus();
                    return false;
                }
                if (txtTempAddress.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtTempAddress.Focus();
                    return false;
                }
                if (txtAge.Text == "" || Convert.ToInt32(txtAge.Text.ToString()) < 20)
                {
                    MessageBox.Show("Enter valid DOB");
                    dtpDOB.Focus();
                    return false;
                }
                if (txtCTC.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtCTC.Focus();
                    return false;
                }
                if (txtEducational.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtEducational.Focus();
                    return false;
                }
                if (txtPermPIN.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtPermPIN.Focus();
                    return false;
                }
                if (txtTempPin.Text == "")
                {
                    MessageBox.Show("Enter all details");
                    txtTempPin.Focus();
                    return false;
                }
                if (cbDeclaration.Checked == false)
                {
                    MessageBox.Show("Declaration error");
                    return false;
                }
                if (rbFemale.Checked == false && rbMale.Checked == false && rbTG.Checked == false)
                {
                    MessageBox.Show("Enter all details");
                    return false;
                }
                if (cbDesignation.SelectedItem == null)
                {
                    MessageBox.Show("Enter all details");
                    return false;
                }
                if (cbIdType.SelectedItem == null)
                {
                    MessageBox.Show("Enter all details");
                    return false;
                }
                if (cbJobLocation.Text == null)
                {
                    MessageBox.Show("Enter all details");
                    return false;
                }
                if (lbSkills.SelectedItem == null)
                {
                    MessageBox.Show("Enter all details");
                    return false;
                }
                if (mtbOfficial.Text == null)
                {
                    MessageBox.Show("Enter all details");
                    return false;
                }
                if (mtbPersonal.Text == null)
                {
                    MessageBox.Show("Enter all details");
                    return false;
                }
                string mail = txtEmail.Text.ToString();
                if (!Helper.Helper.ValidateEmail(mail))
                    return false;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Presentation_Layer.View.EMS / Validate ** " + ex.Message.ToString());
            }
            return true;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

        }

        private void dtpDOB_ValueChanged(object sender, EventArgs e)
        {

        }
        //method to set permanent address as temporary address
        private void cbSameAsPerm_CheckedChanged(object sender, EventArgs e)
        {
            if (cbSameAsPerm.Checked == true)
            {
                txtTempAddress.Text = txtPermAddress.Text;
                txtTempPin.Text = txtPermPIN.Text;
            }
            else
            {
                txtTempAddress.Text = "";
                txtTempPin.Text = "";
            }
        }

        private void gbPersonal_Enter(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Exit from the form? ", "E M S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //If YES button is clicked in the message box
                Environment.Exit(1);        //invoke method to exit
            }
        }

        private void EMS_Load(object sender, EventArgs e)
        {
            cbEmpId.Visible = false;
            btnUpdate.Enabled = false;
        }

        private void btnView_Click(object sender, EventArgs e)
        {

        }
        //method for generating Employee Id
        private static int GenerateId()
        {
            int empid=0;
            empid=Employee_BLL.Read_All_Employee().Tables[0].Columns[0].ToString().Substring(3).Max()+1;
            return empid;
        }
        //method to load Menu Form
        private void goToMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            menuForm objMenu = new menuForm();
            objMenu.Show();
            Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cbDesignation_SelectedValueChanged(object sender, EventArgs e)
        {
            

        }
        //method to submit the data
        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
            int output1 = 0, output2 = 0, output3 = 0;
            try
            {
                if (Validate())
                {
                    if (cbDesignation.SelectedItem != null)
                    {
                        string id;
                        txtEmployeeID.Text = Helper.Helper.GenerateId(cbDesignation.SelectedItem.ToString());
                        MessageBox.Show("New Employee ID Generated Successfully.\n Employee ID : " + txtEmployeeID.Text);
                    }
                    Employee employee = new Employee();
                    employee.employeeId = txtEmployeeID.Text;
                    employee.employeeName = txtName.Text;
                    employee.govIdType = cbIdType.SelectedItem.ToString();
                    employee.govIdNo = txtIdCardNo.Text;
                    if (rbFemale.Checked == true)
                        employee.gender = "female";
                    else if (rbMale.Checked == true)
                        employee.gender = "male";
                    else
                        employee.gender = "TG";
                    employee.dob = dtpDOB.Value.ToShortDateString();
                    employee.permanentAddress = txtPermAddress.Text;
                    employee.tempAddress = txtTempAddress.Text;
                    employee.permanentPin = Convert.ToInt32(txtPermPIN.Text);
                    employee.tempPin = Convert.ToInt32(txtTempPin.Text);
                    employee.personalContact = mtbPersonal.Text;
                    employee.officialContact = mtbOfficial.Text;
                    employee.emailId = txtEmail.Text;
                    employee.designation = cbDesignation.SelectedItem.ToString();
                    employee.ctc = Convert.ToDouble(txtCTC.Text);
                    employee.jobLocation = cbJobLocation.SelectedItem.ToString();
                    employee.education = txtEducational.Text;
                    employee.skills = "";
                    var lst = lbSkills.SelectedItems;
                    foreach (var item in lst)
                    {
                        employee.skills += item.ToString();
                    }
                    employee.status = "Employee";
                    output1 = Employee_BLL.Insert_Employee_Personal(employee);
                    output3 = Employee_BLL.Insert_Employee_ID(employee);
                    output2 = Employee_BLL.Insert_Employee_Professional(employee);
                    Debug.WriteLine(output1 + output2 + output3);
                    if (output1 > 0 && output2 > 0 && output3 > 0)
                    {
                        MessageBox.Show("employee Details Updated Successfully !!", "employee");
                        btnSubmit.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("ERROR !!!", "employee");
                    }
                }
                else
                    MessageBox.Show("error");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Presentation_Layer.View.EMS / SUBMIT Button ** " + ex.Message.ToString());
            }
        }
        //method to view all the details of an employee
        private void btnView_Click_1(object sender, EventArgs e)
        {
            Read_All_Employee();
        }

        private void cbSameAsPerm_CheckedChanged_1(object sender, EventArgs e)
        {
            if (cbSameAsPerm.Checked == true)
            {
                txtTempAddress.Text = txtPermAddress.Text;
                txtTempPin.Text = txtPermPIN.Text;
            }
            else
            {
                txtTempAddress.Text = "";
                txtTempPin.Text = "";
            }
        }

        private void dtpDOB_ValueChanged_1(object sender, EventArgs e)
        {
            txtAge.Text = (Convert.ToInt32(DateTime.Now.Year) - Convert.ToInt32(dtpDOB.Value.Year)).ToString();
        }
        //method to clear the form
        private void btnClear_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Clear the form? ", "E M S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //If YES button is clicked in the message box
                Clear();        //invoke method to clear
                btnSubmit.Enabled = true;
            }
        }
        //read all
        private static void Read_All_Employee()
        {
            DataSet dataset = null;
            try
            {
                dataset = Employee_BLL.Read_All_Employee();
                if (dataset != null)
                {
                    MessageBox.Show(dataset.Tables[0].ToString());
                }
                else
                {
                    MessageBox.Show("No student details available");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("** EmployeeManagementSystem.Presentation_Layer.View.EMS / Read_All_Employee ** " + ex.Message.ToString());
            }
        }
       public  void MakeReadonly()
        {
           
        }
        //method to view all the details
       private void btnView1_Click(object sender, EventArgs e)
       {
           if(btnView1.Text=="Edit")
           {
               cbEmpId.Visible = true;
               btnView1.Text = "View";
               LoadCombo();
               txtEmployeeID.Visible = false;
               btnUpdate.Enabled = false;
               btnSubmit.Enabled = true;
               
           }
           else
           {
               Employee employee = null;
               txtEmployeeID.Text = cbEmpId.SelectedValue.ToString();
               string employeeId = txtEmployeeID.Text;
               employee = Employee_BLL.Get_EmployeeProfessional(employeeId);
               SetEmployee(employee);
               btnView1.Text = "Edit";
               cbEmpId.Visible = false;
               txtEmployeeID.Visible = true;
               txtEmployeeID.ReadOnly = true;
               btnUpdate.Enabled = true;
               btnSubmit.Enabled = false;
           }
       }
        //method to get all the details
       private void LoadCombo()
       {
           DataSet dataset = Employee_BLL.Read_All_Employee();
           cbEmpId.DataSource = dataset.Tables[0];
           cbEmpId.ValueMember = "employeeId";
           cbEmpId.DisplayMember = "employeeId";
       }

       private void txtEmployeeID_TextChanged(object sender, EventArgs e)
       {

       }

       private void cbDesignation_SelectedIndexChanged(object sender, EventArgs e)
       {

       }
        //method to set employee details
       public void SetEmployee(Employee employee)
       {
               try
               {
                   string employeeId = employee.employeeId;
                   btnView1.Text = "Edit";
                   txtEmployeeID.ReadOnly = true;
                   cbDesignation.SelectedItem = employee.designation.ToString();
                   txtCTC.Text = employee.ctc.ToString();
                   mtbOfficial.Text = employee.officialContact;
                   cbJobLocation.SelectedItem = employee.jobLocation;
                   employee = Employee_BLL.Get_EmployeePersonal(employeeId);
                   txtName.Text = employee.employeeName;
                   cbIdType.SelectedItem = employee.govIdType;
                   txtIdCardNo.Text = employee.govIdNo.ToString();
                   if (employee.gender == "Male")
                   {
                       rbMale.Checked = true;
                   }
                   else if (employee.gender == "Female")
                       rbFemale.Checked = true;
                   else
                       rbTG.Checked = true;
                   dtpDOB.Value = Convert.ToDateTime(employee.dob);
                   txtPermAddress.Text = employee.permanentAddress;
                   txtPermPIN.Text = employee.permanentPin.ToString();
                   txtTempAddress.Text = employee.tempAddress;
                   txtTempPin.Text = employee.tempPin.ToString();
                   mtbPersonal.Text = employee.personalContact;
                   txtEmail.Text = employee.emailId;
                   txtEducational.Text = employee.education;
                   if (employee.skills.Contains("JAVA"))
                       lbSkills.SelectedItem = "JAVA";
                   if (employee.skills.Contains("C#"))
                       lbSkills.SelectedItem = "C#";
                   if (employee.skills.Contains("C++"))
                       lbSkills.SelectedItem = "C++";
                   if (employee.skills.Contains("HTML"))
                       lbSkills.SelectedItem = "HTML";
                   if (employee.skills.Contains("Python"))
                       lbSkills.SelectedItem = "Python";
                   if (employee.skills.Contains("Android"))
                       lbSkills.SelectedItem = "Android";
                   if (employee.skills.Contains("C Language"))
                       lbSkills.SelectedItem = "C Language";
                   if (employee.skills.Contains("Web Development"))
                       lbSkills.SelectedItem = "Web Development";
               }
               catch (Exception ex)
               {

                   Debug.WriteLine("*** Error: EmployeeManagementSystem.Presentation_Layer.View.EMS  / SetEmployee " + ex.Message.ToString());
               }
       }
        //method to update employee details
       private void update_Click(object sender, EventArgs e)
       {
           Employee employee=new Employee();
           try
           {
               if(Validate())
               {
                   employee.employeeId = txtEmployeeID.Text;
                   employee.employeeName = txtName.Text;
                   employee.govIdType = cbIdType.SelectedItem.ToString();
                   employee.govIdNo = txtIdCardNo.Text;
                   if (rbMale.Checked == true)
                       employee.gender = "Male";
                   else if (rbFemale.Checked == true)
                       employee.gender = "Female";
                   else
                       employee.gender = "TG";
                   employee.dob = dtpDOB.Value.ToShortDateString();
                   employee.permanentAddress = txtPermAddress.Text;
                   employee.permanentPin = Convert.ToInt32(txtPermPIN.Text);
                   employee.tempAddress = txtTempAddress.Text;
                   employee.tempPin = Convert.ToInt32(txtTempPin.Text);
                   employee.designation = cbDesignation.SelectedItem.ToString();
                   employee.jobLocation = cbJobLocation.SelectedItem.ToString();
                   employee.ctc = Convert.ToInt32(txtCTC.Text);
                   employee.personalContact = mtbPersonal.Text;
                   employee.officialContact = mtbOfficial.Text;
                   employee.education = txtEducational.Text;
                   employee.emailId = txtEmail.Text;
                   employee.skills = "";
                   var lst = lbSkills.SelectedItems;
                   foreach (var item in lst)
                   {
                       employee.skills += item.ToString();
                   }
                   if (Employee_BLL.Update_Employee(employee) > 0)
                       MessageBox.Show("Updated Successfully");
                   else
                       MessageBox.Show("Error !!");
               }
               
           }
           catch (Exception ex)
           {

               Debug.WriteLine("*** Error: EmployeeManagementSystem.Presentation_Layer.View.EMS  / Update" + ex.Message.ToString());
           }
       }

       private void msEMS_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
       {

       }

       private void cbDeclaration_CheckedChanged(object sender, EventArgs e)
       {

       }

       private void cbDeclaration_KeyDown(object sender, KeyEventArgs e)
       {
           if (e.KeyCode == Keys.Enter)
               cbDeclaration.Checked = true;
       }

       private void rbMale_KeyDown(object sender, KeyEventArgs e)
       {
           if (e.KeyCode == Keys.Enter)
               rbMale.Checked = true;
       }

       private void rbFemale_KeyDown(object sender, KeyEventArgs e)
       {
           if (e.KeyCode == Keys.Enter)
               rbFemale.Checked = true;
       }

       private void rbTG_KeyDown(object sender, KeyEventArgs e)
       {
           if (e.KeyCode == Keys.Enter)
               rbTG.Checked = true;
       }

       private void cbSameAsPerm_KeyDown(object sender, KeyEventArgs e)
       {
           if (e.KeyCode == Keys.Enter)
               cbSameAsPerm.Checked = true;
       }           
    }
}