﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class calculator : Form
    {
        double result; 
        bool flag=false;
        char operation;
        public calculator()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }
//***********************************************************************************************************************************
        //button decimal point
        private void button10_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += ".";
        }
        //button AC
        private void button1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "0"; result = 0;
        }
        //result
        private void btnEqual_Click(object sender, EventArgs e)
        {
            if(operation=='+')
            {
                result += Convert.ToDouble(txtDisplay.Text);
                txtDisplay.Text = result.ToString();
            }
                
             if(operation=='-')
             {
                 result -= Convert.ToDouble(txtDisplay.Text);
                 txtDisplay.Text = result.ToString();
             }
             if(operation=='*')
             {
                 result *= Convert.ToDouble(txtDisplay.Text);
                 txtDisplay.Text = result.ToString();
             }
             if (operation == '/')
             {
                 result /= Convert.ToDouble(txtDisplay.Text);
                 txtDisplay.Text = result.ToString();
             }
             else
             {
                 result = Convert.ToDouble(txtDisplay.Text);
                 txtDisplay.Text = result.ToString();
             }

            operation = '=';
        }
        //backspace
        private void btnBackSpace_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text.Substring(0,txtDisplay.Text.Length-1);
        }

//***********************************************************************************************************************************

        //addition
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (operation == '=')
                result = 0;
            result += Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = result.ToString();
            flag = true;
            operation = '+';
        }
        //subtraction
        private void btnSubtract_Click(object sender, EventArgs e)
        {
            if (operation == '=')
                result = 0;
            if(result == 0)
                result = Convert.ToDouble(txtDisplay.Text);
            else
                result = result - Convert.ToDouble(txtDisplay.Text);
                txtDisplay.Text = result.ToString();
                flag = true;
                operation = '-';
        }
        //multiplication
        private void btnMultiplication_Click(object sender, EventArgs e)
        {
            if (operation == '=')
                result = 1;
            if (result == 0 && Convert.ToDouble(txtDisplay.Text) != 0)
                result = 1;
            
            result *= Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = result.ToString();
            flag = true;
            operation = '*';
        }
        //division
        private void btnDivision_Click(object sender, EventArgs e)
        {
            if (operation == '=')
                result = result*result;
            if (result == 0 && Convert.ToDouble(txtDisplay.Text) != 0)
                result = Convert.ToDouble(txtDisplay.Text);
            else
            {
                
                result /= Convert.ToDouble(txtDisplay.Text);
            }
            txtDisplay.Text = result.ToString();
            flag = true;
            operation = '/';
        }
        //plus or minus
        private void btnPlusMinus_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = (Convert.ToDouble(txtDisplay.Text) * (-1)).ToString();
        }

//*************************************************************************************************************************************
        
        //button 0
        private void btn0_Click(object sender, EventArgs e)
        {
            if(flag)
                txtDisplay.Text = "0";
            else
                txtDisplay.Text += "0";
        }
        //button 1
        private void btn1_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "1";
            else
                txtDisplay.Text += "1";
        }
        //button 2
        private void btn2_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "2";
            else
                txtDisplay.Text += "2";
        }
        //button 3
        private void btn3_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "3";
            else
                txtDisplay.Text += "3";
        }
        //button 4
        private void btn4_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "4";
            else
                txtDisplay.Text += "4";
        }
        //button 5
        private void btn5_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "5";
            else
                txtDisplay.Text += "5";
        }
        //button 6
        private void btn6_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "6";
            else
                txtDisplay.Text += "6";
        }
        //button 7
        private void btn9_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "7";
            else
                txtDisplay.Text += "7";
        }
        //button 8
        private void btn8_Click(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "8";
            else
                txtDisplay.Text += "8";
        }
        //button 9
        private void btn9_Click_1(object sender, EventArgs e)
        {
            if (flag)
                txtDisplay.Text = "9";
            else
                txtDisplay.Text += "9";
        }
        bool change = false;
        private void txtDisplay_TextChanged(object sender, EventArgs e)
        {
            change = true;
        }
        bool flagtxt;
        private void txtDisplay_KeyDown(object sender, KeyEventArgs e)
        {
            flagtxt = false;
            if (e.KeyCode == Keys.Add)
            {
                flagtxt = true;
                btnAdd.PerformClick();
                
            }
               
            if (e.KeyCode == Keys.Divide)
            {
                btnDivision.PerformClick();
                flagtxt = true;
            }
                
            if (e.KeyCode == Keys.Multiply)
            {
                btnMultiplication.PerformClick();
                flagtxt = true;
            }
               
            if (e.KeyCode == Keys.Subtract)
            {
                btnSubtract.PerformClick();
                flagtxt = true;
            }
                
        }

        private void txtDisplay_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = flagtxt;
        }
    }
}
