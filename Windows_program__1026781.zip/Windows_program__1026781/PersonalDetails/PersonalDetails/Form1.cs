﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonalDetails
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
                
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_4(object sender, EventArgs e)
        {

        }

        private void label1_Click_5(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtpDOB_ValueChanged(object sender, EventArgs e)
        {

        }

        private void rbFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cbSports_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cbReading_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cbDance_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblType_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //variable declaraion
            string name, gender=null, dob, mobileNumber, emailID, typeofaddress, address, interest = null;
            string output;
            //read and store values from form
            name = txtName.Text;
            if (rbMale.Checked == true)
                gender = "Male";
            if (rbFemale.Checked == true)
                gender = "Female";
            mobileNumber = txtMobile.Text;
            emailID = txtEmail.Text;
            typeofaddress = cmbType.Text.ToString();
            address = txtAddress.Text;
            dob = dtpDOB.Value.ToShortDateString();
            if (cbDance.Checked == true)
                interest += " Dance, ";
            if (cbSports.Checked == true)
                interest += " Sports, ";
            if (cbMusic.Checked == true)
                interest += " Music, ";
            if (cbReading.Checked == true)
                interest += "Reading, ";
            output = "Name : " + name + "\nGender : " + gender + "\nDOB : " + dob + "\nType of Address : " + typeofaddress + "\nAddress : "
                        + address + "\nInterests : " + interest + "\nMobile : " + mobileNumber + "\nEmail ID : " + emailID;
            MessageBox.Show(output, "PERSONAL DETAILS");        //display output
        }

    }
}
