﻿namespace PersonalDetails
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlPersonal = new System.Windows.Forms.Panel();
            this.gbCommunication = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEMailID = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.lblMobile = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.lblType = new System.Windows.Forms.Label();
            this.gbPersonal = new System.Windows.Forms.GroupBox();
            this.pnlInterest = new System.Windows.Forms.Panel();
            this.cbDance = new System.Windows.Forms.CheckBox();
            this.cbReading = new System.Windows.Forms.CheckBox();
            this.cbMusic = new System.Windows.Forms.CheckBox();
            this.cbSports = new System.Windows.Forms.CheckBox();
            this.lblInterest = new System.Windows.Forms.Label();
            this.pnlGender = new System.Windows.Forms.Panel();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.lblGender = new System.Windows.Forms.Label();
            this.pnlDOB = new System.Windows.Forms.Panel();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.lblDOB = new System.Windows.Forms.Label();
            this.pnlName = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnVerify = new System.Windows.Forms.Button();
            this.pnlPersonal.SuspendLayout();
            this.gbCommunication.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gbPersonal.SuspendLayout();
            this.pnlInterest.SuspendLayout();
            this.pnlGender.SuspendLayout();
            this.pnlDOB.SuspendLayout();
            this.pnlName.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlPersonal
            // 
            this.pnlPersonal.Controls.Add(this.gbCommunication);
            this.pnlPersonal.Controls.Add(this.gbPersonal);
            this.pnlPersonal.Location = new System.Drawing.Point(9, 38);
            this.pnlPersonal.Name = "pnlPersonal";
            this.pnlPersonal.Size = new System.Drawing.Size(607, 221);
            this.pnlPersonal.TabIndex = 0;
            // 
            // gbCommunication
            // 
            this.gbCommunication.Controls.Add(this.panel4);
            this.gbCommunication.Controls.Add(this.panel3);
            this.gbCommunication.Controls.Add(this.panel2);
            this.gbCommunication.Controls.Add(this.panel1);
            this.gbCommunication.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCommunication.Location = new System.Drawing.Point(321, 15);
            this.gbCommunication.Name = "gbCommunication";
            this.gbCommunication.Size = new System.Drawing.Size(273, 199);
            this.gbCommunication.TabIndex = 1;
            this.gbCommunication.TabStop = false;
            this.gbCommunication.Text = "COMMUNICATION";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtEmail);
            this.panel4.Controls.Add(this.lblEMailID);
            this.panel4.Location = new System.Drawing.Point(15, 154);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(252, 37);
            this.panel4.TabIndex = 2;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(92, 8);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(148, 20);
            this.txtEmail.TabIndex = 12;
            this.txtEmail.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // lblEMailID
            // 
            this.lblEMailID.AutoSize = true;
            this.lblEMailID.Location = new System.Drawing.Point(6, 11);
            this.lblEMailID.Name = "lblEMailID";
            this.lblEMailID.Size = new System.Drawing.Size(54, 13);
            this.lblEMailID.TabIndex = 0;
            this.lblEMailID.Text = "Email ID";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtMobile);
            this.panel3.Controls.Add(this.lblMobile);
            this.panel3.Location = new System.Drawing.Point(15, 113);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(252, 37);
            this.panel3.TabIndex = 2;
            // 
            // txtMobile
            // 
            this.txtMobile.Location = new System.Drawing.Point(92, 8);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(148, 20);
            this.txtMobile.TabIndex = 11;
            this.txtMobile.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lblMobile
            // 
            this.lblMobile.AutoSize = true;
            this.lblMobile.Location = new System.Drawing.Point(6, 11);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.Size = new System.Drawing.Size(44, 13);
            this.lblMobile.TabIndex = 0;
            this.lblMobile.Text = "Mobile";
            this.lblMobile.Click += new System.EventHandler(this.label1_Click_5);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtAddress);
            this.panel2.Controls.Add(this.lblAddress);
            this.panel2.Location = new System.Drawing.Point(15, 57);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(252, 52);
            this.panel2.TabIndex = 2;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(92, 5);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAddress.Size = new System.Drawing.Size(148, 41);
            this.txtAddress.TabIndex = 10;
            this.txtAddress.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(6, 18);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(52, 13);
            this.lblAddress.TabIndex = 0;
            this.lblAddress.Text = "Address";
            this.lblAddress.Click += new System.EventHandler(this.label1_Click_4);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cmbType);
            this.panel1.Controls.Add(this.lblType);
            this.panel1.Location = new System.Drawing.Point(15, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(252, 37);
            this.panel1.TabIndex = 2;
            // 
            // cmbType
            // 
            this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Items.AddRange(new object[] {
            "Personal",
            "Official",
            "Work",
            "Other"});
            this.cmbType.Location = new System.Drawing.Point(93, 9);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(156, 21);
            this.cmbType.TabIndex = 9;
            this.cmbType.Text = "Personal";
            this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cbType_SelectedIndexChanged);
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(13, 13);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(35, 13);
            this.lblType.TabIndex = 3;
            this.lblType.Text = "Type";
            this.lblType.Click += new System.EventHandler(this.lblType_Click);
            // 
            // gbPersonal
            // 
            this.gbPersonal.Controls.Add(this.pnlInterest);
            this.gbPersonal.Controls.Add(this.pnlGender);
            this.gbPersonal.Controls.Add(this.pnlDOB);
            this.gbPersonal.Controls.Add(this.pnlName);
            this.gbPersonal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPersonal.Location = new System.Drawing.Point(13, 15);
            this.gbPersonal.Name = "gbPersonal";
            this.gbPersonal.Size = new System.Drawing.Size(273, 199);
            this.gbPersonal.TabIndex = 0;
            this.gbPersonal.TabStop = false;
            this.gbPersonal.Text = "PERSONAL";
            // 
            // pnlInterest
            // 
            this.pnlInterest.Controls.Add(this.cbDance);
            this.pnlInterest.Controls.Add(this.cbReading);
            this.pnlInterest.Controls.Add(this.cbMusic);
            this.pnlInterest.Controls.Add(this.cbSports);
            this.pnlInterest.Controls.Add(this.lblInterest);
            this.pnlInterest.Location = new System.Drawing.Point(10, 142);
            this.pnlInterest.Name = "pnlInterest";
            this.pnlInterest.Size = new System.Drawing.Size(252, 47);
            this.pnlInterest.TabIndex = 4;
            // 
            // cbDance
            // 
            this.cbDance.AutoSize = true;
            this.cbDance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDance.Location = new System.Drawing.Point(170, 26);
            this.cbDance.Name = "cbDance";
            this.cbDance.Size = new System.Drawing.Size(58, 17);
            this.cbDance.TabIndex = 8;
            this.cbDance.Text = "Dance";
            this.cbDance.UseVisualStyleBackColor = true;
            this.cbDance.CheckedChanged += new System.EventHandler(this.cbDance_CheckedChanged);
            // 
            // cbReading
            // 
            this.cbReading.AutoSize = true;
            this.cbReading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbReading.Location = new System.Drawing.Point(95, 27);
            this.cbReading.Name = "cbReading";
            this.cbReading.Size = new System.Drawing.Size(66, 17);
            this.cbReading.TabIndex = 7;
            this.cbReading.Text = "Reading";
            this.cbReading.UseVisualStyleBackColor = true;
            this.cbReading.CheckedChanged += new System.EventHandler(this.cbReading_CheckedChanged);
            // 
            // cbMusic
            // 
            this.cbMusic.AutoSize = true;
            this.cbMusic.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMusic.Location = new System.Drawing.Point(170, 3);
            this.cbMusic.Name = "cbMusic";
            this.cbMusic.Size = new System.Drawing.Size(54, 17);
            this.cbMusic.TabIndex = 6;
            this.cbMusic.Text = "Music";
            this.cbMusic.UseVisualStyleBackColor = true;
            this.cbMusic.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // cbSports
            // 
            this.cbSports.AutoSize = true;
            this.cbSports.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSports.Location = new System.Drawing.Point(95, 4);
            this.cbSports.Name = "cbSports";
            this.cbSports.Size = new System.Drawing.Size(56, 17);
            this.cbSports.TabIndex = 5;
            this.cbSports.Text = "Sports";
            this.cbSports.UseVisualStyleBackColor = true;
            this.cbSports.CheckedChanged += new System.EventHandler(this.cbSports_CheckedChanged);
            // 
            // lblInterest
            // 
            this.lblInterest.AutoSize = true;
            this.lblInterest.Location = new System.Drawing.Point(7, 13);
            this.lblInterest.Name = "lblInterest";
            this.lblInterest.Size = new System.Drawing.Size(50, 13);
            this.lblInterest.TabIndex = 0;
            this.lblInterest.Text = "Interest";
            this.lblInterest.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // pnlGender
            // 
            this.pnlGender.Controls.Add(this.rbFemale);
            this.pnlGender.Controls.Add(this.rbMale);
            this.pnlGender.Controls.Add(this.lblGender);
            this.pnlGender.Location = new System.Drawing.Point(10, 100);
            this.pnlGender.Name = "pnlGender";
            this.pnlGender.Size = new System.Drawing.Size(252, 37);
            this.pnlGender.TabIndex = 3;
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbFemale.Location = new System.Drawing.Point(167, 10);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(59, 17);
            this.rbFemale.TabIndex = 4;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            this.rbFemale.CheckedChanged += new System.EventHandler(this.rbFemale_CheckedChanged);
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMale.Location = new System.Drawing.Point(93, 10);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(48, 17);
            this.rbMale.TabIndex = 3;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            this.rbMale.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(4, 12);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(48, 13);
            this.lblGender.TabIndex = 1;
            this.lblGender.Text = "Gender";
            this.lblGender.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // pnlDOB
            // 
            this.pnlDOB.Controls.Add(this.dtpDOB);
            this.pnlDOB.Controls.Add(this.lblDOB);
            this.pnlDOB.Location = new System.Drawing.Point(10, 58);
            this.pnlDOB.Name = "pnlDOB";
            this.pnlDOB.Size = new System.Drawing.Size(252, 37);
            this.pnlDOB.TabIndex = 1;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDOB.Location = new System.Drawing.Point(90, 6);
            this.dtpDOB.MinDate = new System.DateTime(1980, 1, 1, 0, 0, 0, 0);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(144, 20);
            this.dtpDOB.TabIndex = 2;
            this.dtpDOB.Value = new System.DateTime(2019, 8, 14, 0, 0, 0, 0);
            this.dtpDOB.ValueChanged += new System.EventHandler(this.dtpDOB_ValueChanged);
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(4, 12);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(33, 13);
            this.lblDOB.TabIndex = 1;
            this.lblDOB.Text = "DOB";
            this.lblDOB.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // pnlName
            // 
            this.pnlName.Controls.Add(this.txtName);
            this.pnlName.Controls.Add(this.lblName);
            this.pnlName.Location = new System.Drawing.Point(10, 16);
            this.pnlName.Name = "pnlName";
            this.pnlName.Size = new System.Drawing.Size(252, 37);
            this.pnlName.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(92, 8);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(148, 20);
            this.txtName.TabIndex = 1;
            this.txtName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(6, 11);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(39, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(231, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(184, 20);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "PERSONAL DETAILS";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button1);
            this.panel5.Controls.Add(this.btnVerify);
            this.panel5.Location = new System.Drawing.Point(9, 268);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(607, 37);
            this.panel5.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(98, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 28);
            this.button2.TabIndex = 2;
            this.button2.Text = "SUBMIT";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(383, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 28);
            this.button1.TabIndex = 1;
            this.button1.Text = "SUBMIT";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnVerify
            // 
            this.btnVerify.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnVerify.Location = new System.Drawing.Point(241, 4);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(109, 28);
            this.btnVerify.TabIndex = 0;
            this.btnVerify.Text = "SUBMIT";
            this.btnVerify.UseVisualStyleBackColor = false;
            this.btnVerify.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(624, 312);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.pnlPersonal);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "PERSONAL DETAILS";
            this.pnlPersonal.ResumeLayout(false);
            this.gbCommunication.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gbPersonal.ResumeLayout(false);
            this.pnlInterest.ResumeLayout(false);
            this.pnlInterest.PerformLayout();
            this.pnlGender.ResumeLayout(false);
            this.pnlGender.PerformLayout();
            this.pnlDOB.ResumeLayout(false);
            this.pnlDOB.PerformLayout();
            this.pnlName.ResumeLayout(false);
            this.pnlName.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlPersonal;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox gbCommunication;
        private System.Windows.Forms.GroupBox gbPersonal;
        private System.Windows.Forms.Panel pnlDOB;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Panel pnlName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Panel pnlGender;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Panel pnlInterest;
        private System.Windows.Forms.Label lblInterest;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.CheckBox cbDance;
        private System.Windows.Forms.CheckBox cbReading;
        private System.Windows.Forms.CheckBox cbMusic;
        private System.Windows.Forms.CheckBox cbSports;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEMailID;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Windows.Forms.Label lblMobile;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnVerify;
    }
}

