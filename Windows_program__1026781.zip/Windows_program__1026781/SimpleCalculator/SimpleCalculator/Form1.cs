﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class SimpleCalculator : Form
    {
        public SimpleCalculator()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblValue2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double val1, val2, val3;
            try
            {
                val1 = Convert.ToDouble(txtValue1.Text);
                val2 = Convert.ToDouble(txtValue2.Text);
                val3 = val1 + val2;
                lblProcess.Text = "+";
                txtResult.Text = val3.ToString();
            }
            catch(Exception)
            {
                txtResult.Text = "Error!";
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double val1, val2, val3;
            try
            {
                val1 = Convert.ToDouble(txtValue1.Text);
                val2 = Convert.ToDouble(txtValue2.Text);
                val3 = val1 - val2;
                lblProcess.Text = "-";
                txtResult.Text = val3.ToString();
            }
            catch (Exception)
            {
                txtResult.Text = "Error!";
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            double val1, val2, val3;
            try
            {
                val1 = Convert.ToDouble(txtValue1.Text);
                val2 = Convert.ToDouble(txtValue2.Text);
                val3 = val1 * val2;
                lblProcess.Text = "x";
                txtResult.Text = val3.ToString();
            }
            catch (Exception)
            {
                txtResult.Text = "Error!";
            }
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            double val1, val2, val3;
            try
            {
                val1 = Convert.ToDouble(txtValue1.Text);
                val2 = Convert.ToDouble(txtValue2.Text);
                val3 = val1 / val2;
                lblProcess.Text = "/";
                txtResult.Text = val3.ToString();
            }
              catch(DivideByZeroException)
            {
                txtResult.Text = "Error!";
            }
            catch (Exception)
            {
                txtResult.Text = "Error!";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       
    }
}
