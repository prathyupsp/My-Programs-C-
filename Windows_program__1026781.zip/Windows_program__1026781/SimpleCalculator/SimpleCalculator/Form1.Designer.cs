﻿namespace SimpleCalculator
{
    partial class SimpleCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValue1 = new System.Windows.Forms.Label();
            this.txtValue1 = new System.Windows.Forms.TextBox();
            this.lblValue2 = new System.Windows.Forms.Label();
            this.txtValue2 = new System.Windows.Forms.TextBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblResultShow = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSub = new System.Windows.Forms.Button();
            this.btnmult = new System.Windows.Forms.Button();
            this.btnDiv = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.lblEqual = new System.Windows.Forms.Label();
            this.lblProcess = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblValue1
            // 
            this.lblValue1.AutoSize = true;
            this.lblValue1.Location = new System.Drawing.Point(56, 10);
            this.lblValue1.Name = "lblValue1";
            this.lblValue1.Size = new System.Drawing.Size(78, 13);
            this.lblValue1.TabIndex = 0;
            this.lblValue1.Text = "VALUE 1    :";
            this.lblValue1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtValue1
            // 
            this.txtValue1.BackColor = System.Drawing.Color.White;
            this.txtValue1.Location = new System.Drawing.Point(156, 5);
            this.txtValue1.Name = "txtValue1";
            this.txtValue1.Size = new System.Drawing.Size(67, 20);
            this.txtValue1.TabIndex = 1;
            this.txtValue1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblValue2
            // 
            this.lblValue2.AutoSize = true;
            this.lblValue2.Location = new System.Drawing.Point(56, 68);
            this.lblValue2.Name = "lblValue2";
            this.lblValue2.Size = new System.Drawing.Size(78, 13);
            this.lblValue2.TabIndex = 2;
            this.lblValue2.Text = "VALUE 2    :";
            this.lblValue2.Click += new System.EventHandler(this.lblValue2_Click);
            // 
            // txtValue2
            // 
            this.txtValue2.BackColor = System.Drawing.Color.White;
            this.txtValue2.Location = new System.Drawing.Point(156, 62);
            this.txtValue2.Name = "txtValue2";
            this.txtValue2.Size = new System.Drawing.Size(67, 20);
            this.txtValue2.TabIndex = 3;
            this.txtValue2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(56, 122);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(80, 13);
            this.lblResult.TabIndex = 4;
            this.lblResult.Text = "RESULT     :";
            this.lblResult.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblResultShow
            // 
            this.lblResultShow.AutoSize = true;
            this.lblResultShow.Location = new System.Drawing.Point(106, 104);
            this.lblResultShow.Name = "lblResultShow";
            this.lblResultShow.Size = new System.Drawing.Size(0, 13);
            this.lblResultShow.TabIndex = 5;
            this.lblResultShow.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Linen;
            this.btnAdd.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnAdd.Location = new System.Drawing.Point(19, 160);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(87, 23);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSub
            // 
            this.btnSub.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSub.Location = new System.Drawing.Point(170, 160);
            this.btnSub.Name = "btnSub";
            this.btnSub.Size = new System.Drawing.Size(87, 23);
            this.btnSub.TabIndex = 7;
            this.btnSub.Text = "SUBTRACT";
            this.btnSub.UseVisualStyleBackColor = true;
            this.btnSub.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnmult
            // 
            this.btnmult.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnmult.Location = new System.Drawing.Point(19, 209);
            this.btnmult.Name = "btnmult";
            this.btnmult.Size = new System.Drawing.Size(87, 23);
            this.btnmult.TabIndex = 8;
            this.btnmult.Text = "MULTIPLY";
            this.btnmult.UseVisualStyleBackColor = true;
            this.btnmult.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // btnDiv
            // 
            this.btnDiv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnDiv.Location = new System.Drawing.Point(170, 209);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(87, 23);
            this.btnDiv.TabIndex = 9;
            this.btnDiv.Text = "DIVISION";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.Color.White;
            this.txtResult.Location = new System.Drawing.Point(156, 120);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(67, 20);
            this.txtResult.TabIndex = 10;
            this.txtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblEqual
            // 
            this.lblEqual.AutoSize = true;
            this.lblEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEqual.Location = new System.Drawing.Point(174, 87);
            this.lblEqual.Name = "lblEqual";
            this.lblEqual.Size = new System.Drawing.Size(31, 31);
            this.lblEqual.TabIndex = 11;
            this.lblEqual.Text = "=";
            // 
            // lblProcess
            // 
            this.lblProcess.AutoSize = true;
            this.lblProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcess.Location = new System.Drawing.Point(174, 27);
            this.lblProcess.Name = "lblProcess";
            this.lblProcess.Size = new System.Drawing.Size(0, 31);
            this.lblProcess.TabIndex = 12;
            // 
            // SimpleCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(262, 244);
            this.Controls.Add(this.lblProcess);
            this.Controls.Add(this.lblEqual);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.btnmult);
            this.Controls.Add(this.btnSub);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblResultShow);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.txtValue2);
            this.Controls.Add(this.lblValue2);
            this.Controls.Add(this.txtValue1);
            this.Controls.Add(this.lblValue1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Name = "SimpleCalculator";
            this.Text = "Simple Calculator";
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValue1;
        private System.Windows.Forms.TextBox txtValue1;
        private System.Windows.Forms.Label lblValue2;
        private System.Windows.Forms.TextBox txtValue2;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblResultShow;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSub;
        private System.Windows.Forms.Button btnmult;
        private System.Windows.Forms.Button btnDiv;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label lblEqual;
        private System.Windows.Forms.Label lblProcess;
    }
}

