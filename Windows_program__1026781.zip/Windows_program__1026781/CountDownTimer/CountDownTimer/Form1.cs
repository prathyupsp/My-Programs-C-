﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CountDownTimer
{
    public partial class countDown : Form
    {
        public countDown()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pbPicture.Load("C:\\Users\\1026781\\Downloads\\images.png");
            
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Start();
            //Environment.TickCount
        
            //txtCount.Text = timer1.Tick.ToString();
              //  ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          // txtCount.Text = tim
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
