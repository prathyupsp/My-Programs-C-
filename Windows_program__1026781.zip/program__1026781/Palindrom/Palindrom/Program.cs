﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrom
{
    class Program
    {
        static void Main(string[] args)
        {
            Palindrom P1=new Palindrom();
            P1.Input();
            P1.CheckPalindrom();
            P1.Display();
            Console.ReadKey();
        }
    }
    //class defenition
    class Palindrom
    {
        string inputstring; string result;
        //read the string
        public void Input()
        {
            Console.WriteLine("Enter the string to check :");
            inputstring = Console.ReadLine();
        }
        //check palindrom
        public void CheckPalindrom()
        {
            string temp = inputstring;
            result = " is a palindrom";
            for(int i=0;i<inputstring.Length;i++)
            {
                if(inputstring[inputstring.Length-i-1]!=inputstring[i])
                {
                    result = " is not a palindrom";

                }
            }
        }
        //display the result
        public void Display()
        {
            Console.WriteLine(inputstring + result);
        }
    }
}
