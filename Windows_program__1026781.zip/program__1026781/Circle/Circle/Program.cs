﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circle
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle C1=new Circle();
            C1.Input();
            C1.Circumferencecalc();
            C1.Areacalc();
            C1.Display();
            Console.ReadKey();
        }
    }
    class Circle
    {//variable declaration
        double radius, circumference, area;
        static double PI = 3.14;
        //input radius
        public void Input()
        {
            Console.WriteLine("Enter the radius");
            radius = Convert.ToInt32(Console.ReadLine());
        }
        //circumference calculation
        public void Circumferencecalc()
        {
            circumference = 2 * PI * radius;
        }
        //method to calculate area
        public void Areacalc()
        {
            area = PI * radius * radius;
        }
        //method to display results
        public void Display()
        {
            Console.WriteLine("Radius = "+radius);
            Console.WriteLine("Circumference = " + circumference);
            Console.WriteLine("Area = " + area);
          
        }
    }
}
