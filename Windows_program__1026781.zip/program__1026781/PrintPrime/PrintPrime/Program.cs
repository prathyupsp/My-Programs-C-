﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintPrime
{
    class Program
    {
        static void Main(string[] args)
        {
            Prime P1=new Prime();
            P1.Input();
            P1.FindPrime();
            P1.Display();
            Console.ReadKey();
        }
    }
    class Prime
    {
        //variables
        int Limit; int[] array;
        //input the limit
        public void Input()
        {
            Console.WriteLine("Enter no: of prime numbers to be printed");
            Limit=Convert.ToInt32(Console.ReadLine());
            array = new int[Limit];
        }
        //Check and display whether prime numbers
        public void FindPrime()
        {
            int i,j=2,n=0;
            while(n<Limit)
            {
                int flag = 0;
                for (i = 2; i <= (j / 2); i++)
                {
                    if (j % i == 0) //checking remainder
                        flag=1;
                }
                if (flag == 0)
                {
                    array[n] = j;
                    n++;
                }
                j++;
            }
        }
        public void Display()
        {
            Console.WriteLine();
            for (int i = 0; i < Limit; i++)
                Console.WriteLine(array[i]);
        }
    }
}
