﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InheritanceBase;
namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee E1 = new Employee(2000);
            E1.ReadInput();
            E1.ReadEmployee();
            E1.calculate();
            E1.Display();
            Console.ReadKey();
        }
    }
    //Base class -Person
  
    //Student class derived from person
    class Student : Person
    {
        double[] marks = new double[6];
        double total, average;
        //to read marks of student
        public void ReadStudent()
        {
            Console.WriteLine("Enter marks for 6 Subjects : ");
            for (int i = 0; i < 6; i++)
                marks[i] = Convert.ToInt32(Console.ReadLine());
        }
        //to calculate total and average mark
        public void calculate()
        {
            for (int i = 0; i < 6; i++)
                total += marks[i];
            average = total / 6;
        }
        //Display student details
        public void Display()
        {
            Console.WriteLine("Student ID    : " + id);
            Console.WriteLine("Student Name  : " + name);
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("SUBJECT {0} : {1}", i, marks[i]);
            }
            Console.WriteLine("Total Marks   : " + total);
            Console.WriteLine("Average Marks : " + average);
        }
    }
    //Employee class derived from Person
    class Employee : Person
    {
        double basicpay, hra, grosspay;
        //constructor
        public Employee(double hraInitial)
        {
            hra = hraInitial;
        }
        //read employee details
        public void ReadEmployee()
        {
            Console.WriteLine("Enter Basic Pay : ");
            basicpay = Convert.ToInt32(Console.ReadLine());
        }
        //calculate hra and gross pay
        public void calculate()
        {
            if (10 * basicpay / 100>hra)
                hra = 10 * basicpay / 100;
            grosspay = basicpay + hra;
        }
        //display employee details
        public void Display()
        {
            Console.WriteLine("Employee ID    : " + id);
            Console.WriteLine("Employee Name  : " + name);
            Console.WriteLine("Basic Pay      : " + basicpay);
            Console.WriteLine("HRA            : " + hra);
            Console.WriteLine("Gross Pay      : " + grosspay);
        }
    }
}
