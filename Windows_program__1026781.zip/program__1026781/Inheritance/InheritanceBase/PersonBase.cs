﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceBase
{
  public  class Person
    {
        public int id;
        public string name;
        public string department;
        //to read id,name,department
        public void ReadInput()
        {
            Console.WriteLine("Enter ID number  : ");
            id = Convert.ToInt32(Console.ReadLine());   //read id
            Console.WriteLine("Enter Name       : ");
            name = Console.ReadLine();      //read name
            Console.WriteLine("Enter Department : ");
            department = Console.ReadLine();        //read department
        }
    }
}