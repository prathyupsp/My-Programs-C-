﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandLineInput
{
    class CommandLineIn
    {
        static void Main(string[] args)
        {
            int length = args.Length;
            int[] arr=new int[length];
            CommandInput O1 = new CommandInput();
          // O1.Read();
            for(int i=0;i<length;i++)
            {
                arr[i]=Convert.ToInt32( args[i]);
            }
            O1.Calculate(length,arr);
            O1.Display();
            Console.ReadKey();
        }
    }
    //class definition
    class CommandInput
    {
        int size;
        double total, average; int[] arr;
        //calculate total and average
        public void Calculate(int length,params int[] arr)
        {
            foreach (int i in arr)
            {
                total=total+i;
            }
            average = total / length;
        }
        //display the result
        public void Display()
        {
            Console.WriteLine("Total : " + total);
            Console.WriteLine("Average : " + average);
        }
    }
}
