﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinToDecimal
{
    class Program
    {
        static void Main(string[] args)
        {
            Bintodec B1 = new Bintodec();//object creation
            B1.input();
            B1.convert();
            B1.print();
            Console.ReadKey();
        }
    }
    //class defenition
class Bintodec
{
    //variables
    int bin, binary=0,dec=0;
    //getting binary value
    public void input()
    {
        Console.WriteLine("Enter the binary number");
        binary = Convert.ToInt32(Console.ReadLine());
        bin = binary;
    }
    //converting binary to decimal
    public void convert()
    {
        int i = 0;
        int rem = 0;
        while (bin != 0)
        {
            rem = bin % 10;
            if (rem != 0 && rem != 1)
            {
                Console.WriteLine("INVALID"); break;
            }
            else
            {
                bin = bin / 10;
                dec = (int)(dec + Math.Pow(2, i) * rem);
                i++;
            }
        }
    }
    //display the result
    public void print()
    {
        Console.WriteLine("Decimal equivalent = " + dec);
    }
}
}