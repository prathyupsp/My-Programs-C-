﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecimalToBinary
{
    class Program
    {
        static void Main(string[] args)
        {
            DecToBin D1=new DecToBin();//object creation
            D1.input();
            D1.convert();
            D1.print();
            Console.ReadKey();
        }
    }
    //class defenition
    class DecToBin
    {
        //variable declaration
        int dec, bin=0,num;
        //input decimal number
        public void input()
        {
            Console.WriteLine("Enter the decimal number  :");
            num=Convert.ToInt32(Console.ReadLine());
            dec = num;
        }
        //decimal to binary convertion
        public void convert()
        {    
            int rem = 0, i = 0;
            while (dec != 0)
            {
                rem = dec % 2;
                dec = dec / 2;
                bin =(int) (bin + Math.Pow(10,i) * rem);
                i++;
            }
        }
        //display the result
        public void print()
        {
            Console.WriteLine("binary equivalent = "+bin);
        }
    }
}
