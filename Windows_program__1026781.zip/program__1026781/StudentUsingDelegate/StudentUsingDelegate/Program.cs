﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace StudentMarklist
{
    class Program
    {
       
        public static void Main(string[] args)
        {
            int numberOfStudents;
            Student[] student;
            Console.WriteLine("Enter no: of Students : ");
            numberOfStudents = Convert.ToInt32(Console.ReadLine());
            student = new Student[numberOfStudents];
            Student.Initialise();       //read number of students
            //instantiate objects
            for (int i = 0; i < numberOfStudents; i++)
            {
                student[i] = new Student();
            }
            //read details of each student
            for (int i = 0; i < numberOfStudents;i++)
            {
                Console.Write("\nStudent " + (i + 1)+"\n");
                student[i].Input();
            }
            //check whether pass or fail and generate gradecard
            for (int i = 0; i < numberOfStudents; i++)
            {
                student[i].Calculate();
            }
            //call display function using id of failed students to display list of failed students (using delegate)
            for (int i = 0; i < numberOfStudents; i++)
            {
                Console.Write("\n\n List of failed Students  ");
                student[i].Display(Student.stud(student[i]));    //calling using delegate
            }
            Console.ReadKey();   
        }
    }
    class Student
    {
        //declaring datamembers
        string student_name;
        int student_id;static int numberOfSubjects;
        float[] marks;
        float totalMark, averageMark;
        string[] grade;
        string status;
        //read number of subjects
        public static void Initialise()
        {
            Console.WriteLine("Enter number of subjects : ");
            numberOfSubjects = Convert.ToInt32(Console.ReadLine()); 
        }
        //input function
        public void Input()
        {
            grade = new string[numberOfSubjects];
            marks = new float[numberOfSubjects];
            Console.Write("Enter student id                :  ");
            student_id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter student name              :  ");
            student_name = Console.ReadLine();
            for (int i = 0; i < numberOfSubjects; i++)
            {
                Console.Write("Enter marks for subject " + (i + 1) + ": ");
                marks[i] = Convert.ToInt32(Console.ReadLine());
                if (marks[i] > 100 || marks[i] < 0)
                {
                    Console.WriteLine("  INVALID ENTRY");
                    break;
                }
            }
        }
        //calculate total and average and grade and passed/failed
        public void Calculate()
        {
            int flag = 0;
            for (int i = 0; i < numberOfSubjects; i++)
            {
                if (marks[i] >= 90)
                    grade[i] = "A+";
                else if (marks[i] >= 80)
                    grade[i] = "A";
                else if (marks[i] >= 70)
                    grade[i] = "B+";
                else if (marks[i] >= 60)
                    grade[i] = "B";
                else if (marks[i] >= 50)
                    grade[i] = "C+";
                else if (marks[i] >= 40)
                    grade[i] = "C";
                else
                {
                    grade[i] = "F"; flag = 1;
                }
                totalMark += marks[i];
            }
            averageMark = totalMark / numberOfSubjects;
            if (flag == 0)
            {
                status = "PASSED";
            }
            else
            {
                status = "FAILED";
            }
        }
        //display details
        public void Display(int id)
        {
        if(student_id==id)
          {
            Console.WriteLine("\n******************************************************************\n");
            Console.Write("Student ID : " + student_id);
            Console.Write("  Student Name : " + student_name);
            Console.Write("  |  " + status);
          }
        }
        public delegate int ShowStudentStatus(Student S1);   //delegate declaration

        public static int ShowFailed(Student S1)
        {
            if (S1.status == "FAILED")
                return S1.student_id;   //returns id of failed students
            else return 0; 
        }
        public static ShowStudentStatus stud = new ShowStudentStatus(ShowFailed);       //assign delegate to ShowFailed() method    
    }
}


