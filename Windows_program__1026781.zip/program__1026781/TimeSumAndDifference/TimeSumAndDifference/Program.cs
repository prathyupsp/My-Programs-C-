﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeSumAndDifference
{
    class Program
    {
        static void Main(string[] args)
        {
            Time T1 = new Time();
            Time T2 = new Time();
            Time T3 = new Time();
            Time T4 = new Time();
            Console.WriteLine("\nFirst Input   ");
            T1.Input();
            Console.WriteLine("\nSecond Input  ");
            T2.Input();
            T3.CalculateSum(T1, T2);
            T4.CalculateDifference(T1, T2);
            Console.Write("\n\nFirst Input   : ");
            T1.Display();
            Console.Write("\nSecond Input  : ");
            T2.Display();
            Console.Write("\n\nSum           : ");
            T3.Display();
            Console.Write("\nDifference    : ");
            T4.Display();
            Console.ReadKey();
        }
   }
    class Time
    {
        //variable declaraion
        int Hours, Seconds, Minutes;
        //input the values
        public void Input()
        {
            
            l1:Console.Write("Enter Hours   :  ");
            Hours = Convert.ToInt32(Console.ReadLine());
            if (Hours < 0)
            {
                Console.WriteLine("INVALID INPUT");
                goto l1;
            }
            l2:Console.Write("Enter Minutes :  ");
            Minutes = Convert.ToInt32(Console.ReadLine());
            if (Minutes < 0|| Minutes > 59)
            {
                Console.WriteLine("INVALID INPUT");
                goto l2;
            }
            l3:Console.Write("Enter Seconds :  ");
            Seconds = Convert.ToInt32(Console.ReadLine());
            if (Seconds < 0 || Seconds > 59)
            {
                Console.WriteLine("INVALID INPUT");
                goto l2;
            }
        }
        //calculating sum
        public void CalculateSum(Time T1,Time T2)
        {
            Seconds = (T1.Seconds + T2.Seconds) % 60;
            Minutes = (T1.Minutes + T2.Minutes + (T1.Seconds + T2.Seconds) / 60) % 60;
            Hours = T1.Hours + T2.Hours + (T1.Minutes + T2.Minutes + (T1.Seconds + T2.Seconds) / 60) / 60;
        }
        //calculating difference
        public void CalculateDifference(Time T1, Time T2)
        {
            int totalSeconds1, totalSeconds2, difference;
            totalSeconds1 = T1.Seconds + T1.Minutes * 60 + T1.Hours * 3600;
            totalSeconds2 = T2.Seconds + T2.Minutes * 60 + T2.Hours * 3600;
            difference = Math.Abs(totalSeconds2 - totalSeconds1);
            Hours = difference / 3600;
            Minutes = (difference - Hours * 3600)/60;
            Seconds = (difference % 60);
        }
        //displaying outputs
        public void Display()
        {
            Console.Write(Hours + " Hours " + Minutes + " Minutes " + Seconds + " Seconds");
        }
    }
}
