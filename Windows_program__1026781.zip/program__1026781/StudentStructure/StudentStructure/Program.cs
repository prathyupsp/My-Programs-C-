﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentStructure
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentClass S1 = new StudentClass();
            S1.Input();
            S1.Calculate();
            S1.Display();
            Console.ReadKey();
        }
    }
   public struct Student
    {
       //declaring datamembers
       public string student_name;
       public int student_id;
       public float totalMark;
       public float averageMark;
       public string status;
    }
    class StudentClass
    {
        Student O1;
        public int flag=0;
        public string[] grade = new string[6];
        public float[] marks = new float[6];
        //input function
        public void Input()
        {
            Console.Write("Enter student id                :  ");
            O1.student_id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter student name              :  ");
            O1.student_name = Console.ReadLine();
            for (int i = 0; i < 6; i++)
            {
                Console.Write("Enter marks for subject " + (i + 1) + ": ");
                marks[i] = Convert.ToInt32(Console.ReadLine());
                if (marks[i] > 100 || marks[i] < 0)
                {
                    Console.WriteLine("  INVALID ENTRY");
                    break;
                }
            }
        }
        //calculate total and average
        public void Calculate()
        {
            for (int i = 0; i < 6; i++)
            {
                if (marks[i] >= 90)
                    grade[i] = "A+";
                else if (marks[i] >= 80)
                    grade[i] = "A";
                else if (marks[i] >= 70)
                    grade[i] = "B+";
                else if (marks[i] >= 60)
                    grade[i] = "B";
                else if (marks[i] >= 50)
                    grade[i] = "C+";
                else if (marks[i] >= 40)
                    grade[i] = "C";
                else
                {
                    grade[i] = "F";
                    flag = 1;
                }
                O1.totalMark += marks[i];
            }
            O1.averageMark = O1.totalMark / 6;
            if (flag == 0)
                O1.status = "PASSED";
            else
                O1.status = "FAILED";
        }
        //display details
        public void Display()
        {
            Console.WriteLine("******************************************************************\n");
            Console.WriteLine("  Student Name    : " + O1.student_name);
            Console.WriteLine("  Student ID      : " + O1.student_id);
            Console.WriteLine("      * * MARKS * *");
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("  Subject " + (i + 1) + " :  " + marks[i] + "    " + grade[i]);
            }
            Console.WriteLine("\n  Total Marks     : " + O1.totalMark);
            Console.WriteLine("\n  Average Marks   : " + O1.averageMark);
            Console.WriteLine("\n         " + O1.status);
        }

    }
}
