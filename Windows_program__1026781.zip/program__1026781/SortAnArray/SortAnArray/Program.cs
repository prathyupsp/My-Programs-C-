﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortAnArray
{
    class Program
    {
        static void Main(string[] args)
        {
            SortArray S1 = new SortArray();
            S1.Input();
            S1.SortAscending();
            S1.SortDescending();
            S1.Display();
            Console.ReadKey();
        }
    }
    //class defenition
    class SortArray
    {
        //declaring variables
        int size;
        int[] array;
        int[] ascendingArray;
        int[] descendingArray;
        //Read the array
        public void Input()
        {
            Console.WriteLine("Enter the number of elements in the array : ");
            size=Convert.ToInt32(Console.ReadLine());
            array = new int[size];
            ascendingArray=new int[size];
            descendingArray = new int[size];
            Console.WriteLine("Enter the elements in the array : ");
            for(int i=0;i<size;i++)
            {
                array[i] =Convert.ToInt32(Console.ReadLine());
                ascendingArray[i] = array[i];
                descendingArray[i] = array[i];
            }
        }
        //sorting in ascending order
        public void SortAscending()
        {
            int temp,i,j;
            for(i=0;i<size;i++)
            {
                for(j=0;j<i;j++)
                {
                    if (ascendingArray[i] < ascendingArray[j])
                    {
                        //swap the values
                        temp = ascendingArray[i];
                        ascendingArray[i] = ascendingArray[j];
                        ascendingArray[j] = temp;
                    }
                }
            }
        }
        //sorting in descending order
        public void SortDescending()
        {
            int temp, i, j;
            for (i = 0; i < size; i++)
            {
                for (j = 0; j < i; j++)
                {
                    if (descendingArray[i] > descendingArray[j])
                    {
                        //swap the values
                        temp = descendingArray[i];
                        descendingArray[i] = descendingArray[j];
                        descendingArray[j] = temp;
                    }
                }
            }
        }
        //display input and output
        public void Display()
        {
            int i;
            Console.Write("\n\nArray before sorting  :  ");
            for (i=0; i < size; i++)
                Console.Write(array[i] + " ");
            Console.Write("\n\nIn ascending order    :  ");
            for (i=0; i < size; i++)
                Console.Write(ascendingArray[i] + " ");
            Console.Write("\n\nIn descending order   :  ");
            for (i = 0; i < size; i++)
                Console.Write(descendingArray[i] + " ");
        }
    }
}
