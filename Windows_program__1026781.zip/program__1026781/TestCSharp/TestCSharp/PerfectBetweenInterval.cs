﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCSharp
{
    class PerfectBetweenInterval
    {
        //main program
        static void Main(string[] args)
        {
            PerfectNumberInterval P1 = new PerfectNumberInterval();//obect creation
            P1.ReadInput();//function call to read the inputs
            P1.CheckPerfectNumber();//function call to check and display the perfect numbers
            Console.ReadKey();
        }
    }
    //class defenition
    class PerfectNumberInterval
    {
        //variable declaration
        int Start, End;
        public void ReadInput()
        {
            Console.WriteLine("Enter the lower and upper limit : ");
            Start = Convert.ToInt32(Console.ReadLine());//read lower imit
            End = Convert.ToInt32(Console.ReadLine());//read upper limit
            Console.WriteLine("\n\nPerfectNumbers between "+Start+" & "+End +" are : ");  
        }
        //function to check and display perfect number
        public void CheckPerfectNumber()
        {
            for (int temp=Start; temp <= End; temp++)
            {
                int sum = 0;
                for (int i = 1; i < temp; i++)
                {
                    if (temp % i == 0)
                        sum = sum + i;     //find and add divisors
                }
                if (sum == temp)
                {
                    Console.WriteLine(temp+" ");        // display perfect numbers
                }
            }
        }
    }
}