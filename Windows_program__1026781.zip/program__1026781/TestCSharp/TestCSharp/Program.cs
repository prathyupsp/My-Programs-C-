﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCSharp
{
    class CheckPerfectNumber
    {
        //main program
        static void Main(string[] args)
        {
            PerfectNumber P1=new PerfectNumber();//object creation
            P1.Input();
            P1.Display();
            Console.ReadKey();
        }
    }
    //class defenition
    class PerfectNumber
    {
        //variable declaration
        int Number;
        string Result;//variable to store result
        //function to read the input
        public void Input()
        {
            Console.WriteLine("Enter the number to check whether it is a perfect number : ");
            Number = Convert.ToInt32(Console.ReadLine());//read input
            CheckPerfect(Number);//Function call tpo check perfect number
        }
        //function to check perfect number
        public void CheckPerfect(int n)
        {
            int sum = 0;
            for(int i=1;i<n;i++)
            {
                if (n % i == 0)
                    sum = sum + i;      //find and add divisors
            }
            if(sum==Number)
            {
                //the number is a perfect number
                Result = "is a perfect number";     //store the result
            }
            else
                Result = "is not a perfect number";     //store the result
        }
        //display the result
        public void Display()
        {
            Console.WriteLine("\n"+Number + " " + Result);
        }
    }
}
