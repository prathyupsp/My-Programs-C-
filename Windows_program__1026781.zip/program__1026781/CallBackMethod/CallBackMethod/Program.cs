﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CallBackMethod
{
    public delegate void DelegateSum(int sum);      //delegate declaration
    class ThreadCallBackDemo
    {
        //main method
        static void Main(string[] args)
        {
            int limit;
            DelegateSum callBack = new DelegateSum(PrintSum);
            Console.WriteLine("Enter the upper limit : ");
            limit=Convert.ToInt32(Console.ReadLine());      //read upper limit
            SUM sum = new SUM(limit, callBack);     //instantiating object of the class SUM
            Thread threadSum = new Thread(sum.FindSum);     //thread (FindSum method)
            threadSum.Start();      //start the thread (call FindSum() method)
            Console.ReadLine();
        }
        //method to print sum
        public static void PrintSum(int sum)
        {
            Console.WriteLine("The Sum of odd numbers = "+ sum);

        }
    }
    //class defenition
    class SUM
    {

        int _number;
        DelegateSum _DelegateSum;       //delegate variable
        public SUM(int target, DelegateSum DelegateSum)
        {
            _number = target;
            _DelegateSum = DelegateSum;     //delegate object passed through the function is stored in _DelegateSum
        }
        //function to find sum of odd numbers from 1 to _number
        public void FindSum()
        {
            int sum = 0;
            //finding sum
            for (int i = 1; i <= _number; i++)
            {
                if(i%2 !=0)
                sum += i;
            }
            if (_DelegateSum != null)
            {
                _DelegateSum(sum);
            }
        }
    }
}
