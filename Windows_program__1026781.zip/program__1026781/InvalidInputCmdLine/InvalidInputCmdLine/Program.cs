﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvalidInputCmdLine
{
    class Program
    {
        static void Main(string[] args)
        {
          //   ** If the entered number is not between 0 & 100, then it is INVALID!! **
            CheckInvalid C1 = new CheckInvalid();
            C1.Check(args);
            C1.Display();
        }
    }
//class defenition
    class CheckInvalid
    {
        static int count;
        //method to check invalid data
        public void Check(string[] arr)
        {
            for(int i=0;i<arr.Length;i++)
            {
                try
                {
                   if(Convert.ToInt32(arr[i])>=0 && Convert.ToInt32(arr[i])<=100)       //check for invalid data
                   {   
                   }
                   else
                       throw new MisMatchException();           //throw exception
                }
                catch
                {
                
                }
            } 
        }
        //method to display the number of invalid entry
        public void Display()
        {
            Console.WriteLine("No: of Inputs greater than '100' or less than '0' = " + count);
        }
        //Static method to increment the count when invalid data is found
        public static void IncrementCount()
        {
            count++;
        }
    }
    //class to handle exception
    class MisMatchException : Exception
    {
        public MisMatchException()
        {
            CheckInvalid.IncrementCount();      //call method to increment count
        }
    }
}
