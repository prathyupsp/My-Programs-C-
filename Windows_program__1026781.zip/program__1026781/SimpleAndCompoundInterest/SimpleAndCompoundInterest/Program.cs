﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleAndCompoundInterest
{
    class Program
    {
        static void Main(string[] args)
        {
            Interest I1 = new Interest();
            I1.Input();
            I1.SimpleInterest();
            I1.CompoundInterest();
            I1.Display();
            Console.ReadKey();
        }
    }
    class Interest
    {
        //class defenition
        double principal, years, rate,SI,CI;
        //read values
        public void Input()
        {
            Console.WriteLine("Enter the principal amount : ");
            principal=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the Rate of Interest : ");
            rate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter no of years : ");
            years = Convert.ToDouble(Console.ReadLine());
        }
        //simple interest
        public void SimpleInterest()
        {
            SI = principal * years * rate / 100;
        }
        //compound interest
        public void CompoundInterest()
        {
            double t=0,option=0;
            Console.WriteLine("Enter the type of calculation : 1.Yearly 2.Half yearly 3.Quarterly 4.Monthly");
            option = Convert.ToDouble(Console.ReadLine());
            switch((int)option)
            {
                case 1: t = 1; break;
                case 2: t = 2; break;
                case 3: t = 4; break;
                case 4: t = 12; break;
                default: Console.WriteLine("INVALID"); break;
            }

            CI = principal * Math.Pow((1 + rate / (t * 100)), (years * t))-principal;
        }
        //display the result
        public void Display()
        {
            Console.WriteLine("Principal amount : " + principal);
            Console.WriteLine("Rate of interest : " + rate);
            Console.WriteLine("Period of loan   : " + years);
            Console.WriteLine("Simple interest   : " + SI);
            Console.WriteLine("Compound interest   : " + CI);
        }
    }
}
