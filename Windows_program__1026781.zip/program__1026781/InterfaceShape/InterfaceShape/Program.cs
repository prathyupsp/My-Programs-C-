﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceShape
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle C1 = new Circle();
            Square S1 = new Square();
            Triangle T1 = new Triangle();
            T1.Input();
            T1.FindArea();
            T1.Display();
            Console.ReadKey();
        }
    }
    public interface IShape
    {
        //function to read value
        void Input();
        //function to calculate area
        void FindArea();
        //function to display area
        void Display();
    }

    //class circle impliments the interface IShape
    class Circle : IShape
    {
        double radius; double area;
        const double PI = 3.14;
        //read radius of circle
        public void Input()
        {
            Console.WriteLine("Enter radius : ");
            radius=Convert.ToDouble(Console.ReadLine());
        }
        //calculating area(overriding)
        public void FindArea()
        {
            area = PI * radius * radius;
        }
        //display area
        public void Display()
        {
            Console.WriteLine("Area : "+area);
        }
        
    }
    //class Square impliments the interface IShape
    public class Square : IShape
    {
        double side; double area;
        //reading the lenth of one side of the square
        public void Input()
        {
            Console.WriteLine("Enter Length of a side : ");
            side = Convert.ToDouble(Console.ReadLine());
        }
        //calculating area(overriding)
        public void FindArea()
        {
            area = side*side;
        }
        //display area
        public void Display()
        {
            Console.WriteLine("Area : " + area);
        }
    }
    //class Triangle impliments the interface IShape
   public class Triangle : IShape
    {
        double baseLength, height; double area;
        //read base and height of triangle
        public void Input()
        {
            Console.WriteLine("Enter Length of a length of base : ");
            baseLength = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Height of triangle : ");
            height = Convert.ToDouble(Console.ReadLine());
        }
        //calculating area(overriding)
        public void FindArea()
        {
            area = baseLength * height/2;
        }

       //display area
        public void Display()
        {
            Console.WriteLine("Area : " + area);
        }
    }
}