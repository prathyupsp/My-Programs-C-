﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfOddNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            SumofOddNumbers S1=new SumofOddNumbers();
            S1.Input();
            S1.CalculateSum();
            S1.Display();
            Console.ReadKey();
        }
    }
    class SumofOddNumbers
    {
        //variable declaration
        int Limit,Sum;
        //reading the number of odd numbers to be added
        public void Input()
        {
            Console.WriteLine("Enter the number of odd numbers to be added : ");
            Limit = Convert.ToInt32(Console.ReadLine());
        }
        //calculate sum
        public void CalculateSum()
        {
            int j = 1,n=1,i;
            while(j<=Limit)
            {
                  if(n%2!=0)
                  {
                      Sum+=n;
                      j++;
                  }
                  n++;

            }
        }
        //display sum
        public void Display()
        {
            Console.WriteLine("Sum of " + Limit + " odd numbers = " + Sum);
        }
    }
}
