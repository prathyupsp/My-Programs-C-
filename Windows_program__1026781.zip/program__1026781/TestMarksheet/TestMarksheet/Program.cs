﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestMarksheet
{
    class StudentMarkSheet
    {
        //Main method
        static void Main(string[] args)
        {
            StudentFunctions Stud1 = new StudentFunctions();    //object creation
            Stud1.ReadInput();  //function call to read input
            Stud1.Calculate();  //function call to calculate total, avg,grade
            Stud1.DisplayDetails(); //function call to display details
            Console.ReadKey();
        }
    }

    //struct to store student details
    struct StudentDetails
    {
        public int studentID;
        public string studentName;
        public string status;
        public StudentDetails(int id,string name,string statusOfStudent) //parameterised constructor in structure
        {
            studentID = id;
            studentName = name;
            status = statusOfStudent;
        }

    }

    //abstract class to store marks and related data
    abstract class StudentMarks
    {
        
        //abstract functions to read input
        public abstract void ReadInput();
        public abstract void Calculate();
        public virtual void DisplayDetails()
        {
            Console.WriteLine("INVALID");
        }
    }

    //class to read and generate mark list (inherited from class StudentMarks)
    class StudentFunctions:StudentMarks
    {
        public StudentDetails S1 = new StudentDetails(1001, "NAME not available","status not available");    //create object of struct with parameterised constructor
        //variable declaraion
        double[] marks; //array to store marks
        string[] grades;    //array to store grade
        double totalMarks, averageMarks;
        int numberOfSubjects;
        static double minMarks = 0;
        static double maxMarks = 100;
        //read input details
        public override void ReadInput()
        {
            Console.WriteLine("Enter Student ID : ");
            S1.studentID = Convert.ToInt32(Console.ReadLine()); // read student id
            Console.WriteLine("Enter Name of Student : ");
            S1.studentName = Console.ReadLine();    // read student name
            Console.WriteLine("Enter Number of subjects ");
            numberOfSubjects = Convert.ToInt32(Console.ReadLine()); //read number of subjects
            marks = new double[numberOfSubjects];
            grades = new string[numberOfSubjects];
            Console.WriteLine("Enter Marks of student ");
            //read marks
            for (int i = 0; i < numberOfSubjects; i++)
            {
                Console.WriteLine("\nEnter marks for subject "+(i+1)+" : ");
                marks[i] = Convert.ToDouble(Console.ReadLine());
                if(marks[i]>maxMarks||marks[i]<minMarks)    //chack for invalid data
                {
                    Console.WriteLine("Invalid Input : Enter again");
                    i--;
                }
            }
        }
        //function to calculate total and average marks, grade and status
        public override void Calculate()
        {
            int flag = 0; 
            //assign grade for each subject
            for (int i = 0; i < numberOfSubjects; i++)
            {
                totalMarks += marks[i];
                if (marks[i] >= 90)
                    grades[i] = "A+";
                else if (marks[i] >= 80)
                    grades[i] = "A";
                else if (marks[i] >= 70)
                    grades[i] = "B+";
                else if (marks[i] >= 60)
                    grades[i] = "B";
                else if (marks[i] >= 50)
                    grades[i] = "C+";
                else if (marks[i] >= 40)
                    grades[i] = "C";
                else
                {
                    //condition for failure
                    grades[i] = "F";
                    flag = 1;
                }  
            }
            //check for pass or fail status
            if (flag == 1)
                S1.status = "          **Failed**";
            else
                S1.status = "          **Passed**";
            totalMarks = 0; averageMarks = 0;
            for (int i = 0; i < numberOfSubjects; i++)
                totalMarks =totalMarks + marks[i];      //calculate total marks
            averageMarks = totalMarks / numberOfSubjects;       //calculate average marks
        }
        //display the details of student
        public override void DisplayDetails()
        {
            Console.WriteLine("\n************************************************************\n");
            Console.WriteLine("Student ID       : " + S1.studentID);    //display student id
            Console.WriteLine("Name Of Student  : " + S1.studentName);  //display student name
            for (int i = 0; i < numberOfSubjects; i++)
            Console.WriteLine("Subject "+(i+1)+"        : " + marks[i]+"  "+grades[i]); //display marks of each subject with grade
            Console.WriteLine("\nTotal Marks      : " + totalMarks);  //display total marks
            Console.WriteLine("Average Marks    : " + averageMarks);    //display average marks
            Console.WriteLine(S1.status);  //display status of student
        }
    }
}
