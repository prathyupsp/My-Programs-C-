﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trialprogram
{
    class SumOOP
    {
        static void Main(string[] args)
        {
            SUM s1=new SUM();
            s1.input();
            s1.calcsum();
            s1.calcdiff();
            s1.calcprod();
            s1.display();
            Console.ReadKey();
        }
    }
    class SUM
    {//variable declaration
        int val1,val2,val3,val4,val5;
        //input data
        public void input()
        {
            Console.WriteLine("Enter first no: ");
            val1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second no: ");
            val2 = Convert.ToInt32(Console.ReadLine());
        }
        //calculate sum
        public void calcsum()
        {
            val3 = val1 + val2;
        }
        //calculate difference
        public void calcdiff()
        {
            val4 = val1 - val2;
        }
        //calculate product
        public void calcprod()
        {
            val5 = val1 * val2;
        }
        //output
        public void display()
        {
            Console.WriteLine(val1 + " + " + val2 + " = " + val3);
            Console.WriteLine(val1 + " - " + val2 + " = " + val4);
            Console.WriteLine(val1 + " * " + val2 + " = " + val5);
        }
    }
    
}
