﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trialprogram
{
    class Sumproced
    {
        static void Main(string[] args)
        {
            int val1, val2, val3;
            Console.WriteLine("Enter first no: ");
            val1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second no: ");
            val2 = Convert.ToInt32(Console.ReadLine());
            val3 = val1 + val2;
            Console.WriteLine(val1 + " + " + val2 + " = " + val3);
            Console.ReadKey();
        }
    }
}
