﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloadingDistance
{
    class Program
    {
        static void Main(string[] args)
        {
            Distance D1 = new Distance();
            Distance D2 = new Distance();
            Distance D3 = new Distance();
            Distance D4 = new Distance();
            Distance D5 = new Distance();
            Distance D6 = new Distance();
            D1.Input();
            D2.Input();
            D3 = D1 + D2;
            D4 = D1 - D2;
            D5 = D1 + 3;
            Console.WriteLine("SUM = "); 
            D3.Display();
            Console.WriteLine("SUM of the distance and the constant = ");
            D5.Display();
            Console.WriteLine("DIFFERENCE = "); 
            D4.Display();
            Console.ReadKey();
        }
    }
    class Distance
    {
        //variable declaraion
        int inches, feets,result;
        //input the values
        public void Input()
        {
            Console.WriteLine("Enter Distance");
        reenter1: Console.Write("Enter feets  :  ");
            feets = Convert.ToInt32(Console.ReadLine());
            if (feets < 0)
            {
                Console.WriteLine("Invalid Input");
                goto reenter1;
            }
        reenter2: Console.Write("Enter inches :  ");
            inches = Convert.ToInt32(Console.ReadLine());
            if (inches < 0 || inches > 12)
            {
                Console.WriteLine("Invalid Input");
                goto reenter2;
            }
        }
        
        //calculating sum
        public static Distance operator+(Distance D1,Distance D2)
        {
            Distance D3=new Distance();
            int totalinches1, totalinches2, sum;
            totalinches1 = D1.inches + D1.feets * 12;
            totalinches2 = D2.inches + D2.feets * 12;
            sum = totalinches1 + totalinches2;
            D3.feets = sum / 12;
            D3.inches = sum % 12;
            return D3;
        }
        //Adding an inch value
        public static Distance operator +(Distance D1,int inchToAdd)
        {
            Distance D5 = new Distance();
            int totalinches1, sum;
            totalinches1 = D1.inches + D1.feets * 12;
            sum = totalinches1 + inchToAdd;
            D5.feets = sum / 12;
            D5.inches = sum % 12;
            return D5;
        }
        //calculating difference
        public static Distance operator-(Distance D1, Distance D2)
        {
            Distance D4=new Distance();
            int totalinches1, totalinches2, difference;
            totalinches1 = D1.inches + D1.feets * 12;
            totalinches2 = D2.inches + D2.feets * 12;
            difference = Math.Abs(totalinches1 - totalinches2);
            D4.feets = difference / 12;
            D4.inches = difference % 12;
            return D4;
        }

        //comparing two distnces


        //displaying outputs
        public void Display()
        {
            Console.WriteLine(feets + " feets " + inches + " inches");
        }
        //display the result of comparison
        public void DisplayComparison()
        {
            if(result==0)
                Console.WriteLine("Both are equal");
            else
                Console.WriteLine("Not equal");
        }
    }
}
