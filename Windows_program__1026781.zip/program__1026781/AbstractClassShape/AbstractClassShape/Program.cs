﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    class Program
    {
        static void Main(string[] args)
        {
            int option = 0;
            bool flag = true;
            while (flag)
            {
                //read an option from user
                Console.WriteLine("Enter an option : 1.Circle  2.Square  3.Triangle");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1: flag = false; Circle C1 = new Circle();
                        C1.Input();
                        C1.Findarea();
                        C1.Display(); break;
                    case 2: flag = false; Square S1 = new Square();
                        S1.Input();
                        S1.Findarea();
                        S1.Display(); break;
                    case 3: flag = false; Triangle T1 = new Triangle();
                        T1.Input();
                        T1.Findarea();
                        T1.Display(); break;
                    default: Console.WriteLine("INVALID"); break;
                }
            }
            Console.ReadKey();
        }
    }
    //Abstract class
    abstract class Shape
    {
        public double area;
        //abstract function to read Input
        public abstract void Input();
        //abstract function to calculate area
        public abstract void Findarea();
        //display area
        public void Display()
        {
            Console.WriteLine("Area = " + area);
        }
    }
    class Circle:Shape
    {
        double radius;
        const double PI = 3.14;
        //read radius of circle
        public override void Input()
        {
            Console.WriteLine("Enter radius : ");
            radius=Convert.ToDouble(Console.ReadLine());
        }
        //calculating area(overriding)
        public override void Findarea()
        {
            area = PI * radius * radius;
        }
        
    }
    class Square : Shape
    {
        double side;
        //reading the lenth of one side of the square
        public override void Input()
        {
            Console.WriteLine("Enter Length of a side : ");
            side = Convert.ToDouble(Console.ReadLine());
        }
        //calculating area(overriding)
        public override void Findarea()
        {
            area = side*side;
        }

    }
    class Triangle : Shape
    {
        double baseLength,height;
        //read base and height of triangle
        public override void Input()
        {
            Console.WriteLine("Enter Length of a length of base : ");
            baseLength = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Height of triangle : ");
            height = Convert.ToDouble(Console.ReadLine());
        }
        //calculating area(overriding)
        public override void Findarea()
        {
            area = baseLength*height/2;
        }

    }
}
