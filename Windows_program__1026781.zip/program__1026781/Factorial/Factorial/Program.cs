﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            FindFactorial F1 = new FindFactorial();//object creation
            F1.Input();
            F1.Factorial();
            F1.Display();
            Console.ReadKey();
        }
    }
}
//class definition
class FindFactorial
{
    int Number, fact;
    //method to read input
    public void Input()
    {
        Console.WriteLine("Enter the Number :");
        Number = Convert.ToInt32(Console.ReadLine());
        if(Number<0)             //checking if the number is non negative or not
        {
            Console.WriteLine("Invalid Entry");
            Input();
        }
    }
    //method to find factorial
    public void Factorial()
    {
        fact = 1;
        int temp = Number;
        while (temp > 0)
        {
            fact = fact * temp;
            temp--;
        }
    }
    //method to display factorisl
    public void Display()
    {
        Console.WriteLine(Number + " ! = " + fact);
    }
}