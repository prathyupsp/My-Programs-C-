﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sequence
{
    class Program
    {
        static void Main(string[] args)
        {
            Sequence_Fact S1=new Sequence_Fact();
            S1.input();
            S1.sequencecalc();
            S1.display();
            Console.ReadKey();
        }
    }
    class Sequence_Fact
    {
        //variable declaration
        int n;
        double sum = 0.0;
        public int factorial(int number)
        {
           int fact = 1;
            while (number > 0)
            {
                fact = fact*number;
                number--;
            }
            return fact;
        }
        //read input
        public void input()
        {
            Console.WriteLine("enter the limit ");
            n = Convert.ToInt32((Console.ReadLine()));
        }
        //display output
        public void display()
        {
            Console.WriteLine(sum);
        }
        //sum calculation
        public void sequencecalc()
        {
            for(int i=1;i<=n;i++)
            {
                double t = ((double)i / (double)(factorial(i)));
                sum = (sum + t);   
            }   
        }
    }
}
