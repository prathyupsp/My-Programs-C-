﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Combination
{
    class Program
    {
        static void Main(string[] args)
        {
            FindCombination F1 = new FindCombination();//object creation
            F1.Input();
            F1.Combination();
            F1.Display();
            Console.ReadKey();
        }
    }
}
//class defenition
class FindCombination
{
    int n,r, ncr;
    //input values
    public void Input()
    {
        bool flag = true;
        while (flag)
        {
            Console.WriteLine("Enter the value for n");
            n = Convert.ToInt32(Console.ReadLine());
            if (n < 0)           //checking for valid input
            {
                Console.WriteLine("Invalid Entry");
                Input();
            }
            else
            {
                Console.WriteLine("Enter the value for r");
                r = Convert.ToInt32(Console.ReadLine());
            }
            if (r < 0)           //checking for valid input
            {
                Console.WriteLine("Invalid Entry");
                Input();
            }
            if (n < r)           //checking for valid input
            {
                Console.WriteLine("Invalid Entry");
                Input();
            }
            flag = false;
        }
    }
    //calculate factorial
    public int Factorial(int n)
    {
        int fact;
        fact = 1;
        int temp = n;
        while (temp > 0)
        {
            fact = fact * temp;
            temp--;
        }
        return fact;
    }
    //calculate NCR(if possible and else display invalid);
    public void Combination()
    {
        ncr = Factorial(n) / (Factorial(n - r) * Factorial(r));
    }
    //Display NCR result
    public void Display()
    {
        Console.WriteLine(n + "C" + r+" = "+ncr);
    }
}