﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebuggingDemo
{
    class Program
    {
        public static void Main(string[] args)
        {
    /*      int j = 20;
            for(int i=0;i<=10;++i)
            {
                int k = 10;
                j = j + i+k;
                Console.WriteLine(i);
            }       */
             Console.ReadKey();
        }
        public static int Sum(int val1, int val2)
        {
            int val3 = val1 + val2;
            Console.WriteLine(val3);
            return val3;
        }
    }   
}
