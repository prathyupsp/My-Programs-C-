﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace DebuggingDemo
{
    class DebugDemo3
    {
        static int i = 0;
        static void Main(string[] args)
        {
            Thread t1 = new Thread(Inc);
            t1.Name = "Thread 1";
            t1.Start();
            Thread t2 = new Thread(Inc);
            t2.Name = "Thread 2";
            t2.Start();
           /* Thread t3 = new Thread(Inc);
            t3.Name = "Thread 3";
            t3.Start();     */
            Console.ReadKey();
        }
        static void Inc()
        {
            for(int k=0;k<=50;k++)
            {
                
                Console.WriteLine(Thread.CurrentThread.Name+"       k = "+k);
                Console.ReadKey();
                Thread.Sleep(1000);
                
            }
        }
    }
}
