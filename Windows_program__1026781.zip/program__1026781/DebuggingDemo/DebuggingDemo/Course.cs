﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebuggingDemo
{
    class DebugDemo2
    {
        static void Main(string[] args)
        {
            List<Course> CourseDetails = new List<Course>();
            CourseDetails.Add(new Course { Id = 1, Name = "C#", Duration = "3 years", Fees = 5000 });
            CourseDetails.Add(new Course { Id = 2, Name = "C++", Duration = "2 years", Fees = 3000 });
            CourseDetails.Add(new Course { Id = 3, Name = "JAVA", Duration = "2.5 years", Fees = 4000 });
            CourseDetails.Add(new Course { Id = 4, Name = "C", Duration = "1.5 years", Fees = 1500 });
            foreach (Course course in CourseDetails)
                course.Display();
            Console.ReadKey();
        }
    }
    class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Duration { get; set; }
        public float Fees { get; set; }
        public void Display()
        {
            Console.WriteLine("\n*******************");
            Console.WriteLine("ID    =  " + Id);
            Console.WriteLine("Name  =  " + Name);
            Console.WriteLine("Fees  =  " + Fees);
            Console.WriteLine("*******************\n");
        }

    }
}
