﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OddOrEven
{
    class Program
    {
        static void Main(string[] args)
        {
            Oddeven O1=new Oddeven();
            O1.Input();
            O1.Check();
            O1.Display();
            Console.ReadKey();
        }
    }
}
class Oddeven
{//variable declaration
    int num; string result;
    //to read number
    public void Input()
    {
        Console.WriteLine("Enter the number to check \n");
        num=Convert.ToInt32(Console.ReadLine());
    }
    //to check and store the result (odd or even)
    public void Check()
    {
        if(num%2!=0)
        {
            
            result = "Odd";
        }
            else
            {
            
            result = "Even";
            }
       
    }

    public void Display()
    {
        Console.WriteLine("\n\n"+num + " is " + result);
    }
}
