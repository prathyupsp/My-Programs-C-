﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonocciRecursion
{
    class Program
    {
        static void Main(string[] args)
        {
            Fibonocci F1 = new Fibonocci();
            F1.Input();
            F1.Generate();
            F1.Display();
            Console.ReadKey();
        }
    }
    class Fibonocci
    {
        //declaring variables
        int Limit; int[] series;
        int t1, t2, t3, count;
        //constructor
        public Fibonocci()
        {
            t1 = 0; t2 = 1; count = 0;
        }  
        //reading no: of terms to be generated
        public void Input()
        {
            Console.WriteLine("Enter the number of terms to be generated :  ");
            Limit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            series = new int[Limit];
        }
        //Generate Fibonocci series
        public void Generate()
        {
                series[count] = t1;//store series in an array
                t3 = t1 + t2;
                t1 = t2;
                t2 = t3;
                count++;
                if (count < Limit)
                    Generate(); //recursion
       } 
        //display series
        public void Display()
        {
            for (int i = 0; i < Limit; i++)
                Console.Write(series[i] + " ");
        }
    }
}