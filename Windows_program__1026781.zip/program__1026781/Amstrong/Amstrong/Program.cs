﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Amstrong
{
    class Program
    {
        //main method
        static void Main(string[] args)
        {
            CheckAmstrong A1 = new CheckAmstrong();
            A1.Input();
            A1.Check();
            A1.Display();
            Console.ReadKey();
        }
    }
}
//class defenition
class CheckAmstrong
{
    int Number; string result;
    //reading the number to check
    public void Input()
    {
        Console.WriteLine("Enter the Number :");
        Number = Convert.ToInt32(Console.ReadLine());
    }
    //check amstrong nor not
    public void Check()
    {
        int temp = Number, rem, sum = 0, n=1;
        while ((temp / (int)Math.Pow(10, n)) > 0)
            n++;
        while(temp>0)
        {
            rem = temp % 10; 
            temp = temp / 10;
            sum = sum + (int)Math.Pow(rem, n);
        }
        if (sum == Number)
            result = " is amstrong";
        else
            result = " not amstrong";
    }
    //display the output
    public void Display()
    {
        Console.WriteLine(Number + result);
    }
}