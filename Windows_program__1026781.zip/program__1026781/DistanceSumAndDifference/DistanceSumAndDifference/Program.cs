﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistanceSumAndDifference
{
    class Program
    {
        static void Main(string[] args)
        {
            Distance D1 = new Distance();
            Distance D2 = new Distance();
            Distance D3 = new Distance();
            Distance D4 = new Distance();
            D1.Input();
            D2.Input();
            D3.CalculateSum(D1, D2);
            D4.CalculateDifference(D1, D2);
            D3.Display();
            D4.Display();
            Console.ReadKey();
        }
    }
    class Distance
    {
        //variable declaraion
        int inches, feets;
        //input the values
        public void Input()
        {
            Console.WriteLine("Enter Distance");
            reenter1: Console.Write("Enter feets  :  ");
            feets = Convert.ToInt32(Console.ReadLine());
            if (feets < 0)       //checking for valid input
            {
                Console.WriteLine("Invalid Input");
                goto reenter1;
            }  
           reenter2: Console.Write("Enter inches :  ");
            inches = Convert.ToInt32(Console.ReadLine());
            if (inches < 0 || inches > 12)        //checking for valid input
            {
                Console.WriteLine("Invalid Input");
                goto reenter2;
            }
        }
        //calculating sum
        public void CalculateSum(Distance D1,Distance D2)
        {
            int totalinches1, totalinches2, sum;
            //converting to inches
            totalinches1 = D1.inches + D1.feets * 12;
            totalinches2 = D2.inches + D2.feets * 12;
            sum = totalinches1 + totalinches2;
            //converting back to feets and inches
            feets = sum / 12;
            inches = sum % 12;
            Console.WriteLine("Sum and differences are");
        }
        //calculating difference
        public void CalculateDifference(Distance D1, Distance D2)
        {
            int totalinches1, totalinches2, difference;
            //converting to inches
            totalinches1 = D1.inches + D1.feets * 12;
            totalinches2 = D2.inches + D2.feets * 12;
            difference = Math.Abs(totalinches1 - totalinches2);
            //converting back to feets and inches
            feets = difference / 12;
            inches = difference % 12;
        }
        //displaying outputs
        public void Display()
        {
            Console.WriteLine(feets + " feets " + inches + " inches");
        }
    }
}
