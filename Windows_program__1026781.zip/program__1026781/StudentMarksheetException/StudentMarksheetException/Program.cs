﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentMarksheetException
{
    class Program
    {
        static void Main(string[] args)
        {
            Student S1 = new Student();
            S1.InputDetails();
            S1.ReadMarks();
            S1.Calculate();
            S1.Display();
            Console.ReadKey();
        }
    }
class Student
{
    //declaring datamembers
    string student_name;
    int student_id;
    float[] marks=new float[6];
    float totalMark,averageMark;
    int flag = 0;
    string[] grade=new string[6];
    string status;
   //read id and name
    public void InputDetails()
    {
        //exception handling
        try
        {
            Console.Write("Enter student id                :  ");
            student_id = Convert.ToInt32(Console.ReadLine());
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message.ToString());
        }
             Console.Write("Enter student name             :  ");
             student_name = Console.ReadLine();
    }
    //read marks and throw exception
    public void ReadMarks()
    {
        for (int i = 0; i < 6; i++)
        {
            //exception handling (Nested Try)
            try
            {
                Console.Write("Enter marks for subject " + (i + 1) + ": ");
                marks[i] = Convert.ToInt32(Console.ReadLine());

                try
                {
                    if (marks[i] > 100 || marks[i] < 0)
                    {
                        throw new MOBException();           //throw user defined exception
                    }
                }
                catch
                {
                    Console.Write("Try Again\n");
                    i--;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message.ToString());
                i--;
            }
        }  
    }
    //calculate total, grade and average
    public void Calculate()
    {
        for(int i=0;i<6;i++)
        {
            if (marks[i] >= 90)
                grade[i] = "A+";
            else if (marks[i] >= 80)
                grade[i] = "A";
            else if (marks[i] >= 70)
                grade[i] = "B+";
            else if (marks[i] >= 60)
                grade[i] = "B";
            else if (marks[i] >= 50)
                grade[i] = "C+";
            else if (marks[i] >= 40)
                grade[i] = "C";
            else
            {
                grade[i] = "D";
                flag = 1;
            }
           totalMark += marks[i];    
        }
        averageMark = totalMark / 6;
        if (flag == 0)
            status = "PASSED";
        else
            status = "FAILED";
    }
    //display details
    public void Display()
    {
        Console.WriteLine("******************************************************************\n");
        Console.WriteLine("  Student Name    : " + student_name);
        Console.WriteLine("  Student ID      : " + student_id);
        Console.WriteLine("      * * MARKS * *");
        for(int i=0;i<6;i++)
        {
           Console.WriteLine("  Subject " +(i+1)+" :  "+ marks[i]+"    "+grade[i]);
        }
        Console.WriteLine("\n  Total Marks     : " + totalMark);
        Console.WriteLine("\n  Average Marks   : " + averageMark);
            Console.WriteLine("\n         "+status);
    }
}
    //exception class
    class MOBException:Exception
    {
        public MOBException()
        {
            Console.WriteLine("**Invalid entry : Mark should be between 0 & 100 **");
        }
    }
}