﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarParkingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            CarParking C1 = new CarParking();
            C1.Input();
            Console.ReadKey();
        }
    }
    //class defenition
    class CarParking
    {
        //variables
        int[] slots;int size;
        //read options
        public void Input()
        {
            int option;
            Console.WriteLine("\n\nSelect an option :\n1.Manager \n2.Park a car \n3.Take away \n4.Show status");
            option=Convert.ToInt32(Console.ReadLine());
            if(option==1)
                Manager();
            else if(option==2)
                Park();
            else if(option==3)
                TakeACar();
            else if(option==4)
                ShowStatus();
            else
            {
                Console.WriteLine("INVALID OPTION");
                Input();
            }
        }
        //manager
        public void Manager()
        {
            Console.WriteLine("Enter no: of parking slots available :");
            size = Convert.ToInt32(Console.ReadLine());
            slots = new int[size];
            Console.WriteLine("Enter the status of each slot : 0.Available  1.Not Available");
            for(int i=0;i<size;i++)
            {
                Console.WriteLine("Slot no:  " + (i+1));//read status of slots
                slots[i] = Convert.ToInt32(Console.ReadLine());
            }
            Input();
        }
        //park a car
        public void Park()
        {
            int i;
            for(i=0;i<size;i++)
            {
                if(slots[i]==0)
                    break;
            }
            if(i>=size)
                Console.WriteLine("Sorry !! all slots are full");
            Console.WriteLine("You can park your car at slot no: " + (i + 1));
            slots[i] = 1;
            Input();
        }
        //take a car
        public void TakeACar()
        {
            int slot;
            Console.WriteLine("Enter the slot at which your car is parked:");//read parking slot number
            slot = Convert.ToInt32(Console.ReadLine());
            if (slots[slot-1] == 1)
            Console.WriteLine("SUCCESS! YOU CAN TAKE YOUR CAR");
            else
            {
                Console.WriteLine("Invalid !!");
                Input();
            }   
        }
        //show status of each slots
        public void ShowStatus()
        {
            Console.WriteLine("\n");
            int i = 0;
            for (; i < size; i++)
            {
                if(slots[i]==0)
                    Console.WriteLine("Slot no :" + (i + 1) +":  Empty");
                else
                    Console.WriteLine("Slot no :" + (i + 1) +":  Filled");
            }
            Input();
        }
    }
}
