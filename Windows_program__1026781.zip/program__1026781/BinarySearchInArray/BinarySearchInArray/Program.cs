﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearchInArray
{
    class Program
    {
        static void Main(string[] args)
        {
            BinarySearch S1 = new BinarySearch();
            S1.Input();
            S1.SortAscending();
            S1.Search();
            Console.ReadKey();
        }
    }
    class BinarySearch
    {
        int size, element;
        int[] array;
        public int[] ascendingArray;
        //Read the array
        public void Input()
        {
            Console.WriteLine("Enter the number of elements in the array : "); //read size of the array
            size = Convert.ToInt32(Console.ReadLine());
            array = new int[size];
            ascendingArray = new int[size];
            Console.WriteLine("Enter the elements in the array : ");
            //read the array elements using for loop
            for (int i = 0; i < size; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
                ascendingArray[i] = array[i];
            }
            //Read the element to search
            Console.WriteLine("Enter the element to search : ");
            element = Convert.ToInt32(Console.ReadLine());
        }
        //sorting in ascending order
        public void SortAscending()
        {
            int temp, i, j;
            for (i = 0; i < size; i++)
            {
                for (j = 0; j < i; j++)
                {
                    if (ascendingArray[i] < ascendingArray[j])
                    {
                        //swapping
                        temp = ascendingArray[i];
                        ascendingArray[i] = ascendingArray[j];
                        ascendingArray[j] = temp;
                    }
                }
            }
        }
        //binary search
        public void Search()
        {
            int min = 0, max = size + 1, flag=0;
            int k;
            for(int i=min;i<max;i++)
            {
                flag = 0;
                k = (min + max) / 2;
                if (element > ascendingArray[k-1])
                {
                    min = k;
                }
                else if (element < ascendingArray[k-1])
                {
                    max = k;
                }
                else if (element == ascendingArray[k-1])
                {
                    flag = 1;
                }
            }
            //search for the position of the element in the original array
            if (flag == 1)
                for (int r = 0; r < size; r++)
                    if (array[r] == element)
                        Console.WriteLine("found at " + (r +1) + " th position in the array");
            else if(flag == 0)
            Console.WriteLine("Not found in the array");
        }
    }
}