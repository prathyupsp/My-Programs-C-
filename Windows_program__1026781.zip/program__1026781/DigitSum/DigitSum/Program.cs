﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitSum
{
    class Program
    {
        static void Main(string[] args)
        {
            DigitSum D1 = new DigitSum();
            D1.Input();

            D1.Output();
        }
    }
    //class defenition
    class DigitSum
    {
        int num, sum;//variables
        //Function to read input
        public void Input()
        {
            int temp;
            num = Convert.ToInt32(Console.ReadLine());
            temp = num;
            Calculate(temp);//Calling the function to calculate sum of digits
        }
        //Function to display sum
        public void Output()
        {
            
            Console.WriteLine("Sum of digits of " + num + " = " + sum);
            Console.ReadKey();
        }
        //Function to calculate sum of digits
        public void Calculate(int temp)
        {
            sum = 0;
            while (temp != 0)
            {
                sum = sum + temp % 10;
                temp = temp / 10;
            }

        }

    }

}
