﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitSum
{
    class Program
    {
        static void Main(string[] args)
        {
            DigitSum D1 = new DigitSum();//Object declaration
            D1.Input();
            D1.Output();
            Console.ReadKey();
        }
    }
    //class declaration
    class DigitSum
    {
        //variable declaration
        int num, sum;
        //function to read inputs
        public void Input()
        {
            int temp;
            Console.WriteLine("Enter the no : ");
            num = Convert.ToInt32(Console.ReadLine());
            temp = num;
            calculate(temp);            //calling the function to calculate sum of digits
        }
        //function to read output
        public void Output()
        {
            if (sum > 9)
            {
                calculate(sum);         //calling the function to calculate sum of digits
            }
            Console.WriteLine("Sum of digits of " + num + " = " + sum);
        }
        //function to calculate sum of digits
        public void calculate(int temp)
        {
            sum = 0;
            while (temp != 0)
            {
                sum = sum + temp % 10;
                temp = temp / 10;
            }

        }

    }

}