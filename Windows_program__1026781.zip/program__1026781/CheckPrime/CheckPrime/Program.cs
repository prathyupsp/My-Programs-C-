﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckPrime
{
    class Program
    {
        static void Main(string[] args)
        {
            Check C1=new Check();
            C1.Input();
            C1.CheckPrime();
            C1.Display();
            Console.ReadKey();
        }
    }
    class Check
    {
        //variable declaration
        int Number; string result;
        //reading input to check
        public void Input()
        {
            Console.WriteLine("Enter the number to check :");
            Number=Convert.ToInt32(Console.ReadLine());
        }
        //Check and display whther it is prime or not
        public void CheckPrime()
        {
            int i, flag = 0;
            for (i = 2; i <= Number / 2; i++)
                if (Number % i == 0) //checking remainder
                    flag = 1;
            if (flag == 0)
                result=" is a prime";
            else
                result=" is not a prime";
        }
        //Display the result
        public void Display()
        {
            Console.WriteLine(Number + result);
        }
    }
}
