﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTestTwo
{
    public delegate bool IsBalanceDelegate(Customer C);
    class TestTwo
    {
        static void Main(string[] args)
        {
            IsBalanceDelegate isbalance = new IsBalanceDelegate(IsBalance);
            List<Customer> CustomerObj = new List<Customer>();
            Customer C1=new Customer();
            Customer C2 = new Customer();
            CustomerObj.Add(C1);
            CustomerObj.Add(C2);
            int id;
            foreach(Customer C in CustomerObj)
            {
                Console.WriteLine("Customer ID :" + C.customerID);
                C.ReadCustomer();
            }
            while (true)
            {
                Console.WriteLine("\n\nEnter Option : 1.Debit   2.Credit   3.Get Details of customer with balance <= 5000");

                int option;
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1: Console.WriteLine("Enter Customer Id : ");
                        id = Convert.ToInt32(Console.ReadLine());
                        foreach (Customer C in CustomerObj)
                        {
                            if (C.customerID == id)
                                C.Debit();
                        }
                        break;
                    case 2: Console.WriteLine("Enter Customer Id : ");
                        id = Convert.ToInt32(Console.ReadLine());
                        foreach (Customer C in CustomerObj)
                        {
                            if (C.customerID == id)
                                C.Credit();
                        } break;
                    case 3: Customer.GetCustomer(CustomerObj, isbalance); break;
                    default: Console.WriteLine("INVALID"); break;
                }
            }
             Console.ReadKey();
        }
         public static bool IsBalance(Customer C1)
         {
            if (C1.accountBalance <= 5000)
            {
                return true;
            }
            else
                return false;
            }   
       
        }
            
        //class defenition
        public class Customer
        {
            //variable declarations
            private readonly int _customerID;
            internal string customerName;
            internal int accountBalance;
            static int noOfCustomers = 0;
            const string CompanyName = "QUEST";
            //constructor
            public Customer()
            {
                noOfCustomers++;
                _customerID = noOfCustomers;
            }
            //property to return number of customers
            public int TotalCustomers
            {
                get
                {
                    return noOfCustomers;
                }
            }
            public int customerID
            {
                get
                {
                    return _customerID;
                }
            }
            //read details of customer
            public void ReadCustomer()
            {
                Console.WriteLine("Enter Customer Name : ");
                customerName = Console.ReadLine();
                Console.WriteLine("Enter Account Balance : ");
                accountBalance = Convert.ToInt32(Console.ReadLine());
            }
            //debit amount
            public void Debit()
            {
                int debit = 0;
                Console.WriteLine("Enter amount to be debited");
                debit = Convert.ToInt32(Console.ReadLine());
                //Exception handling
                try
                {
                    if (debit < 0 || debit > accountBalance)
                    {
                        InvalidAmountException Invalid = new InvalidAmountException();
                        throw Invalid;
                    }
                    accountBalance -= debit;
                    Console.WriteLine("new account balance = " + accountBalance);
                }
                catch (InvalidAmountException)
                {
                    Debit();
                }
            }
            //credit amount
            public void Credit()
            {
                int credit = 0;
                Console.WriteLine("Enter amount to be credited");
                credit = Convert.ToInt32(Console.ReadLine());
                //Exception handling
                try
                {
                    if (credit < 0)
                    {
                        InvalidAmountException Invalid = new InvalidAmountException();
                        throw Invalid;
                    }
                    accountBalance += credit;
                    Console.WriteLine("new account balance = "+accountBalance);
                }
                catch (InvalidAmountException)
                {
                    Credit();
                }
            }
            
            //getcustomer method
            public static void GetCustomer(List<Customer> list1, IsBalanceDelegate isBalanceDelegate)
            {
                //Console.WriteLine(" Details of customer with balance < = 5000");
                    foreach(Customer CList in list1)
                    {
                        if (isBalanceDelegate(CList)==true)
                         {
                                 Console.WriteLine("Customer ID = " + CList._customerID + "  |  Name = " + CList.customerName+ " |  Balance = "+CList.accountBalance);
                         }
                    } 
            }
            //user defined exception
            class InvalidAmountException : Exception
            {
                public InvalidAmountException()
                {
                    Console.WriteLine("Invalid Amount. Enter a valid Input :");
                }
            }
        }
    }