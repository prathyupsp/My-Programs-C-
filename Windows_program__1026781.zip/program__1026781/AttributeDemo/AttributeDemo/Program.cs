﻿#define DEBUG
//#undef DEBUG
#define TRACE
//#undef TRACE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Diagnostics;

namespace AttributeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            sumofNumbers S1 = new sumofNumbers();
            S1.Input();
            S1.CalculateSumAvg();
            S1.DisplaySum();
            S1.DisplayAvg();
            Console.ReadKey();
        }
    }
    class sumofNumbers
    {
        //variable declaration
        List<int>listOfNumbers=new List<int>();
        double sum, size, avg;
        //read elements
        public void Input()
        {
            Console.WriteLine("Enter the no:of elements : ");
            size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the numbers : ");
            for(int i=0;i<size;i++)
            {
                listOfNumbers.Add(Convert.ToInt32(Console.ReadLine()));
            }
        }
        //function to calculate sum and average and returns sum
   //     [Obsolete("This function to calculate sum and average is obselete", true)]
        public void CalculateSumAvg()
        {
            foreach (int i in listOfNumbers)
            {
                sum+=i;
            }
            avg = sum / size;
        }  
        //display sum
        [Conditional("DEBUG")]     //conditional attribute
        public void DisplaySum()
        {
            Console.WriteLine();
            Console.WriteLine("From DEBUG ");
            Console.WriteLine("Sum = " + sum);
        }
        
        [Conditional("TRACE")]     //conditional attribute
        public void DisplayAvg()
        {
            Console.WriteLine();
            Console.WriteLine("From TRACE ");
            Console.WriteLine("Avg = " + avg);
        }
    }
}
