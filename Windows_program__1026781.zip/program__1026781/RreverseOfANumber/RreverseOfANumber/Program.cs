﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RreverseOfANumber
{
    class Program
    {
        static void Main(string[] args)
        {
            ReverseNumber R1 = new ReverseNumber();
            R1.Input();
            R1.Reverse();
            R1.Display();
            Console.ReadKey();
        }
    }
    //class defenition
    class ReverseNumber
    {
        //variables
        int Number, ReverseOfNumber;
        //reading input
        public void Input()
        {
            Console.WriteLine("Enter the Number : ");
            Number = Convert.ToInt32(Console.ReadLine());
        }
        //calculating reverse of the number
        public void Reverse()
        {
            int temp = Number,remainder;
            while(temp>0)
            {
                remainder = temp % 10;
                ReverseOfNumber = ReverseOfNumber * 10 + remainder;
                temp = temp / 10;
            }
        }
        //Displaying the output
        public void Display()
        {
            Console.WriteLine("Reverse of " + Number + " is " + ReverseOfNumber);
        }
    }
}
