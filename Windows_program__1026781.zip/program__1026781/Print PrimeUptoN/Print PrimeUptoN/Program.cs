﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_PrimeUptoN
{
    class Program
    {
        static void Main(string[] args)
        {
            Prime P1 = new Prime();
            P1.Input();
            P1.CheckPrime();
            P1.Display();
            Console.ReadKey();
        }
    }
    class Prime
    {
        //variables
        int Limit; int[] arr;
        //input the limit
        public void Input()
        {
            Console.WriteLine("Enter upper limit prime numbers to be printed");
            Limit = Convert.ToInt32(Console.ReadLine());
            arr = new int[Limit];
        }
        //Check and display whether prime numbers
        public void CheckPrime()
        {
            int i, j = 2, n = 0;
            while (j <= Limit)
            {
                int flag = 0;
                for (i = 2; i <= (j / 2); i++)
                {
                    if (j % i == 0) //checking remainder
                        flag = 1;
                }
                if (flag == 0)
                {
                    arr[n] = j;
                    //Console.WriteLine(j);
                    n++;
                }
                j++;
            }
        }
        public void Display()
        {
            int i=0;
            while(arr[i]!=0)
            {
                Console.WriteLine(arr[i]);
                i++;
            }
               
        }
    }
}
