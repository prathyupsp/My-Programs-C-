﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    class Program
    {
        static void Main(string[] args)
        {
            int option=0;
            Transactions T1 = new Transactions();
        optionInput: Console.WriteLine("\n*************************************\n");
            Console.WriteLine("\nEnter any option : \n1.Show account details \n2.Create account \n3.Debit \n4.Credit");
            option = Convert.ToInt32(Console.ReadLine());
            switch(option)
            {
                case 1: T1.Display(); goto optionInput; break;
                case 2: T1.CreateAccount(); goto optionInput; break;
                case 3: T1.Debit(); goto optionInput; break;
                case 4: T1.Credit(); goto optionInput; break;
                default:goto optionInput;
            }
            Console.ReadKey();
        }
    }
    //class defenition
    class Account
    {
       public static long accountNumber = 100000;
       public string name;
       public double balance;
        //contact details
       public struct contactDetails
       {
           public string house;
           public string street;
           public string emailID;
           public dynamic mobileNumber;
           public contactDetails(string H,string S,string E,dynamic M)
           {
               house = H;
               street = S;
               emailID = E;
               mobileNumber = M;
           }
       }
    }
    //class transactions inherited from account
    class Transactions : Account
    {
        contactDetails C1 = new contactDetails("House", "Street", "Emil", "0000000000");
        public struct date
        {
           public int dd, mm, yy;
        }
        double amount;
        //credit an amount
        public void Credit()
        {
            int account;
            Console.WriteLine("\nEnter your account number : ");
            account = Convert.ToInt32(Console.ReadLine());
            if (account == accountNumber)
            {
                Console.WriteLine("Enter amount to be credited : ");
                amount = Convert.ToInt32(Console.ReadLine());
                if (amount > 0)
                {
                    balance += amount;
                    Console.WriteLine("SUCCESSFULLY COMPLETED ");
                }
                else
                {
                    Console.WriteLine("Invalid : ");
                    Credit();
                }
            }
            else
            {
                Console.WriteLine("INVALID!! ");
                Credit();
            }
        }
        //debit an account
        public void Debit()
        {
            int account;
            Console.WriteLine("Enter your account number : ");
            account = Convert.ToInt32(Console.ReadLine());
            if (account == accountNumber)
            {
                Console.WriteLine("Enter amount to be credited : ");
                amount = Convert.ToInt32(Console.ReadLine());
                if (amount > 0 && amount <= balance)
                {
                    balance -= amount;
                    Console.WriteLine("SUCCESSFULLY COMPLETED ");
                }
                else
                {
                    Console.WriteLine("Invalid!! ");
                    Debit();
                }
            }
            else
            {
                Console.WriteLine("INVALID!! ");
                Debit();
            }
        }
        //create an account
        public void CreateAccount()
        {
            Console.WriteLine("\nEnter your Name   : ");
            name = Console.ReadLine();
            Console.WriteLine("Enter house Name : ");
            C1.house = Console.ReadLine();
            Console.WriteLine("Enter your Street Name : ");
            C1.street = Console.ReadLine();
            Console.WriteLine("Enter your email id : ");
            C1.emailID = Console.ReadLine();
            Console.WriteLine("Enter your contact number : ");
            C1.mobileNumber = Console.ReadLine();
            Console.WriteLine("Account Number Generated : " + accountNumber++);
        }
        //display account details
        public void Display()
        {
            Console.WriteLine("\nName             : " + name);
            Console.WriteLine("Account No       : " + accountNumber);
            Console.WriteLine("Address          : " + C1.house+" (House), "+C1.street+" (Street) ");
            Console.WriteLine("Contact Number   : " + C1.mobileNumber);
            Console.WriteLine("email ID         : " + C1.emailID);
            Console.WriteLine("Balance          : " + balance);
        }
    }
}
