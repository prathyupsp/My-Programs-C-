﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //thread creation
            Thread t1 = new Thread(new ThreadStart(ThreadExample.Print));
            t1.Name = "Thread 1 ";
            Thread t2 = new Thread(new ThreadStart(ThreadExample.Print));
            t2.Name = "              Thread 2  ";
            //starting threads
            t1.Start(); 
          //  t1.Join();
            t2.Start();
            Console.ReadKey();
        }
    }
    //Class defenition
    class  ThreadExample
    {
        //function defenition
        public static void Print()
        {
            Console.WriteLine("************");
            Console.WriteLine(Thread.CurrentThread.Name);
            for (int i = 0; i <= 200; i++)
            {
                Console.WriteLine(Thread.CurrentThread.Name + "    "+i);
            }
        }  
    }
}
