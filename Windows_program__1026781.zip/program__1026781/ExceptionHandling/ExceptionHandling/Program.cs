﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        //main method
        static void Main(string[] args)
        {
            Console.WriteLine("\n\ninput =  "+Input.ReadI());
            Console.ReadKey();
        }
    }
    //class defenition
    class Input
    {
        //variable declaration
        static int number;
        //method to read input
        public static int ReadI()
        {
            try
            {
                Console.WriteLine("\n****************\n");
                Console.WriteLine("Enter the Number");
                number = Convert.ToInt32(Console.ReadLine());
            }
                //catch to handle the exception
            catch
            {
                Console.WriteLine("Invalid data");
                Input.ReadI();
            }
            return number;
        }
    }
}
