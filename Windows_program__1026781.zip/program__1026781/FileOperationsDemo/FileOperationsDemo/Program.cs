﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileOperationsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //write into file
            FileStream fwrite = new FileStream("C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Files for program\\file1.txt", FileMode.OpenOrCreate);
            for (int i = 65; i <= 90; i++)
            {
                fwrite.WriteByte((byte)i);
            }
            fwrite.Close();
            Console.WriteLine("Writing completed\n\n");
            //reading
            FileStream fread = new FileStream("C:\\Users\\1026781\\Documents\\Visual Studio 2013\\Projects\\Files for program\\file1.txt", FileMode.OpenOrCreate);
            int j=0;
            while ((j = fread.ReadByte()) != -1)
                Console.Write((char)j);
            fread.Close();
            Console.WriteLine("\nReading completed");
            Console.ReadKey();
        }
    }
}
