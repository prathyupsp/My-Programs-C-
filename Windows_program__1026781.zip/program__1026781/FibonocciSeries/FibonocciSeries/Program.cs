﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonocciSeries
{
    class Program
    {
        static void Main(string[] args)
        {
            Fibonocci F1 = new Fibonocci();
            F1.Input();
            F1.Generate();
            F1.Display();
            Console.ReadKey();
        }
    }
    //class defenition
    class Fibonocci
    {
        //declaring variables
        int Limit; int[] series;
        //reading no: of terms to be generated
        public void Input()
        {
            Console.WriteLine("Enter the number of terms to be generated :  ");
            Limit = Convert.ToInt32(Console.ReadLine());
            series = new int[Limit];
        }
        //Generate Fibonocci series
        public void Generate()
        {
            int t1 = 0, t2 = 1, t3, i=0;
            while(i<Limit)
            {
                series[i] = t1;//store the result
                t3 = t1 + t2;
                t1 = t2;
                t2 = t3;
                i++;
            }
        }
        //display the result
        public void Display()
        {
            Console.WriteLine();
            for (int i = 0; i < Limit; i++)
                Console.Write(series[i] + " ");
        }
    }
}
