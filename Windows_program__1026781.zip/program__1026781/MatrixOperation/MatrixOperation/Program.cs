﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix M1 = new Matrix();
            Matrix M2 = new Matrix();
            Matrix M3 = new Matrix();
            Matrix M4 = new Matrix();
            Matrix M5 = new Matrix();
            Console.WriteLine("MATRIX 1 : ");
            M1.ReadMatrix();
            Console.WriteLine("MATRIX 2 : ");
            M2.ReadMatrix();
            int option = 0; bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter your option\n 1.Addition  2.Subtraction  3.Multiplication");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1: Console.WriteLine("MATRIX 1 : ");//addition
                        M1.DisplayMatrix();
                        Console.WriteLine("MATRIX 2 : ");
                        M2.DisplayMatrix();
                        Console.WriteLine("SUM : ");
                        M3.AddMatrix(M1, M2);
                        M3.DisplayMatrix(); flag = false;
                        break;
                    case 2: Console.WriteLine("MATRIX 1 : ");//subtraction
                        M1.DisplayMatrix();
                        Console.WriteLine("MATRIX 2 : ");
                        M2.DisplayMatrix();
                        Console.WriteLine("DIFFERENCE : ");
                        M4.SubtractMatrix(M1, M2);
                        M4.DisplayMatrix(); flag = false;
                        break;
                    case 3: Console.WriteLine("MATRIX 1 : ");//multiplication
                        M1.DisplayMatrix();
                        Console.WriteLine("MATRIX 2 : ");
                        M2.DisplayMatrix();
                        Console.WriteLine("PRODUCT : ");
                        M5.MultiplyMatrix(M1, M2);
                        M5.DisplayMatrix(); flag = false;
                        break;
                    default: Console.WriteLine("INVALID!!\n"); break;
                }
            }
            Console.ReadKey();
        }
    }
    //class defenition
    class Matrix
    {
        int[,] matrix; static int det;
        int row, column;
        //read the matrix
        public void ReadMatrix()
        {
            Console.WriteLine("Enter no: of rows    : ");
            row = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter no: of columns : ");
            column = Convert.ToInt32(Console.ReadLine());
            matrix = new int[row, column];
            Console.WriteLine("Enter the elements of the matrix ROW wise    : ");
            for(int i=0;i<row;i++)
                for(int j=0;j<column;j++)
                    matrix[i,j] = Convert.ToInt32(Console.ReadLine());
        }
        //check compatibility and add the matrices
        public void AddMatrix(Matrix M1, Matrix M2)
        {
            if (M1.row != M2.row || M2.column != M1.column)
            {
                Console.WriteLine("Not compatible for addition");
            }
            else
            {   row = M1.row;
                column = M1.column;
                matrix = new int[row, column];
             
                for (int i = 0; i < M1.row; i++)
                    for (int j = 0; j < M1.column; j++)
                        matrix[i, j] = M1.matrix[i, j] + M2.matrix[i, j];
            }
        }
        //check compatibility and subtract the matrices
        public void SubtractMatrix(Matrix M1, Matrix M2)
        {
            if (M1.row != M2.row || M2.column != M1.column)
            {
                Console.WriteLine("Not compatible for subtraction");
            }
            else
            {
                row = M1.row;
                column = M1.column;
                matrix = new int[row, column];
                
                for (int i = 0; i < M1.row; i++)
                    for (int j = 0; j < M1.column; j++)
                        matrix[i, j] = M1.matrix[i, j] - M2.matrix[i, j];
            }
        }
        //check compatibility and multiply the matrices
        public void MultiplyMatrix(Matrix M1, Matrix M2)
        {
            if (M2.row != M1.column)
            {
                Console.WriteLine("Not compatible for multiplication");
            }
            else
            {
                row = M1.row;
                column = M2.column;
                matrix = new int[row, column];

                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < column; j++)
                    {
                        matrix[i, j] = 0;
                        for (int k = 0; k < M1.column; k++)
                        {
                            matrix[i, j] = matrix[i, j] + M1.matrix[i, k] * M2.matrix[k, j];
                        }

                    }

                }
            }

        }
        //display the matrix
        public void DisplayMatrix()
        {
            //Console.WriteLine("\n");
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine("\n");
        } 
    }
}
